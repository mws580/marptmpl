# Implementation Requirements

This document outlines the infrastructure, identities, and permissions required to deploy and operate the solution.

## 1. Overview
- Requires an active Azure subscription with appropriate billing and subscription owner contact.
- Deployment is performed using GitHub Actions and uses Entra (Azure AD) Service Principals (SPs) with workload identity federation for CI/CD.
- Solution operates across Source and Target tenants/forests. Cloud operations are performed using Entra SPs. On-premises Active Directory service accounts are required where applicable.

## 2. Prerequisites

| Item | Notes |
|---|---|
| Azure subscription | Subscription ID, billing owner, subscription-level Owner or Contributor for initial setup |
| Azure regions | Identify target regions (e.g., westeurope, northeurope) |
| CI/CD provider | Must support workload identity federation (GitHub Actions, Azure DevOps, etc.) |

## 3. Resource Group Structure

Naming convention: `rg-m365-<env>-<function>-<region>-<nnn>` (examples use `001`).

| Resource Group Example | Purpose | Location | Recommended Tags | Minimum Roles (scope: RG) |
|---|---|---|---|---|
| `rg-m365-stg-analytics-centralus-001` | Analytics and telemetry for staging environment | centralus | environment:stg,owner:<owner>,project:m365 | `Contributor` (scoped to RG)|
| `rg-m365-stg-automation-centralus-001` | Automation runbooks, automation accounts, automation credentials (stg) | centralus | environment:stg,owner:<owner>,project:m365 | `Contributor` (scoped to RG)|
| `rg-m365-stg-shared-centralus-001` | Shared platform services for staging (Data platform, VNet, DNS, common services) | centralus | environment:stg,owner:<owner>,project:m365 | `Contributor` (scoped to RG) |
| `rg-m365-prd-analytics-centralus-001` | Analytics and telemetry for production | centralus | environment:prd,owner:<owner>,project:m365 | `Contributor` (scoped to RG); |
| `rg-m365-prd-automation-centralus-001` | Automation runbooks and automation accounts (prd) | centralus | environment:prd,owner:<owner>,project:m365 | `Contributor` (scoped to RG) |
| `rg-m365-prd-shared-centralus-001` | Shared platform services for production | centralus | environment:prd,owner:<owner>,project:m365 | `Contributor` (scoped to RG) |

Notes:
- Use tags `environment`, `owner`, `project` (and `costcenter` where applicable) for billing and operations.
- Keep RG scope narrow and grant roles to Service Principals or groups at the RG level rather than subscription-wide.
- Use the numeric suffix (`001`) to support multiple copies per region or environment (e.g., `002`).

## 4. Entra Service Principals (Workload Identity Federation)

Create Entra app registrations / service principals in each tenant where deployments or automation run. Configure Federated Identity Credentials so CI/CD can request tokens without long-lived client secrets.

### Service Principal Naming Convention

Use a predictable SP name to make ownership and purpose clear. Suggested pattern:

`<repo-name>-<ci>-pipeline-<env>`

Example:

`ma-toolkit-gh-pipeline-stg` — a GitHub Actions pipeline service principal used for staging deployments.

Include the tenant, owner, and expiry metadata in the application description or tags.

### Federated Credential Naming and SP per Environment

Federated credential naming convention for GitHub OIDC: `gh-<repo>-oidc` where `<repo>` is the repository name. For this repository the federated credential should be named `gh-ma-toolkit-oidc`.

Service Principal per environment:
- Create one SP per environment (`stg`, `prd`). Example SP names:
	- `ma-toolkit-gh-pipeline-stg`
	- `ma-toolkit-gh-pipeline-prd`

Each environment SP should have a federated credential named using the `gh-<repo>-oidc` pattern and least-privilege RBAC scoped to the environment resource groups.

| Service Principal | Tenant | Purpose | Federated Credential | Minimum Roles / Permissions |
|---|---:|---|---:|---|
| `ma-toolkit-gh-pipeline-stg` | Deployment tenant (where CI runs) | Used by CI/CD to deploy into target RGs (source & target tenants as needed) | Yes (workload identity federation) | `Contributor` on target RG(s); `Key Vault Reader` for secrets; `Log Analytics Contributor` if provisioning monitoring |


Federation notes:
- For GitHub Actions: configure `audience`, `issuer`, and repository/workflow conditions.
- Use short-lived tokens and avoid client secrets when possible.

## 5. Permissions on Resource Groups

Grant roles following least-privilege principles. Typical assignments:

| Role | Assigned To | Scope | Purpose |
|---|---|---|---|
| Contributor | `ma-toolkit-gh-pipeline-stg` | Specific RG | Provision VMs, App Services, storage, other resources |
| Key Vault Reader / Secret User | `ma-toolkit-gh-pipeline-stg` or managed identity | Key Vault | Read secrets/certs needed during deployment |


## 6. Entra Service Principals in Source and Target Tenants

- Create one SP per environment (or subscription if environments will be isolated to separate subscriptions) for deployment/automation (`<repo>-gh-pipeline-<environment>`).
- For cross-tenant actions, either grant cross-tenant access via AAD B2B or create SPs in each tenant and coordinate permissions.
- Ensure each SP has a clear owner and expiry/rotation policy.


## 7. Service Principals for Analytics Ingestion

Service Principals are required for connecting to central analytics resources (such as Log Analytics workspaces, Event Hubs, and Storage Accounts) used for telemetry, monitoring, and reporting. These identities must be tightly scoped and follow the same lifecycle and secret-handling practices as other deployment SPs.

| SP Name Pattern | Target System(s) | Required Roles / Permissions | Secret / Credential Handling |
|---|---|---|---|
| `<repo>-analytics-ingest-<env>` | Log Analytics workspace in `rg-platform` | `Log Analytics Contributor` (workspace scope) or custom role with `data write` only | Prefer workload identity federation; if client secret/certificate is used, store in Key Vault with `Key Vault Secret User` / `Key Vault Certificate User` role |
| `<repo>-analytics-export-<env>` | Event Hub / Storage Account for export | `Azure Event Hubs Data Sender` (namespace or hub scope); `Storage Blob Data Contributor` (storage account or container scope) | Same as above; no secrets in code or pipeline variables, use Key Vault references where supported |

Ensure that:
- Each analytics SP is created per environment (e.g., `dev`, `stg`, `prod`) and assigned only the minimum required roles at the narrowest possible scope.
- Access to analytics data complies with organizational data governance and retention policies.
## 8. Active Directory Service Accounts (On-Prem Forests)

Where on-prem resources or AD-integrated services are required, create service accounts in each forest.

| Forest | Account Name | Group Membership / Delegation | Required Permissions |
|---|---|---|---|
| `source.corp.local` | `svc_ma_source` | Domain Users; appropriate local groups | Join machine, read user/group attributes, Kerberos constrained delegation if required |
| `target.corp.local` | `svc_ma_target` | Domain Users; appropriate local groups | Same as above for target forest tasks |

Notes:
- Use managed service accounts (gMSA) where supported for automatic password management.
- Limit accounts to required OUs and apply conditional access / MFA for interactive admin accounts.

## 9. Operational Considerations

- Logging & Monitoring: Centralize logs in a Log Analytics workspace in resource group `rg-m365-<env>-platform-<region>-001`; configure alerts for failed deployments and identity anomalies.
- Secrets Management: Store secrets/certs in Azure Key Vault; grant access via RBAC or access policies to SPs and managed identities only.
- Identity Lifecycle: Define owner, rotation, and expiry policies for SPs and federated credentials. Review federated credentials quarterly.
- Network Security: Use NSGs, private endpoints, and VNet peering as needed; minimize public endpoints.
- Backup & DR: Identify resources requiring backups and retention (databases, storage accounts) and place backup policies in resource group `rg-m365-<env>-platform-<region>-001`.

## 10. Example Minimal Role Assignment Steps

1. Create `rg-app-target`.
2. Register Entra app `sp-deploy-target`; add federated credential for CI provider.
3. Assign `Contributor` role to `sp-deploy-target` scoped to `rg-app-target`.
4. Create Key Vault in resource group `rg-m365-<env>-platform-<region>-001`; add required secrets and grant `Key Vault Reader` to `sp-deploy-target`.

## 11. Security & Compliance

- Audit logging: enable Azure Activity Logs and send to a Log Analytics or storage account for retention.
- Approvals: Use Privileged Identity Management (PIM) where elevated privileges are needed occasionally.
- Network controls and IP restrictions for Key Vault and storage where possible.

---
