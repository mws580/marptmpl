<#
.SYNOPSIS
    Creates an Azure Service Principal with GitHub OIDC Federated Credential and assigns RBAC roles for specified Resource Groups.

.DESCRIPTION
    This script automates the creation of an Azure Service Principal configured for GitHub Actions OIDC
    authentication. It creates or verifies the existence of specified Resource Groups, creates the Service Principal,
    adds a Federated Credential for GitHub OIDC, and assigns the specified RBAC role to the Service Principal for each Resource Group.

.PARAMETER CreateResourceGroupsOnly
    If set, the script will only create the Resource Groups and skip the Service Principal creation and role assignment.

.PARAMETER Environment
    The target environment for which the Resource Groups and Service Principal will be created. Valid values are "poc", "dev", "test", "prod", "stg", "prd".

.PARAMETER Region
    The Azure region where the Resource Groups will be created. Default is "eastus2".

.PARAMETER ServicePrincipalBaseName
    The base name for the Service Principal. Default is "ma-toolkit-gh-pipeline".   

.PARAMETER GitHubOrg
    The GitHub organization name. Default is "microsoft".

.PARAMETER GitHubRepo
    The GitHub repository name. Default is "ma-toolkit".

.PARAMETER SubjectString
    Custom subject string for the federated credential. If not provided, it will be constructed using the GitHub organization and repository.

.PARAMETER Role
    The RBAC role to assign to the Service Principal for each Resource Group. Valid values are "Contributor", "Reader", "Owner". Default is "Contributor".

.PARAMETER Enumerator
    An integer used to differentiate Resource Group names. Default is 1.

.EXAMPLE
    .\New-ServicePrincipalForAzure.ps1 -Environment "dev" -Region "eastus2" -ServicePrincipalBaseName "my-sp" -GitHubOrg "my-org" -GitHubRepo "my-repo" -Role "Contributor" -Enumerator 1
    This command creates a Service Principal for the "dev" environment in the "eastus2" region with the specified base name, GitHub organization, and repository. It assigns the "Contributor" role to the Service Principal for each Resource Group.

.NOTES
    This script requires the Azure CLI.
    Ensure you are logged in to Azure and have the necessary permissions to create Resource Groups, Service Principals, and assign RBAC roles.

.LINK
    https://learn.microsoft.com/en-us/azure/active-directory/develop/workload-identity-federation

#>


[CmdletBinding(DefaultParameterSetName="SubjectString")]
param(
    [Parameter(ParameterSetName="ResourceGroupsOnly", Mandatory=$false, Position=0)]
    [ValidateNotNullOrEmpty()]
    [switch]$CreateResourceGroupsOnly,

    [Parameter(Mandatory=$true, Position=1)]
    [ValidateNotNullOrEmpty()]
    [ValidateSet("poc", "dev", "test", "prod", "stg", "prd")]
    [string]$Environment,

    [Parameter(Mandatory=$false, Position=2)]
    [ValidateNotNullOrEmpty()]
    [ValidateSet("eastus2", "westus2", "centralus")]
    [string]$Region = "eastus2", 
    
    [Parameter(ParameterSetName="OrgAndRepo", Mandatory=$false, Position=3)]
    [Parameter(ParameterSetName="SubjectString", Mandatory=$false, Position=3)]
    [ValidateNotNullOrEmpty()]
    [string]$ServicePrincipalBaseName = "ma-toolkit-gh-pipeline", 

    [Parameter(ParameterSetName="OrgAndRepo", Mandatory=$false, Position=4)]
    [string]$GitHubOrg = "microsoft", 

    [Parameter(ParameterSetName="OrgAndRepo", Mandatory=$false, Position=5)]
    [Parameter(ParameterSetName="SubjectString", Mandatory=$false, Position=5)]
    [ValidateNotNullOrEmpty()]
    [string]$GitHubRepo = "ma-toolkit", 

    [Parameter(ParameterSetName="SubjectString", Mandatory=$false, Position=6)]
    [ValidateNotNullOrEmpty()]
    [string]$SubjectString = "repository_owner_id:6154722:repository_id:1115245726", 

    [Parameter(ParameterSetName="OrgAndRepo", Mandatory=$false, Position=7)]
    [Parameter(ParameterSetName="SubjectString", Mandatory=$false, Position=7)]
    [ValidateNotNullOrEmpty()]
    [ValidateSet("Contributor", "Reader", "Owner")]
    [string]$Role = "Contributor",

    [Parameter(Mandatory=$false, Position=8)]
    [int32]$Enumerator = 1
)

$RgBaseNames = @(
    "rg-m365-${Environment}-shared"
    "rg-m365-${Environment}-analytics"
    "rg-m365-${Environment}-automation"
)

$ServicePrincipalName = "$ServicePrincipalBaseName-$Environment"

if ($SubjectString)
{
    Write-Host "Using custom Subject String: $SubjectString"
    $SubjectString = "${SubjectString}:environment:$Environment"
}

else
{
    $SubjectString = "repo:$GitHubOrg/$GitHubRepo:environment:$Environment"
    Write-Host "Using default Subject String: $SubjectString"
}

$FederatedCredentialName = "gh-$GitHubRepo-oidc"

$fedCredJson = @"
{
  "name": "$FederatedCredentialName",
  "issuer": "https://token.actions.githubusercontent.com",
  "subject": "$SubjectString",
  "description": "GitHub Actions OIDC Federation for $GitHubRepo",
  "audiences": ["api://AzureADTokenExchange"]
}
"@

# Get current Azure subscription ID
$SubscriptionId = (az account show --query id -o tsv)

foreach ($BaseName in $RgBaseNames) 
{
    # 1. Get Resource Group - Create if not exists

    $ResourceGroupName = "$BaseName-$Region-{0:D3}" -f $Enumerator
    #$rg = Get-AzResourceGroup -Name $ResourceGroupName -ErrorAction SilentlyContinue
    $resourceGroupExists = az group exists --name $ResourceGroupName
    if ($resourceGroupExists -eq "true") {
        $ResourceGroup = az group show --name $ResourceGroupName | ConvertFrom-Json
    } else {
        $ResourceGroup = $null
    }
    if ($ResourceGroup) 
    {
        Write-Host "Resource Group '$ResourceGroupName' exists. Skipping creation."
        #$ResourceGroup = $ResourceGroup[0]
    }

    else 
    {
        Write-Host "Resource Group '$ResourceGroupName' not found. Creating..."
        #New-AzResourceGroup -Name $ResourceGroupName -Location $Region
        $ResourceGroup = (az group create --name $ResourceGroupName --location $Region | ConvertFrom-Json)
    }

    if ($CreateResourceGroupsOnly) 
    {
        Write-Host "CreateResourceGroupsOnly flag is set. Skipping Service Principal creation for Resource Group '$ResourceGroupName'."
        continue
    }

    else 
    {
        # 2. Check for existing App Registration and Service Principal
        Write-Host "Proceeding to create Service Principal for Resource Group '$ResourceGroupName'..."
        Write-Host "Checking for existing App Registration and Service Principal..."

        # $ExistingServicePrincipal = Get-AzADServicePrincipal -DisplayName $ServicePrincipalName -ErrorAction SilentlyContinue
        $ServicePrincipal = (az ad sp list --display-name $ServicePrincipalName | ConvertFrom-Json)[0]

        if ($ServicePrincipal) 
        {
            Write-Host "Service Principal '$ServicePrincipalName' already exists (AppId: $($ServicePrincipal.AppId)). Skipping creation."
        }

        else 
        {
            Write-Host "Service Principal '$ServicePrincipalName' not found. Creating new Service Principal..."
            # 3. Create App Registration
            # $ServicePrincipal = New-AzADServicePrincipal -DisplayName $ServicePrincipalName
            $NewServicePrincipal = az ad sp create-for-rbac --name $ServicePrincipalName --create-password false | ConvertFrom-Json
            Write-Host "Service Principal '$ServicePrincipalName' created with AppId: $($NewServicePrincipal.appId)"

            $ServicePrincipal = (az ad sp list --display-name $ServicePrincipalName | ConvertFrom-Json)[0]
        }


        if ($ServicePrincipal)
        {
            # 4. Add Federated Credential
            write-Host "Checking for existing Federated Credentials for Service Principal '$ServicePrincipalName'..."
            $FederatedCredentialRaw = az ad app federated-credential show --id $ServicePrincipal.appId --federated-credential-id $FederatedCredentialName 2>$null
            if ($LASTEXITCODE -eq 0 -and -not [string]::IsNullOrWhiteSpace($FederatedCredentialRaw))
            {
                $FederatedCredential = $FederatedCredentialRaw | ConvertFrom-Json
            }

            else
            {
                $FederatedCredential = $null
            }

            if ($FederatedCredential) 
            {
                Write-Host "Federated Credential '$FederatedCredentialName' already exists for Service Principal '$ServicePrincipalName'. Skipping addition."
            }

            else 
            {    
                Write-Host "Adding Federated Credential for GitHub OIDC to Service Principal '$ServicePrincipalName'..."
                $tempFile = New-TemporaryFile
                try
                {
                    $fedCredJson | Out-File -FilePath $tempFile -Encoding utf8

                    $FederatedCredential = az ad app federated-credential create `
                        --id $ServicePrincipal.appId `
                        --parameters $tempFile
                }
                finally
                {
                    if (Test-Path $tempFile)
                    {
                        Remove-Item $tempFile -ErrorAction SilentlyContinue
                    }
                }
                Write-Host "Federated Credential added to Service Principal '$ServicePrincipalName'."
            }
        }

        # 5. Assign RBAC Role
        Write-Host "Assigning RBAC role '$Role' to the Service Principal for Resource Group '$ResourceGroupName'..."
        #New-AzRoleAssignment -ObjectId $ServicePrincipal.Id -RoleDefinitionName $Role -Scope "/subscriptions/$SubscriptionId/resourceGroups/$ResourceGroupName"

        $RoleAssignment = az role assignment list --assignee $ServicePrincipal.appId --scope $ResourceGroup.id | ConvertFrom-Json

        if ($RoleAssignment) 
        {
            Write-Host "Role '$Role' assigned to Service Principal '$ServicePrincipalName' for Resource Group '$ResourceGroupName'."
            $ExistingRoleCount = 0

            foreach ($item in $RoleAssignment) 
            {
                if ($item.roleDefinitionName -eq $Role -and $item.scope -eq $ResourceGroup.id) 
                {
                    Write-Host "Verified: Service Principal '$ServicePrincipalName' has been assigned the role '$Role' for Resource Group '$ResourceGroupName'."
                    $ExistingRoleCount++
                }

                else 
                {
                    Write-Host "Role assignment does not match expected values. Role: $Role, Scope: $($item.scope)"
                }
            }
        } 

        if ($ExistingRoleCount -gt 0) 
        {
            Write-Host "Information: The role '$Role' is already assigned to Service Principal '$ServicePrincipalName' for Resource Group '$ResourceGroupName'."
        }

        else 
        {
            Write-Host "Assigning role '$Role' to Service Principal '$ServicePrincipalName' for Resource Group '$ResourceGroupName'."
            $RoleAssignment = az role assignment create --assignee $ServicePrincipal.appId --role $Role --scope  $ResourceGroup.id | ConvertFrom-Json
        }
    }

}

# Retrieve the actual tenant (directory) ID from the current Azure context
$TenantId = az account show --query tenantId -o tsv

if ($ServicePrincipal)
{
    Write-Host "`n=== GitHub Secrets Values ==="
    Write-Host "ENVIRONMENT: $Environment"
    Write-Host "AZURE_CLIENT_ID: $($ServicePrincipal.appId)"  
    Write-Host "AZURE_TENANT_ID: $TenantId"
    Write-Host "AZURE_APP_OBJECT_ID: $($ServicePrincipal.id)"
    Write-Host "AZURE_APP_NAME: $ServicePrincipalName"
    Write-Host "AZURE_SUBSCRIPTION_ID: $SubscriptionId"
}



<# 




Write-Host "Retrieving App Registration: $ServicePrincipalName"
$app = az ad app list --display-name $ServicePrincipalName | ConvertFrom-Json    
if ($app.Count -eq 0) {
    Write-Host "App Registration '$ServicePrincipalName' not found."
} else {
    $app | Format-List
}       

# Output values for GitHub Secrets
Write-Host "`n=== GitHub Secrets Values ==="
Write-Host "AZURE_CLIENT_ID: $($app[0].appId)"  
Write-Host "AZURE_TENANT_ID: $((az account show | ConvertFrom-Json).tenantId)"  
Write-Host "AZURE_APP_OBJECT_ID: $($app[0].id)"
Write-Host "AZURE_APP_NAME: $ServicePrincipalName"
Write-Host "AZURE_SUBSCRIPTION_ID: $((az account show | ConvertFrom-Json).id)"

# Select Service Principal by name
Write-Host "Retrieving Service Principal for App: $ServicePrincipalName"
$servicePrincipal = az ad sp list --display-name $ServicePrincipalName | ConvertFrom-Json
if ($servicePrincipal.Count -eq 0) {
    Write-Host "Service Principal for '$ServicePrincipalName' not found."
} else {
    $servicePrincipal | Format-List
}

$sp = $servicePrincipal[0]

# 2. Create Service Principal
Write-Host "Creating Service Principal..."
# $sp = az ad sp create --id $app.appId | ConvertFrom-Json

# 3. Assign RBAC Role
Write-Host "Assigning RBAC role '$Role' to the Service Principal..."
az role assignment create `
    --assignee $sp.id `
    --role $Role `
    --scope "/subscriptions/$SubscriptionId/resourceGroups/$ResourceGroupName"

# 4. Add Federated Credential
Write-Host "Adding Federated Credential for GitHub OIDC..."
$fedCredJson = @"
{
  "name": "gh-$GitHubRepo-oidc",
  "issuer": "https://token.actions.githubusercontent.com",
  "subject": "repo:$GitHubOrg/$GitHubRepo:ref:refs/heads/main",
  "description": "GitHub Actions OIDC Federation for $GitHubRepo",
  "audiences": ["api://AzureADTokenExchange"]
}
"@

$tempFile = New-TemporaryFile
$fedCredJson | Out-File $tempFile

az ad app federated-credential create `
    --id $app.appId `
    --parameters $tempFile

Remove-Item $tempFile

# 5. Output values for GitHub Secrets
Write-Host "`n=== Add these to your GitHub Secrets ==="
Write-Host "AZURE_CLIENT_ID: $($app.appId)"
Write-Host "AZURE_TENANT_ID: $(az account show --query tenantId -o tsv)"
Write-Host "AZURE_SUBSCRIPTION_ID: $SubscriptionId"
Write-Host "========================================="
 #>