<#
.SYNOPSIS
    Exchange Online ingestion script for Microsoft 365 analytics.

.DESCRIPTION
    This script handles Exchange Online data extraction including:
    - Mailboxes with statistics (source and target)
    - Mail Users / External Members (target only - for external linkage matching)
    
    Process:
    1. Retrieves environment configuration from Key Vault
    2. Retrieves certificate from Key Vault
    3. Authenticates to Exchange Online using certificate-based auth
    4. Pulls mailbox data with statistics
    5. For target environment: also pulls Mail Users (external members)
    6. Writes JSON to ADLS landing zone
    
    Container Architecture:
    - This script runs in the dedicated exo-ingest container
    - It does NOT load Microsoft.Graph modules
    - This avoids OData assembly conflicts (EXO needs 7.15.0, Graph uses 7.21.0)
    - Graph API entities (users, groups, etc.) are handled by
      Invoke-GraphIngestion.ps1 in the graph-ingest container

.PARAMETER KeyVaultName
    Key Vault name containing the certificate and configuration secrets.

.PARAMETER Environment
    Source or target environment: source, target

.PARAMETER StorageAccountName
    ADLS storage account name. If not provided, fetched from Key Vault.

.PARAMETER ContainerName
    Azure Storage container name. Default: bronze

.PARAMETER BatchId
    Batch ID for tracking. Auto-generated if not provided.

.PARAMETER DebugMode
    Enable verbose debug output.

.EXAMPLE
    # Direct invocation (container entry point)
    ./Invoke-ExoIngestion.ps1 -KeyVaultName "kv-m365-dev-001" -Environment "source"
    
.EXAMPLE
    # Target environment - fetches both mailboxes AND mail users
    ./Invoke-ExoIngestion.ps1 -KeyVaultName "kv-m365-dev-001" -Environment "target"

.NOTES
    Entry point: This is the ENTRYPOINT for the exo-ingest container.
    Entity types:
    - mailboxes: Always fetched (source and target)
    - mail_users: Only fetched for target environment (external members for identity matching)
#>

[CmdletBinding()]
param(
    [Parameter(Mandatory = $false)]
    [string]$KeyVaultName = $env:KEYVAULT_NAME,

    [Parameter(Mandatory = $false)]
    [ValidateSet("source", "target")]
    [string]$Environment = $env:ENVIRONMENT,

    [Parameter(Mandatory = $false)]
    [string]$StorageAccountName = $env:STORAGE_ACCOUNT_NAME,

    [Parameter(Mandatory = $false)]
    [string]$ContainerName = "bronze",

    [Parameter(Mandatory = $false)]
    [string]$BatchId = [guid]::NewGuid().ToString(),

    [Parameter(Mandatory = $false)]
    [bool]$DebugMode = [bool]$env:DEBUG_MODE
)

# Script variables
$script:StartTime = Get-Date
$script:BatchId = $BatchId

function Write-Log {
    param([string]$Message, [string]$Level = "INFO")
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    Write-Host "[$timestamp] [$Level] [EXO-PROCESS] $Message"
}

function Get-MaskedValue {
    param([string]$Value, [int]$VisibleChars = 4)
    if ([string]::IsNullOrEmpty($Value)) { return "[not set]" }
    if ($Value.Length -le ($VisibleChars * 2)) { return "****" }
    $start = $Value.Substring(0, $VisibleChars)
    $end = $Value.Substring($Value.Length - $VisibleChars)
    return "$start****$end"
}

function Get-IngestionStats {
    param(
        $MailboxCount,
        $MailUserCount,
        $Status,
        $ErrorMessage = $null
    )
    
    $endTime = Get-Date
    $duration = ($endTime - $script:StartTime).TotalSeconds
    
    return @{
        batch_id            = $script:BatchId
        environment         = $Environment
        started_at          = $script:StartTime.ToString("o")
        completed_at        = $endTime.ToString("o")
        duration_seconds    = [math]::Round($duration, 2)
        mailboxes_fetched   = $MailboxCount
        mail_users_fetched  = $MailUserCount
        status              = $Status
        error_message       = $ErrorMessage
    }
}

# Validate required parameters
if ([string]::IsNullOrEmpty($KeyVaultName)) {
    throw "KeyVaultName is required. Set via parameter or KEYVAULT_NAME environment variable."
}
if ([string]::IsNullOrEmpty($Environment)) {
    throw "Environment is required. Set via parameter or ENVIRONMENT environment variable."
}

# Load modules
Write-Log "Loading Exchange Online and Az modules (excluding Az.Storage)..."
try {
    Import-Module ExchangeOnlineManagement -ErrorAction Stop
    Write-Log "ExchangeOnlineManagement loaded"
    
    Import-Module Az.Accounts -ErrorAction Stop
    Import-Module Az.KeyVault -ErrorAction Stop
    Write-Log "Az.Accounts and Az.KeyVault loaded (Az.Storage excluded to avoid OData conflict)"
}
catch {
    Write-Log "Failed to load modules: $($_.Exception.Message)" -Level "ERROR"
    throw
}

# Import custom modules
$modulePath = Join-Path $PSScriptRoot "modules"
$kvHelperPath = Join-Path $modulePath "KeyVaultHelper.psm1"
Import-Module $kvHelperPath -Force -ErrorAction Stop
Write-Log "KeyVaultHelper loaded"

# REST-based blob upload function
function Write-ToAdlsRest {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$StorageAccountName,
        
        [Parameter(Mandatory = $true)]
        [string]$ContainerName,
        
        [Parameter(Mandatory = $true)]
        [string]$BlobPath,
        
        [Parameter(Mandatory = $true)]
        [object]$Data,
        
        [Parameter(Mandatory = $false)]
        [string]$BatchId = [guid]::NewGuid().ToString(),

        [Parameter(Mandatory = $false)]
        [string]$TenantId = "",

        [Parameter(Mandatory = $false)]
        [string]$TenantName = "",

        [Parameter(Mandatory = $false)]
        [string]$EntityType = "",

        [Parameter(Mandatory = $false)]
        [string]$Environment = ""
    )
    
    try {
        $identityEndpoint = $env:IDENTITY_ENDPOINT
        $identityHeader = $env:IDENTITY_HEADER
        
        if ([string]::IsNullOrEmpty($identityEndpoint)) {
            throw "IDENTITY_ENDPOINT not set - managed identity not available"
        }
        
        $resource = "https://storage.azure.com/"
        $tokenUrl = "$identityEndpoint`?resource=$resource&api-version=2019-08-01"
        
        Write-Log "Getting storage token from ACA identity endpoint..."
        $tokenResponse = Invoke-RestMethod -Uri $tokenUrl -Headers @{"X-IDENTITY-HEADER"=$identityHeader} -Method Get
        $accessToken = $tokenResponse.access_token
        
        if ([string]::IsNullOrEmpty($accessToken)) {
            throw "Access token is null or empty"
        }
        
        Write-Log "Got storage access token (length: $($accessToken.Length))"
        
        $wrapper = @{
            batch_id     = $BatchId
            tenant_id    = $TenantId
            tenant_name  = $TenantName
            entity_type  = $EntityType
            environment  = $Environment
            ingested_at  = (Get-Date).ToString("o")
            record_count = ($Data | Measure-Object).Count
            data         = $Data
        }
        
        $json = $wrapper | ConvertTo-Json -Depth 20 -Compress
        $bytes = [System.Text.Encoding]::UTF8.GetBytes($json)
        
        # Create file
        $createUri = "https://$StorageAccountName.dfs.core.windows.net/$ContainerName/$($BlobPath)?resource=file"
        $headers = @{
            "Authorization"  = "Bearer $accessToken"
            "x-ms-version"   = "2021-08-06"
            "Content-Length" = "0"
        }
        Write-Log "Creating file at: $createUri"
        Invoke-RestMethod -Uri $createUri -Method Put -Headers $headers
        
        # Append data
        $appendUri = "https://$StorageAccountName.dfs.core.windows.net/$ContainerName/$($BlobPath)?action=append&position=0"
        $appendHeaders = @{
            "Authorization"  = "Bearer $accessToken"
            "x-ms-version"   = "2021-08-06"
            "Content-Type"   = "application/json"
            "Content-Length" = $bytes.Length.ToString()
        }
        Write-Log "Appending $($bytes.Length) bytes..."
        Invoke-RestMethod -Uri $appendUri -Method Patch -Headers $appendHeaders -Body $bytes
        
        # Flush
        $flushUri = "https://$StorageAccountName.dfs.core.windows.net/$ContainerName/$($BlobPath)?action=flush&position=$($bytes.Length)"
        $flushHeaders = @{
            "Authorization"  = "Bearer $accessToken"
            "x-ms-version"   = "2021-08-06"
            "Content-Length" = "0"
        }
        Write-Log "Flushing file..."
        Invoke-RestMethod -Uri $flushUri -Method Patch -Headers $flushHeaders
        
        Write-Log "Successfully uploaded to ADLS: $ContainerName/$BlobPath"
        return $true
    }
    catch {
        Write-Log "Failed to upload to ADLS via REST: $($_.Exception.Message)" -Level "ERROR"
        throw
    }
}

function ConvertTo-SizeMB {
    [CmdletBinding()]
    param([Parameter(Mandatory = $false)][object]$SizeObject)
    
    if (-not $SizeObject) { return 0 }
    
    try {
        if ($SizeObject.Value -and $SizeObject.Value.PSObject.Methods.Name -contains 'ToMB') {
            return [double]$SizeObject.Value.ToMB()
        }
        if ($SizeObject.Value -is [long] -or $SizeObject.Value -is [int64]) {
            return [double]$SizeObject.Value / 1MB
        }
        $sizeString = $SizeObject.ToString()
        if ($sizeString -match '\(([\d,\.]+)\s*bytes\)') {
            $bytesString = $matches[1] -replace '[,\s]', ''
            if ([double]::TryParse($bytesString, [ref]$null)) {
                return [double]$bytesString / 1MB
            }
        }
        $normalizedString = $sizeString.Trim()
        if ($normalizedString -match '^([\d,\.\s]+)\s*(KB|MB|GB|TB|B)\b') {
            $valueString = $matches[1].Trim() -replace '\s', ''
            $unit = $matches[2].ToUpper()
            if ($valueString -match '^\d+,\d+$' -and $valueString -notmatch '\.') {
                $valueString = $valueString -replace ',', '.'
            }
            else {
                $valueString = $valueString -replace ',', ''
            }
            $value = 0.0
            if ([double]::TryParse($valueString, [System.Globalization.NumberStyles]::Any, 
                [System.Globalization.CultureInfo]::InvariantCulture, [ref]$value)) {
                $result = switch ($unit) {
                    "B"  { $value / 1MB }
                    "KB" { $value / 1024 }
                    "MB" { $value }
                    "GB" { $value * 1024 }
                    "TB" { $value * 1024 * 1024 }
                    default { 0 }
                }
                return $result
            }
        }
        return 0
    }
    catch {
        return 0
    }
}

function Get-ExoMailboxes {
    [CmdletBinding()]
    param()
    
    Write-Log "Fetching mailboxes from Exchange Online..."
    
    $allMailboxes = @()
    $mailboxes = Get-EXOMailbox -ResultSize Unlimited -PropertySets All
    
    Write-Log "Found $($mailboxes.Count) mailboxes, fetching statistics..."
    
    $processed = 0
    foreach ($mbx in $mailboxes) {
        try {
            $stats = Get-EXOMailboxStatistics -Identity $mbx.ExchangeGuid.ToString() -ErrorAction SilentlyContinue
            
            $allMailboxes += [PSCustomObject]@{
                ExchangeGuid                  = $mbx.ExchangeGuid.ToString()
                UserPrincipalName             = $mbx.UserPrincipalName
                DisplayName                   = $mbx.DisplayName
                PrimarySmtpAddress            = $mbx.PrimarySmtpAddress
                Alias                         = $mbx.Alias
                RecipientType                 = $mbx.RecipientType
                RecipientTypeDetails          = $mbx.RecipientTypeDetails
                EmailAddresses                = ($mbx.EmailAddresses | Where-Object { $_ -like "smtp:*" }) -join ";"
                WhenCreated                   = $mbx.WhenCreated
                WhenMailboxCreated            = $mbx.WhenMailboxCreated
                IsMailboxEnabled              = $mbx.IsMailboxEnabled
                ArchiveStatus                 = $mbx.ArchiveStatus
                ArchiveGuid                   = $mbx.ArchiveGuid.ToString()
                LitigationHoldEnabled         = $mbx.LitigationHoldEnabled
                RetentionHoldEnabled          = $mbx.RetentionHoldEnabled
                InPlaceHolds                  = ($mbx.InPlaceHolds -join ";")
                ForwardingAddress             = $mbx.ForwardingAddress
                ForwardingSmtpAddress         = $mbx.ForwardingSmtpAddress
                DeliverToMailboxAndForward    = $mbx.DeliverToMailboxAndForward
                HiddenFromAddressListsEnabled = $mbx.HiddenFromAddressListsEnabled
                IsDirSynced                   = $mbx.IsDirSynced
                ExternalDirectoryObjectId     = $mbx.ExternalDirectoryObjectId
                ItemCount                     = if ($stats) { $stats.ItemCount } else { $null }
                TotalItemSizeMB               = if ($stats) { ConvertTo-SizeMB -SizeObject $stats.TotalItemSize } else { $null }
                DeletedItemCount              = if ($stats) { $stats.DeletedItemCount } else { $null }
                DeletedItemSizeMB             = if ($stats) { ConvertTo-SizeMB -SizeObject $stats.TotalDeletedItemSize } else { $null }
                LastLogonTime                 = if ($stats) { $stats.LastLogonTime } else { $null }
                LastUserActionTime            = if ($stats) { $stats.LastUserActionTime } else { $null }
            }
            
            $processed++
            if ($processed % 100 -eq 0) {
                Write-Log "  Processed $processed of $($mailboxes.Count) mailboxes..."
            }
        }
        catch {
            Write-Warning "Failed to get stats for $($mbx.UserPrincipalName): $($_.Exception.Message)"
            $allMailboxes += [PSCustomObject]@{
                ExchangeGuid                  = $mbx.ExchangeGuid.ToString()
                UserPrincipalName             = $mbx.UserPrincipalName
                DisplayName                   = $mbx.DisplayName
                PrimarySmtpAddress            = $mbx.PrimarySmtpAddress
                Alias                         = $mbx.Alias
                RecipientType                 = $mbx.RecipientType
                RecipientTypeDetails          = $mbx.RecipientTypeDetails
                EmailAddresses                = ($mbx.EmailAddresses | Where-Object { $_ -like "smtp:*" }) -join ";"
                WhenCreated                   = $mbx.WhenCreated
                WhenMailboxCreated            = $mbx.WhenMailboxCreated
                IsMailboxEnabled              = $mbx.IsMailboxEnabled
                ArchiveStatus                 = $mbx.ArchiveStatus
                ArchiveGuid                   = $mbx.ArchiveGuid.ToString()
                LitigationHoldEnabled         = $mbx.LitigationHoldEnabled
                RetentionHoldEnabled          = $mbx.RetentionHoldEnabled
                InPlaceHolds                  = ($mbx.InPlaceHolds -join ";")
                ForwardingAddress             = $mbx.ForwardingAddress
                ForwardingSmtpAddress         = $mbx.ForwardingSmtpAddress
                DeliverToMailboxAndForward    = $mbx.DeliverToMailboxAndForward
                HiddenFromAddressListsEnabled = $mbx.HiddenFromAddressListsEnabled
                IsDirSynced                   = $mbx.IsDirSynced
                ExternalDirectoryObjectId     = $mbx.ExternalDirectoryObjectId
                ItemCount                     = $null
                TotalItemSizeMB               = $null
                DeletedItemCount              = $null
                DeletedItemSizeMB             = $null
                LastLogonTime                 = $null
                LastUserActionTime            = $null
            }
        }
    }
    
    Write-Log "Completed fetching $($allMailboxes.Count) mailboxes with statistics"
    return $allMailboxes
}

function Get-ExoMailUsers {
    <#
    .SYNOPSIS
        Fetches Mail Users (external members) from Exchange Online.
        
    .DESCRIPTION
        Mail Users represent external members in the target tenant.
        They have an ExternalEmailAddress (targetAddress) that points to their
        primary mailbox in an external organization.
        
        This data is critical for "external linkage" identity matching:
        - Target Mail User's ExternalEmailAddress → Source User's proxyAddresses
    #>
    [CmdletBinding()]
    param()
    
    Write-Log "Fetching mail users (external members) from Exchange Online..."
    
    $allMailUsers = @()
    
    try {
        $mailUsers = Get-MailUser -ResultSize Unlimited -ErrorAction Stop
        
        Write-Log "Found $($mailUsers.Count) mail users"
        
        $processed = 0
        foreach ($mu in $mailUsers) {
            $allMailUsers += [PSCustomObject]@{
                # Identity
                ExternalDirectoryObjectId     = $mu.ExternalDirectoryObjectId
                Guid                          = $mu.Guid.ToString()
                Identity                      = $mu.Identity
                
                # Display info
                DisplayName                   = $mu.DisplayName
                FirstName                     = $mu.FirstName
                LastName                      = $mu.LastName
                
                # Email addresses - CRITICAL for identity matching
                ExternalEmailAddress          = $mu.ExternalEmailAddress
                PrimarySmtpAddress            = $mu.PrimarySmtpAddress
                EmailAddresses                = ($mu.EmailAddresses | Where-Object { $_ -like "smtp:*" }) -join ";"
                Alias                         = $mu.Alias
                
                # Recipient info
                RecipientType                 = $mu.RecipientType
                RecipientTypeDetails          = $mu.RecipientTypeDetails
                
                # Employment attributes
                Department                    = $mu.Department
                Company                       = $mu.Company
                Title                         = $mu.Title
                
                # Sync status
                IsDirSynced                   = $mu.IsDirSynced
                WhenCreated                   = $mu.WhenCreated
                WhenChanged                   = $mu.WhenChanged
                
                # Hidden from GAL?
                HiddenFromAddressListsEnabled = $mu.HiddenFromAddressListsEnabled
            }
            
            $processed++
            if ($processed % 100 -eq 0) {
                Write-Log "  Processed $processed of $($mailUsers.Count) mail users..."
            }
        }
        
        Write-Log "Completed fetching $($allMailUsers.Count) mail users"
    }
    catch {
        Write-Log "Failed to fetch mail users: $($_.Exception.Message)" -Level "ERROR"
        return @()
    }
    
    return $allMailUsers
}

# Main execution
$certPath = $null
try {
    Write-Log "=========================================="
    Write-Log "Exchange Online Ingestion (Isolated Process)"
    Write-Log "=========================================="
    Write-Log "Batch ID: $BatchId"
    Write-Log "Environment: $Environment"

    # Step 1: Authenticate to Azure using Managed Identity
    Write-Log "Authenticating to Azure using Managed Identity..."
    Connect-AzAccount -Identity | Out-Null
    Write-Log "Azure authentication successful"

    # Step 2: Fetch storage account name from Key Vault (if not provided)
    if ([string]::IsNullOrEmpty($StorageAccountName)) {
        Write-Log "Fetching storage account name from Key Vault..."
        $StorageAccountName = Get-SecretFromKeyVault -KeyVaultName $KeyVaultName -SecretName "storage-account-name"
    }

    # Step 3: Fetch tenant configuration from Key Vault
    Write-Log "Fetching tenant configuration from Key Vault for environment: $Environment"
    $envConfig = Get-EnvironmentConfigFromKeyVault -KeyVaultName $KeyVaultName -Environment $Environment
    
    $TenantId = $envConfig.TenantId
    $ClientId = $envConfig.ClientId
    $CertName = $envConfig.CertName
    $Organization = $envConfig.Organization
    
    $TenantName = $envConfig.TenantName
    if ([string]::IsNullOrEmpty($TenantName)) {
        $TenantName = $Environment.ToUpper()
    }

    if ([string]::IsNullOrEmpty($Organization)) {
        throw "Organization domain is required for Exchange Online."
    }

    if (-not $DebugMode) {
        Write-Log "Tenant ID: $(Get-MaskedValue $TenantId)"
        Write-Log "Organization: $Organization"
    }
    else {
        Write-Log "[DEBUG] Tenant ID: $TenantId"
        Write-Log "[DEBUG] Client ID: $ClientId"
        Write-Log "[DEBUG] Organization: $Organization"
    }

    # Step 4: Get certificate from Key Vault
    Write-Log "Retrieving certificate from Key Vault..."
    $certPath = Get-CertificateFromKeyVault -KeyVaultName $KeyVaultName -CertName $CertName
    Write-Log "Certificate retrieved"

    # Step 5: Connect to Exchange Online
    Write-Log "Connecting to Exchange Online..."
    Connect-ExchangeOnline -CertificateFilePath $certPath `
                           -AppId $ClientId `
                           -Organization $Organization `
                           -ShowBanner:$false
    Write-Log "Exchange Online connection established"

    # Step 6: Fetch mailboxes (both source and target)
    $mailboxData = Get-ExoMailboxes
    $mailboxCount = ($mailboxData | Measure-Object).Count
    Write-Log "Fetched $mailboxCount mailboxes"

    # Step 7: Write mailboxes to ADLS
    $date = Get-Date -Format "yyyy-MM-dd"
    $timestamp = Get-Date -Format "HHmmss"
    $mailboxBlobPath = "raw/exo_mailboxes/$Environment/$date/mailboxes_$($timestamp).json"
    
    Write-Log "Writing mailbox data to ADLS: $ContainerName/$mailboxBlobPath"
    Write-ToAdlsRest -StorageAccountName $StorageAccountName `
                     -ContainerName $ContainerName `
                     -BlobPath $mailboxBlobPath `
                     -Data $mailboxData `
                     -BatchId $BatchId `
                     -TenantId $TenantId `
                     -TenantName $TenantName `
                     -EntityType "mailboxes" `
                     -Environment $Environment
    Write-Log "Mailbox data written successfully"

    # Step 8: For TARGET environment only - fetch Mail Users (external members)
    $mailUserCount = 0
    if ($Environment -eq "target") {
        Write-Log "Target environment detected - fetching Mail Users for external linkage..."
        $mailUserData = Get-ExoMailUsers
        $mailUserCount = ($mailUserData | Measure-Object).Count
        
        if ($mailUserCount -gt 0) {
            $mailUserBlobPath = "raw/exo_mail_users/$Environment/$date/mail_users_$($timestamp).json"
            
            Write-Log "Writing mail user data to ADLS: $ContainerName/$mailUserBlobPath"
            Write-ToAdlsRest -StorageAccountName $StorageAccountName `
                             -ContainerName $ContainerName `
                             -BlobPath $mailUserBlobPath `
                             -Data $mailUserData `
                             -BatchId $BatchId `
                             -TenantId $TenantId `
                             -TenantName $TenantName `
                             -EntityType "mail_users" `
                             -Environment $Environment
            Write-Log "Mail user data written successfully"
        }
        else {
            Write-Log "No mail users found in target environment"
        }
    }
    else {
        Write-Log "Source environment - skipping Mail Users fetch (only needed for target)"
    }

    # Step 9: Disconnect
    Disconnect-ExchangeOnline -Confirm:$false -ErrorAction SilentlyContinue

    # Output stats
    $stats = Get-IngestionStats -MailboxCount $mailboxCount -MailUserCount $mailUserCount -Status "success"
    Write-Log "=========================================="
    Write-Log "EXO ingestion completed successfully"
    Write-Log "Mailboxes: $mailboxCount"
    Write-Log "Mail Users: $mailUserCount"
    Write-Log "Duration: $($stats.duration_seconds) seconds"
    Write-Log "=========================================="
    
    $stats | ConvertTo-Json -Compress | Write-Output
    exit 0
}
catch {
    $errorMessage = $_.Exception.Message
    Write-Log "FAILED: $errorMessage" -Level "ERROR"
    Write-Log $_.ScriptStackTrace -Level "ERROR"
    
    $stats = Get-IngestionStats -MailboxCount 0 -MailUserCount 0 -Status "failed" -ErrorMessage $errorMessage
    $stats | ConvertTo-Json -Compress | Write-Output
    exit 1
}
finally {
    if ($certPath -and (Test-Path $certPath -ErrorAction SilentlyContinue)) {
        try {
            Remove-Item $certPath -Force -ErrorAction Stop
            Write-Log "Temporary certificate file cleaned up"
        }
        catch {
            Write-Log "WARNING: Failed to remove temporary certificate file" -Level "WARN"
        }
    }
}