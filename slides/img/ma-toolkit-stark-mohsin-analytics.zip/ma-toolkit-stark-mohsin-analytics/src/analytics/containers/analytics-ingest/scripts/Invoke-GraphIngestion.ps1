<#
.SYNOPSIS
    Main entry point for Graph API / EXO ingestion.

.DESCRIPTION
    This script:
    1. Retrieves certificate from Key Vault
    2. Authenticates to Graph API or Exchange Online
    3. Pulls data for specified entity
    4. Writes JSON to ADLS landing zone

.PARAMETER EntityType
    Type of entity to ingest: users, contacts, groups, group_members, mailboxes, onedrive, sharepoint

.PARAMETER Environment
    Source or target environment: source, target

.PARAMETER TenantId
    Azure AD Tenant ID for the target tenant

.PARAMETER ClientId
    App Registration Client ID

.PARAMETER KeyVaultName
    Key Vault name containing the certificate

.PARAMETER CertName
    Certificate name in Key Vault

.PARAMETER StorageAccountName
    ADLS storage account name

.EXAMPLE
    ./Invoke-GraphIngestion.ps1 -EntityType users -Environment source -TenantId "xxx" -ClientId "yyy"
#>

[CmdletBinding()]
param(
    [Parameter(Mandatory = $false)]
    [ValidateSet("users", "contacts", "groups", "group_members", "mailboxes", "onedrive", "sharepoint")]
    [string]$EntityType = $env:ENTITY_TYPE,

    [Parameter(Mandatory = $false)]
    [ValidateSet("source", "target")]
    [string]$Environment = $env:ENVIRONMENT,

    [Parameter(Mandatory = $false)]
    [string]$TenantId = $env:TENANT_ID,

    [Parameter(Mandatory = $false)]
    [string]$ClientId = $env:CLIENT_ID,

    [Parameter(Mandatory = $false)]
    [string]$KeyVaultName = $env:KEYVAULT_NAME,

    [Parameter(Mandatory = $false)]
    [string]$CertName = $env:CERT_NAME,

    [Parameter(Mandatory = $false)]
    [string]$StorageAccountName = $env:STORAGE_ACCOUNT_NAME,

    [Parameter(Mandatory = $false)]
    [string]$ContainerName = "bronze",

    [Parameter(Mandatory = $false)]
    [bool]$DebugMode = [bool]$env:DEBUG_MODE
)

# Import modules with error handling
$modulePath = Join-Path $PSScriptRoot "modules"

# Debug output for module loading (only when DEBUG_MODE is set, since Write-Log isn't defined yet)
if ($DebugMode) {
    Write-Host "[DEBUG] PSScriptRoot: $PSScriptRoot"
    Write-Host "[DEBUG] Module path: $modulePath"
    Write-Host "[DEBUG] Module path exists: $(Test-Path $modulePath)"
}

$moduleFiles = @(
    "KeyVaultHelper.psm1",
    "GraphHelper.psm1",
    "StorageHelper.psm1"
)

foreach ($moduleFile in $moduleFiles) {
    $fullPath = Join-Path $modulePath $moduleFile
    if ($DebugMode) {
        Write-Host "[DEBUG] Importing module: $fullPath (exists: $(Test-Path $fullPath))"
    }
    try {
        Import-Module $fullPath -Force -ErrorAction Stop
        if ($DebugMode) {
            Write-Host "[DEBUG] Successfully imported: $moduleFile"
        }
    }
    catch {
        Write-Host "[ERROR] Failed to import $moduleFile : $($_.Exception.Message)"
        throw
    }
}

# Script variables
$script:StartTime = Get-Date
$script:BatchId = [guid]::NewGuid().ToString()

function Write-Log {
    param([string]$Message, [string]$Level = "INFO")
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    Write-Host "[$timestamp] [$Level] $Message"
}

function Get-MaskedValue {
    <#
    .SYNOPSIS
        Returns a masked version of sensitive values for logging.
        Shows first 4 and last 4 characters with asterisks in between.
    #>
    param([string]$Value, [int]$VisibleChars = 4)
    
    if ([string]::IsNullOrEmpty($Value)) { return "[not set]" }
    if ($Value.Length -le ($VisibleChars * 2)) { return "****" }
    
    $start = $Value.Substring(0, $VisibleChars)
    $end = $Value.Substring($Value.Length - $VisibleChars)
    return "$start****$end"
}

function Get-IngestionStats {
    param($RecordCount, $Status, $ErrorMessage = $null)
    
    $endTime = Get-Date
    $duration = ($endTime - $script:StartTime).TotalSeconds
    
    return @{
        batch_id        = $script:BatchId
        entity_type     = $EntityType
        environment     = $Environment
        tenant_id       = $TenantId
        started_at      = $script:StartTime.ToString("o")
        completed_at    = $endTime.ToString("o")
        duration_seconds = [math]::Round($duration, 2)
        records_fetched = $RecordCount
        status          = $Status
        error_message   = $ErrorMessage
    }
}

# Main execution
$certPath = $null
try {
    Write-Log "=========================================="
    Write-Log "M365 Analytics Ingestion"
    Write-Log "=========================================="
    Write-Log "Batch ID: $($script:BatchId)"
    Write-Log "Entity: $EntityType"
    Write-Log "Environment: $Environment"
    Write-Log "=========================================="

    # Validate minimal required parameters (before KV fetch)
    if ([string]::IsNullOrEmpty($KeyVaultName)) {
        throw "Required parameter 'KeyVaultName' is not set"
    }
    if ([string]::IsNullOrEmpty($Environment)) {
        throw "Required parameter 'Environment' is not set"
    }

    # Step 1: Authenticate to Azure using Managed Identity (for Key Vault and Storage access)
    Write-Log "Authenticating to Azure using Managed Identity..."
    Connect-AzAccount -Identity | Out-Null
    Write-Log "Azure authentication successful"

    # Step 1.5: If config values not provided via env vars, fetch from Key Vault
    if ([string]::IsNullOrEmpty($TenantId) -or [string]::IsNullOrEmpty($ClientId)) {
        Write-Log "Fetching tenant configuration from Key Vault for environment: $Environment"
        $configSecretName = "config-$Environment"
        $configSecret = Get-AzKeyVaultSecret -VaultName $KeyVaultName -Name $configSecretName -AsPlainText
        $config = $configSecret | ConvertFrom-Json
        
        # Override variables with config values (handle both PascalCase and camelCase)
        $TenantId = if ($config.TenantId) { $config.TenantId } else { $config.tenantId }
        $ClientId = if ($config.ClientId) { $config.ClientId } else { $config.clientId }
        $CertName = if ($config.CertName) { $config.CertName } else { $config.certName }
        
        # Store Organization for EXO if present
        $org = if ($config.Organization) { $config.Organization } else { $config.organization }
        if ($org) {
            $script:Organization = $org
        }
        
        Write-Log "Tenant configuration loaded from Key Vault"
    }
    
    # Fetch storage account name from separate secret if not provided
    if ([string]::IsNullOrEmpty($StorageAccountName)) {
        Write-Log "Fetching storage account name from Key Vault"
        $StorageAccountName = Get-AzKeyVaultSecret -VaultName $KeyVaultName -Name "storage-account-name" -AsPlainText
    }
    
    Write-Log "Tenant ID: $(Get-MaskedValue $TenantId)"
    Write-Log "Storage Account: $(Get-MaskedValue $StorageAccountName)"
    Write-Log "=========================================="

    # Validate all required parameters
    $requiredParams = @{
        "TenantId"           = $TenantId
        "ClientId"           = $ClientId
        "KeyVaultName"       = $KeyVaultName
        "CertName"           = $CertName
        "StorageAccountName" = $StorageAccountName
    }

    foreach ($param in $requiredParams.GetEnumerator()) {
        if ([string]::IsNullOrEmpty($param.Value)) {
            throw "Required parameter '$($param.Key)' is not set"
        }
    }

    # Step 2: Get certificate from Key Vault
    Write-Log "Retrieving certificate from Key Vault: $KeyVaultName"
    $certPath = Get-CertificateFromKeyVault -KeyVaultName $KeyVaultName -CertName $CertName
    Write-Log "Certificate retrieved and saved to: $certPath"

    # Step 3: Authenticate to Graph API or Exchange Online
    if ($EntityType -eq "mailboxes") {
        # Exchange Online authentication
        Write-Log "Connecting to Exchange Online..."
        Connect-ToExchangeOnline -TenantId $TenantId -ClientId $ClientId -CertPath $certPath -Organization $script:Organization
        Write-Log "Exchange Online connection established"
    }
    else {
        # Graph API authentication
        Write-Log "Connecting to Microsoft Graph..."
        Connect-ToGraph -TenantId $TenantId -ClientId $ClientId -CertPath $certPath
        Write-Log "Graph API connection established"
    }

    # Step 4: Fetch data
    Write-Log "Fetching $EntityType data..."
    $data = switch ($EntityType) {
        "users" { Get-GraphUsers }
        "contacts" { Get-GraphContacts }
        "groups" { Get-GraphGroups }
        "group_members" { Get-GraphGroupMembers }
        "mailboxes" { Get-ExoMailboxes }
        "onedrive" { Get-GraphOneDriveSites }
        "sharepoint" { Get-GraphSharePointSites }
        default { throw "Unknown entity type: $EntityType" }
    }

    $countSource = if ($EntityType -eq "onedrive" -and $data -is [hashtable] -and $data.ContainsKey("sites")) { $data["sites"] } else { $data }
    $recordCount = ($countSource | Measure-Object).Count
    Write-Log "Fetched $recordCount records"

    # Step 5: Write to ADLS (always write, even with 0 records, so DLT has schema)
    $date = Get-Date -Format "yyyy-MM-dd"
    $timestamp = Get-Date -Format "HHmmss"
    
    # Map entity type to folder name
    $folderMap = @{
        "users"         = "entra_users"
        "contacts"      = "entra_contacts"
        "groups"        = "entra_groups"
        "group_members" = "entra_group_members"
        "mailboxes"     = "exo_mailboxes"
        "onedrive"      = "onedrive_sites"
        "sharepoint"    = "sharepoint_sites"
    }
    $folderName = $folderMap[$EntityType]
    
    $blobPath = "raw/$folderName/$Environment/$date/$($EntityType)_$($timestamp).json"
    
    Write-Log "Writing data to ADLS: $ContainerName/$blobPath (records: $recordCount)"
    Write-ToAdls -StorageAccountName $StorageAccountName `
                 -ContainerName $ContainerName `
                 -BlobPath $blobPath `
                 -Data $data `
                 -BatchId $script:BatchId `
                 -TenantId $TenantId `
                 -TenantName $TenantName `
                 -EntityType $folderName `
                 -Environment $Environment
    
    Write-Log "Data written successfully"

    # Step 6: Cleanup connections
    Write-Log "Cleaning up..."
    if ($EntityType -eq "mailboxes") {
        Disconnect-ExchangeOnline -Confirm:$false -ErrorAction SilentlyContinue
    }
    else {
        Disconnect-MgGraph -ErrorAction SilentlyContinue
    }

    # Output stats
    $stats = Get-IngestionStats -RecordCount $recordCount -Status "success"
    Write-Log "=========================================="
    Write-Log "Ingestion completed successfully"
    Write-Log "Records: $recordCount"
    Write-Log "Duration: $($stats.duration_seconds) seconds"
    Write-Log "=========================================="
    
    # Output JSON for ADF/ACA to capture
    $stats | ConvertTo-Json -Compress | Write-Output
    
    exit 0
}
catch {
    $errorMessage = $_.Exception.Message
    Write-Log "FAILED: $errorMessage" -Level "ERROR"
    Write-Log $_.ScriptStackTrace -Level "ERROR"
    
    $stats = Get-IngestionStats -RecordCount 0 -Status "failed" -ErrorMessage $errorMessage
    $stats | ConvertTo-Json -Compress | Write-Output
    
    exit 1
}
finally {
    # Always clean up the certificate file - it contains sensitive key material
    if ($certPath -and (Test-Path $certPath -ErrorAction SilentlyContinue)) {
        try {
            Remove-Item $certPath -Force -ErrorAction Stop
            Write-Log "Temporary certificate file cleaned up"
        }
        catch {
            Write-Log "WARNING: Failed to remove temporary certificate file at '$certPath'. Manual removal recommended." -Level "WARN"
        }
    }
}
