<#
.SYNOPSIS
    Key Vault helper functions for certificate retrieval.
#>

function Get-CertificateFromKeyVault {
    <#
    .SYNOPSIS
        Retrieves a certificate from Azure Key Vault and saves it locally.
    
    .PARAMETER KeyVaultName
        Name of the Key Vault.
    
    .PARAMETER CertName
        Name of the certificate in Key Vault.
    
    .PARAMETER CertPassword
        Optional password for the PFX file. Azure Key Vault certificates exported as secrets
        are typically not password-protected, but this parameter supports cases where a 
        password is required.
    
    .PARAMETER ValidateCertificate
        If $true, validates that the certificate can be loaded and has a private key.
        Default is $true. Set to $false to skip validation (not recommended).
    
    .RETURNS
        Path to the temporary certificate file.
    
    .EXAMPLE
        $certPath = Get-CertificateFromKeyVault -KeyVaultName "mykeyvault" -CertName "mycert"
    
    .EXAMPLE
        $certPath = Get-CertificateFromKeyVault -KeyVaultName "mykeyvault" -CertName "mycert" -CertPassword (ConvertTo-SecureString "pass" -AsPlainText -Force)
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$KeyVaultName,
        
        [Parameter(Mandatory = $true)]
        [string]$CertName,
        
        [Parameter(Mandatory = $false)]
        [SecureString]$CertPassword = $null,
        
        [Parameter(Mandatory = $false)]
        [bool]$ValidateCertificate = $true
    )
    
    $certPath = $null
    $success = $false
    
    try {
        # Get certificate metadata first to verify it exists
        $cert = Get-AzKeyVaultCertificate -VaultName $KeyVaultName -Name $CertName
        
        if ($null -eq $cert) {
            throw "Certificate '$CertName' not found in Key Vault '$KeyVaultName'"
        }
        
        Write-Verbose "Certificate found. Thumbprint: $($cert.Thumbprint), Expires: $($cert.Expires)"
        
        # Check if certificate is expired or expiring soon
        $daysUntilExpiry = ($cert.Expires - (Get-Date)).Days
        if ($daysUntilExpiry -lt 0) {
            throw "Certificate '$CertName' has expired on $($cert.Expires)"
        }
        elseif ($daysUntilExpiry -lt 30) {
            Write-Warning "Certificate '$CertName' will expire in $daysUntilExpiry days on $($cert.Expires)"
        }
        
        # Get the secret (contains the PFX with private key)
        $secret = Get-AzKeyVaultSecret -VaultName $KeyVaultName -Name $CertName -AsPlainText
        
        if ([string]::IsNullOrEmpty($secret)) {
            throw "Failed to retrieve certificate secret from Key Vault. The secret may be empty or access may be denied."
        }
        
        # Decode Base64 to bytes
        try {
            $certBytes = [Convert]::FromBase64String($secret)
        }
        catch {
            throw "Failed to decode certificate from Base64. The certificate secret may be corrupted or in an unexpected format."
        }
        
        # Validate minimum size for a PFX file (should be at least a few hundred bytes)
        if ($certBytes.Length -lt 100) {
            throw "Certificate data appears invalid (size: $($certBytes.Length) bytes). Expected a valid PFX file."
        }
        
        # Use /tmp for Linux containers, TEMP for Windows
        $tempDir = if ([System.Environment]::GetEnvironmentVariable('TEMP')) { [System.Environment]::GetEnvironmentVariable('TEMP') } else { '/tmp' }
        $certPath = Join-Path $tempDir "$CertName.pfx"
        
        [System.IO.File]::WriteAllBytes($certPath, $certBytes)
        Write-Verbose "Certificate saved to: $certPath (Size: $($certBytes.Length) bytes)"
        
        # Validate the certificate if requested
        if ($ValidateCertificate) {
            Write-Verbose "Validating certificate..."
            try {
                $flags = [System.Security.Cryptography.X509Certificates.X509KeyStorageFlags]::Exportable -bor `
                         [System.Security.Cryptography.X509Certificates.X509KeyStorageFlags]::MachineKeySet
                
                # Try to load the certificate (with password if provided)
                if ($CertPassword) {
                    $testCert = [System.Security.Cryptography.X509Certificates.X509Certificate2]::new($certPath, $CertPassword, $flags)
                }
                else {
                    # Try without password first (Azure KV exports typically don't have passwords)
                    try {
                        $testCert = [System.Security.Cryptography.X509Certificates.X509Certificate2]::new($certPath, $null, $flags)
                    }
                    catch {
                        # If that fails, it might need a password
                        if ($_.Exception.Message -match "password|incorrect|invalid") {
                            throw "Certificate appears to be password-protected. Please provide the password using the -CertPassword parameter."
                        }
                        throw
                    }
                }
                
                # Verify the certificate has a private key (required for authentication)
                if (-not $testCert.HasPrivateKey) {
                    throw "Certificate does not contain a private key. Ensure the certificate was uploaded to Key Vault with its private key."
                }
                
                Write-Verbose "Certificate validated successfully:"
                Write-Verbose "  Subject: $($testCert.Subject)"
                Write-Verbose "  Issuer: $($testCert.Issuer)"
                Write-Verbose "  Thumbprint: $($testCert.Thumbprint)"
                Write-Verbose "  Has Private Key: $($testCert.HasPrivateKey)"
                Write-Verbose "  Not Before: $($testCert.NotBefore)"
                Write-Verbose "  Not After: $($testCert.NotAfter)"
            }
            catch {
                throw "Certificate validation failed: $($_.Exception.Message)"
            }
            finally {
                # Dispose of test certificate object
                if ($testCert) { 
                    $testCert.Dispose()
                    $testCert = $null
                }
            }
        }
        
        # Mark as successful - caller is now responsible for cleanup
        $success = $true
        
        return $certPath
    }
    catch {
        throw "Failed to retrieve certificate from Key Vault: $($_.Exception.Message)"
    }
    finally {
        # Clean up sensitive certificate file if an error occurred after it was written
        if (-not $success -and $certPath -and (Test-Path $certPath -ErrorAction SilentlyContinue)) {
            try {
                # Securely delete by overwriting with zeros before removal
                $fileInfo = [System.IO.FileInfo]::new($certPath)
                $length = $fileInfo.Length
                [System.IO.File]::WriteAllBytes($certPath, [byte[]]::new($length))
                Remove-Item $certPath -Force -ErrorAction SilentlyContinue
                Write-Verbose "Cleaned up temporary certificate file after error"
            }
            catch {
                Write-Warning "Failed to clean up temporary certificate file at '$certPath'. Manual removal recommended."
            }
        }
        
        # Clear sensitive data from memory
        if ($secret) { $secret = $null }
        if ($certBytes) { $certBytes = $null }
    }
}

function Get-SecretFromKeyVault {
    <#
    .SYNOPSIS
        Retrieves a plain text secret from Azure Key Vault.
    
    .PARAMETER KeyVaultName
        Name of the Key Vault.
    
    .PARAMETER SecretName
        Name of the secret to retrieve.
    
    .RETURNS
        The secret value as plain text.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$KeyVaultName,
        
        [Parameter(Mandatory = $true)]
        [string]$SecretName
    )
    
    try {
        $secretValue = Get-AzKeyVaultSecret -VaultName $KeyVaultName -Name $SecretName -AsPlainText
        
        if ([string]::IsNullOrEmpty($secretValue)) {
            throw "Secret '$SecretName' not found or is empty in Key Vault '$KeyVaultName'"
        }
        
        return $secretValue
    }
    catch {
        throw "Failed to retrieve secret '$SecretName' from Key Vault: $($_.Exception.Message)"
    }
}

function Get-EnvironmentConfigFromKeyVault {
    <#
    .SYNOPSIS
        Retrieves environment configuration from Azure Key Vault.
    
    .DESCRIPTION
        Fetches config-source or config-target secret from Key Vault and
        parses it as JSON. Handles both PascalCase and camelCase property names.
    
    .PARAMETER KeyVaultName
        Name of the Key Vault.
    
    .PARAMETER Environment
        Environment name: 'source' or 'target'
    
    .RETURNS
        Hashtable with TenantId, ClientId, CertName, Organization, and TenantName.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$KeyVaultName,
        
        [Parameter(Mandatory = $true)]
        [ValidateSet("source", "target")]
        [string]$Environment
    )
    
    try {
        $secretName = "config-$Environment"
        $configJson = Get-AzKeyVaultSecret -VaultName $KeyVaultName -Name $secretName -AsPlainText
        
        if ([string]::IsNullOrEmpty($configJson)) {
            throw "Configuration secret '$secretName' not found or is empty in Key Vault '$KeyVaultName'"
        }
        
        $config = $configJson | ConvertFrom-Json
        
        # Handle both PascalCase and camelCase property names
        $result = @{
            TenantId     = if ($config.TenantId) { $config.TenantId } else { $config.tenantId }
            ClientId     = if ($config.ClientId) { $config.ClientId } else { $config.clientId }
            CertName     = if ($config.CertName) { $config.CertName } else { $config.certName }
            Organization = if ($config.Organization) { $config.Organization } else { $config.organization }
            TenantName   = if ($config.TenantName) { $config.TenantName } else { $config.tenantName }
        }
        
        # Validate required fields
        if ([string]::IsNullOrEmpty($result.TenantId)) {
            throw "TenantId is missing from '$secretName' configuration"
        }
        if ([string]::IsNullOrEmpty($result.ClientId)) {
            throw "ClientId is missing from '$secretName' configuration"
        }
        if ([string]::IsNullOrEmpty($result.CertName)) {
            throw "CertName is missing from '$secretName' configuration"
        }
        
        return $result
    }
    catch {
        throw "Failed to retrieve environment config from Key Vault: $($_.Exception.Message)"
    }
}

Export-ModuleMember -Function Get-CertificateFromKeyVault, Get-SecretFromKeyVault, Get-EnvironmentConfigFromKeyVault
