<#
.SYNOPSIS
    Graph API and Exchange Online helper functions for data retrieval.
#>

function ConvertTo-SizeMB {
    <#
    .SYNOPSIS
        Converts Exchange Online size objects or strings to megabytes.
    
    .DESCRIPTION
        Attempts multiple methods to extract size in MB:
        1. Native .Value.ToMB() method (preferred for Exchange Online ByteQuantifiedSize)
        2. .Value property in bytes (divide by 1MB)
        3. String parsing with robust regex for formats like "1.5 GB (1,610,612,736 bytes)"
        
        Handles various locale formats, whitespace variations, and alternate representations.
    
    .PARAMETER SizeObject
        The size object from Exchange Online (e.g., $stats.TotalItemSize)
    
    .RETURNS
        Size in megabytes as a double, or 0 if parsing fails.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false)]
        [object]$SizeObject
    )
    
    if (-not $SizeObject) {
        return 0
    }
    
    try {
        # Method 1: Try native ToMB() method (ByteQuantifiedSize objects)
        if ($SizeObject.Value -and $SizeObject.Value.PSObject.Methods.Name -contains 'ToMB') {
            return [double]$SizeObject.Value.ToMB()
        }
        
        # Method 2: Try .Value property as bytes
        if ($SizeObject.Value -is [long] -or $SizeObject.Value -is [int64]) {
            return [double]$SizeObject.Value / 1MB
        }
        
        # Method 3: Parse from string representation
        $sizeString = $SizeObject.ToString()
        
        # Handle format like "1.5 GB (1,610,612,736 bytes)" - extract bytes from parentheses first
        if ($sizeString -match '\(([\d,\.]+)\s*bytes\)') {
            $bytesString = $matches[1] -replace '[,\s]', ''  # Remove commas and spaces
            if ([double]::TryParse($bytesString, [ref]$null)) {
                return [double]$bytesString / 1MB
            }
        }
        
        # Handle simple format like "1.5 GB" or "1,500 MB" (with locale variations)
        # Normalize: remove commas, handle both . and , as decimal separators
        $normalizedString = $sizeString.Trim()
        
        # Match pattern: number (with optional decimal) followed by unit
        # Handles: "1.5 GB", "1,5 GB" (European), "1500 MB", "1,500.5 MB"
        if ($normalizedString -match '^([\d,\.\s]+)\s*(KB|MB|GB|TB|B)\b') {
            $valueString = $matches[1].Trim() -replace '\s', ''  # Remove internal spaces
            $unit = $matches[2].ToUpper()
            
            # Handle European decimal format (comma as decimal separator)
            # If there's exactly one comma and no period, treat comma as decimal
            if ($valueString -match '^\d+,\d+$' -and $valueString -notmatch '\.') {
                $valueString = $valueString -replace ',', '.'
            }
            else {
                # Remove thousand separators (commas)
                $valueString = $valueString -replace ',', ''
            }
            
            $value = 0.0
            if ([double]::TryParse($valueString, [System.Globalization.NumberStyles]::Any, 
                [System.Globalization.CultureInfo]::InvariantCulture, [ref]$value)) {
                
                $result = switch ($unit) {
                    "B"  { $value / 1MB }
                    "KB" { $value / 1024 }
                    "MB" { $value }
                    "GB" { $value * 1024 }
                    "TB" { $value * 1024 * 1024 }
                    default { 0 }
                }
                return $result
            }
        }
        
        Write-Warning "Could not parse size from: $sizeString"
        return 0
    }
    catch {
        Write-Warning "Error converting size '$SizeObject': $($_.Exception.Message)"
        return 0
    }
}

function Connect-ToGraph {
    <#
    .SYNOPSIS
        Connects to Microsoft Graph using certificate authentication.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$TenantId,
        
        [Parameter(Mandatory = $true)]
        [string]$ClientId,
        
        [Parameter(Mandatory = $true)]
        [string]$CertPath
    )
    
    try {
        # Load certificate
        $cert = [System.Security.Cryptography.X509Certificates.X509Certificate2]::new($CertPath)
        
        # Connect to Graph
        Connect-MgGraph -TenantId $TenantId -ClientId $ClientId -Certificate $cert -NoWelcome
    }
    catch {
        throw "Failed to connect to Microsoft Graph: $($_.Exception.Message)"
    }
}

function Connect-ToExchangeOnline {
    <#
    .SYNOPSIS
        Connects to Exchange Online using certificate authentication.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$TenantId,
        
        [Parameter(Mandatory = $true)]
        [string]$ClientId,
        
        [Parameter(Mandatory = $true)]
        [string]$CertPath
    )
    
    try {
        # Load certificate
        $cert = [System.Security.Cryptography.X509Certificates.X509Certificate2]::new($CertPath)
        
        # Connect to EXO
        Connect-ExchangeOnline -CertificateThumbprint $cert.Thumbprint `
                               -AppId $ClientId `
                               -Organization "$TenantId.onmicrosoft.com" `
                               -ShowBanner:$false
    }
    catch {
        throw "Failed to connect to Exchange Online: $($_.Exception.Message)"
    }
}

function Get-GraphUsers {
    <#
    .SYNOPSIS
        Retrieves all users from Entra ID via Graph API.
    #>
    [CmdletBinding()]
    param()
    
    $users = @()
    $select = @(
        "id",
        "userPrincipalName",
        "displayName",
        "givenName",
        "surname",
        "mail",
        "proxyAddresses",
        "jobTitle",
        "department",
        "officeLocation",
        "companyName",
        "employeeId",
        "userType",
        "accountEnabled",
        "assignedLicenses",
        "createdDateTime",
        # On-premises sync attributes (critical for hybrid/migration)
        "onPremisesSamAccountName",
        "onPremisesImmutableId",
        "onPremisesDistinguishedName",
        "onPremisesSecurityIdentifier",
        "onPremisesSyncEnabled",
        "onPremisesLastSyncDateTime",
        "onPremisesDomainName",
        # Additional useful fields
        "mobilePhone",
        "businessPhones",
        "usageLocation",
        "preferredLanguage",
        "lastPasswordChangeDateTime"
    )
    
    try {
        # Get all users with pagination
        $uri = "https://graph.microsoft.com/v1.0/users?`$select=$($select -join ',')"
        
        do {
            $response = Invoke-MgGraphRequest -Method GET -Uri $uri
            $users += $response.value
            $uri = $response.'@odata.nextLink'
            
            Write-Host "  Fetched $($users.Count) users so far..."
        } while ($uri)
        
        return $users
    }
    catch {
        throw "Failed to get users: $($_.Exception.Message)"
    }
}

function Get-GraphContacts {
    <#
    .SYNOPSIS
        Retrieves all organizational contacts from Entra ID.
    #>
    [CmdletBinding()]
    param()
    
    $contacts = @()
    $select = @(
        "id",
        "displayName",
        "givenName",
        "surname",
        "mail",
        "proxyAddresses",
        "companyName",
        "department",
        "jobTitle"
    )
    
    try {
        $uri = "https://graph.microsoft.com/v1.0/contacts?`$select=$($select -join ',')"
        
        do {
            $response = Invoke-MgGraphRequest -Method GET -Uri $uri
            $contacts += $response.value
            $uri = $response.'@odata.nextLink'
            
            Write-Host "  Fetched $($contacts.Count) contacts so far..."
        } while ($uri)
        
        return $contacts
    }
    catch {
        throw "Failed to get contacts: $($_.Exception.Message)"
    }
}

function Get-GraphGroups {
    <#
    .SYNOPSIS
        Retrieves all groups from Entra ID.
    #>
    [CmdletBinding()]
    param()
    
    $groups = @()
    $select = @(
        "id",
        "displayName",
        "description",
        "mail",
        "mailEnabled",
        "securityEnabled",
        "proxyAddresses",
        "groupTypes",
        "membershipRule",
        "createdDateTime"
    )
    
    try {
        $uri = "https://graph.microsoft.com/v1.0/groups?`$select=$($select -join ',')"
        
        do {
            $response = Invoke-MgGraphRequest -Method GET -Uri $uri
            $groups += $response.value
            $uri = $response.'@odata.nextLink'
            
            Write-Host "  Fetched $($groups.Count) groups so far..."
        } while ($uri)
        
        return $groups
    }
    catch {
        throw "Failed to get groups: $($_.Exception.Message)"
    }
}

function Get-GraphGroupMembers {
    <#
    .SYNOPSIS
        Retrieves all group memberships.
    #>
    [CmdletBinding()]
    param()
    
    $memberships = @()
    
    try {
        # First get all groups
        $groups = Get-GraphGroups
        $totalGroups = $groups.Count
        $current = 0
        
        foreach ($group in $groups) {
            $current++
            Write-Host "  Processing group $current of ${totalGroups}: $($group.displayName)"
            
            # Note: Don't use $select with @odata.type - it causes BadRequest errors
            # The members endpoint returns the type by default
            $uri = "https://graph.microsoft.com/v1.0/groups/$($group.id)/members"
            
            do {
                $response = Invoke-MgGraphRequest -Method GET -Uri $uri
                
                foreach ($member in $response.value) {
                    $memberType = switch ($member.'@odata.type') {
                        "#microsoft.graph.user" { "user" }
                        "#microsoft.graph.group" { "group" }
                        "#microsoft.graph.servicePrincipal" { "servicePrincipal" }
                        "#microsoft.graph.orgContact" { "contact" }
                        default { "unknown" }
                    }
                    
                    $memberships += @{
                        group_id    = $group.id
                        member_id   = $member.id
                        member_type = $memberType
                    }
                }
                
                $uri = $response.'@odata.nextLink'
            } while ($uri)
        }
        
        return $memberships
    }
    catch {
        throw "Failed to get group members: $($_.Exception.Message)"
    }
}

function Get-GraphOneDriveSites {
    <#
    .SYNOPSIS
        Retrieves OneDrive site information for all users.
    
    .DESCRIPTION
        Iterates through all member users and retrieves their OneDrive information.
        Users without OneDrive provisioned are tracked and summarized at the end.
    
    .OUTPUTS
        Returns a hashtable with:
        - sites: Array of OneDrive site information
        - skipped: Array of users that were skipped with error details
        - summary: Statistics about the retrieval operation
    #>
    [CmdletBinding()]
    param()
    
    $sites = @()
    $skippedUsers = @()
    $errorCategories = @{}
    
    try {
        # Get all users first
        $users = Get-GraphUsers | Where-Object { $_.userType -eq "Member" }
        $totalUsers = $users.Count
        $current = 0
        
        Write-Host "  Processing OneDrive for $totalUsers users..."
        
        foreach ($user in $users) {
            $current++
            
            try {
                $uri = "https://graph.microsoft.com/v1.0/users/$($user.id)/drive"
                $drive = Invoke-MgGraphRequest -Method GET -Uri $uri
                
                $sites += @{
                    id                   = $drive.id
                    webUrl               = $drive.webUrl
                    owner_id             = $user.id
                    owner_email          = $user.mail
                    quota_used           = $drive.quota.used
                    quota_total          = $drive.quota.total
                    lastModifiedDateTime = $drive.lastModifiedDateTime
                    createdDateTime      = $drive.createdDateTime
                }
                
                if ($current % 100 -eq 0) {
                    Write-Host "  Processed $current of $totalUsers users..."
                }
            }
            catch {
                # Categorize the error for summary reporting
                $errorMessage = $_.Exception.Message
                $errorCategory = switch -Regex ($errorMessage) {
                    "itemNotFound|does not exist"   { "OneDrive not provisioned" }
                    "accessDenied|Forbidden|403"    { "Access denied" }
                    "notAllowed"                    { "Not allowed" }
                    "invalidRequest|BadRequest|400" { "Invalid request" }
                    "throttl|429|Too Many"          { "Throttled" }
                    "ServiceUnavailable|503"        { "Service unavailable" }
                    default                         { "Other error" }
                }
                
                # Track for summary
                if (-not $errorCategories.ContainsKey($errorCategory)) {
                    $errorCategories[$errorCategory] = 0
                }
                $errorCategories[$errorCategory]++
                
                # Store details for troubleshooting (limit stored errors to prevent memory issues)
                if ($skippedUsers.Count -lt 1000) {
                    $skippedUsers += @{
                        user_id       = $user.id
                        user_email    = $user.mail
                        user_upn      = $user.userPrincipalName
                        error_category = $errorCategory
                        error_message = $errorMessage.Substring(0, [math]::Min($errorMessage.Length, 200))
                    }
                }
                
                # Log throttling errors as warnings (may need intervention)
                if ($errorCategory -eq "Throttled") {
                    Write-Warning "Throttled while fetching OneDrive for user $($user.userPrincipalName). Consider adding delays."
                }
                
                continue
            }
        }
        
        # Log summary of skipped users
        $totalSkipped = ($errorCategories.Values | Measure-Object -Sum).Sum
        if ($totalSkipped -gt 0) {
            Write-Host ""
            Write-Host "  OneDrive retrieval summary:"
            Write-Host "    - Successfully retrieved: $($sites.Count)"
            Write-Host "    - Skipped: $totalSkipped"
            foreach ($category in $errorCategories.Keys | Sort-Object) {
                Write-Host "      - $category : $($errorCategories[$category])"
            }
            
            # Warn if significant number of access denied errors (may indicate permission issue)
            if ($errorCategories["Access denied"] -gt 10) {
                Write-Warning "Multiple 'Access denied' errors detected. Verify the application has Sites.Read.All or Files.Read.All permissions."
            }
        }
        
        # Return structured result with both data and diagnostics
        return @{
            sites   = $sites
            skipped = $skippedUsers
            summary = @{
                total_users       = $totalUsers
                successful        = $sites.Count
                skipped           = $totalSkipped
                error_categories  = $errorCategories
            }
        }
    }
    catch {
        throw "Failed to get OneDrive sites: $($_.Exception.Message)"
    }
}

function Get-GraphSharePointSites {
    <#
    .SYNOPSIS
        Retrieves all SharePoint sites.
    #>
    [CmdletBinding()]
    param()
    
    $sites = @()
    
    try {
        # Use the sites/getAllSites endpoint which properly returns all sites
        # This requires Sites.Read.All permission
        $uri = 'https://graph.microsoft.com/v1.0/sites/getAllSites'
        
        do {
            $response = Invoke-MgGraphRequest -Method GET -Uri $uri
            
            foreach ($site in $response.value) {
                $sites += [PSCustomObject]@{
                    id                   = $site.id
                    name                 = $site.name
                    displayName          = $site.displayName
                    webUrl               = $site.webUrl
                    createdDateTime      = $site.createdDateTime
                    lastModifiedDateTime = $site.lastModifiedDateTime
                    siteCollection       = $site.siteCollection
                    root                 = $site.root
                }
            }
            
            $uri = $response.'@odata.nextLink'
            
            Write-Host "  Fetched $($sites.Count) SharePoint sites so far..."
        } while ($uri)
        
        return $sites
    }
    catch {
        throw "Failed to get SharePoint sites: $($_.Exception.Message)"
    }
}

function Get-ExoMailboxes {
    <#
    .SYNOPSIS
        Retrieves all mailboxes from Exchange Online with statistics.
    
    .DESCRIPTION
        Fetches mailboxes and their statistics efficiently using bulk operations
        to minimize API calls and avoid throttling in large tenants.
    
    .PARAMETER BatchSize
        Number of mailboxes to process in each batch for statistics retrieval.
        Default is 100. Smaller values reduce memory usage but increase API calls.
    
    .PARAMETER ThrottleRetryCount
        Number of times to retry on throttling errors. Default is 3.
    
    .PARAMETER ThrottleRetryDelaySeconds
        Base delay in seconds between retries (uses exponential backoff). Default is 30.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $false)]
        [int]$BatchSize = 100,
        
        [Parameter(Mandatory = $false)]
        [int]$ThrottleRetryCount = 3,
        
        [Parameter(Mandatory = $false)]
        [int]$ThrottleRetryDelaySeconds = 30
    )
    
    $mailboxes = @()
    
    try {
        Write-Host "  Fetching mailboxes..."
        $exoMailboxes = Get-EXOMailbox -ResultSize Unlimited -PropertySets All
        $totalMailboxes = $exoMailboxes.Count
        Write-Host "  Found $totalMailboxes mailboxes"
        
        # Fetch all mailbox statistics in bulk (much more efficient than individual calls)
        Write-Host "  Fetching mailbox statistics in bulk..."
        $allStats = @{}
        $retryCount = 0
        
        while ($retryCount -le $ThrottleRetryCount) {
            try {
                # Get-EXOMailboxStatistics can accept pipeline input for bulk retrieval
                $statsResults = $exoMailboxes | Get-EXOMailboxStatistics -ErrorAction SilentlyContinue
                
                # Build lookup hashtable by MailboxGuid for O(1) access
                foreach ($stat in $statsResults) {
                    if ($stat.MailboxGuid) {
                        $allStats[$stat.MailboxGuid.ToString()] = $stat
                    }
                }
                Write-Host "  Retrieved statistics for $($allStats.Count) mailboxes"
                break
            }
            catch {
                if ($_.Exception.Message -match "throttl" -or $_.Exception.Message -match "too many requests") {
                    $retryCount++
                    if ($retryCount -le $ThrottleRetryCount) {
                        $delay = $ThrottleRetryDelaySeconds * [math]::Pow(2, $retryCount - 1)
                        Write-Warning "Throttling detected. Waiting $delay seconds before retry $retryCount of $ThrottleRetryCount..."
                        Start-Sleep -Seconds $delay
                    }
                    else {
                        throw "Exceeded maximum retry count due to throttling: $($_.Exception.Message)"
                    }
                }
                else {
                    throw
                }
            }
        }
        
        # Fetch archive statistics in bulk for mailboxes with active archives
        Write-Host "  Fetching archive statistics..."
        $archiveStats = @{}
        $archiveMailboxes = $exoMailboxes | Where-Object { $_.ArchiveStatus -eq "Active" }
        
        if ($archiveMailboxes.Count -gt 0) {
            Write-Host "  Found $($archiveMailboxes.Count) mailboxes with archives"
            
            # Process archives in batches to manage memory and reduce throttling risk
            $archiveBatches = [System.Collections.ArrayList]@()
            for ($i = 0; $i -lt $archiveMailboxes.Count; $i += $BatchSize) {
                $batch = $archiveMailboxes[$i..[math]::Min($i + $BatchSize - 1, $archiveMailboxes.Count - 1)]
                [void]$archiveBatches.Add($batch)
            }
            
            $batchNum = 0
            foreach ($batch in $archiveBatches) {
                $batchNum++
                $retryCount = 0
                
                while ($retryCount -le $ThrottleRetryCount) {
                    try {
                        $archiveResults = $batch | Get-EXOMailboxStatistics -Archive -ErrorAction SilentlyContinue
                        
                        foreach ($stat in $archiveResults) {
                            if ($stat.MailboxGuid) {
                                $archiveStats[$stat.MailboxGuid.ToString()] = $stat
                            }
                        }
                        
                        Write-Host "  Processed archive batch $batchNum of $($archiveBatches.Count)..."
                        break
                    }
                    catch {
                        if ($_.Exception.Message -match "throttl" -or $_.Exception.Message -match "too many requests") {
                            $retryCount++
                            if ($retryCount -le $ThrottleRetryCount) {
                                $delay = $ThrottleRetryDelaySeconds * [math]::Pow(2, $retryCount - 1)
                                Write-Warning "Throttling detected on archive batch. Waiting $delay seconds before retry..."
                                Start-Sleep -Seconds $delay
                            }
                            else {
                                Write-Warning "Exceeded retry count for archive batch $batchNum. Continuing with partial data."
                                break
                            }
                        }
                        else {
                            Write-Warning "Error fetching archive stats for batch $batchNum : $($_.Exception.Message)"
                            break
                        }
                    }
                }
            }
        }
        
        # Build final results using the pre-fetched statistics
        Write-Host "  Building mailbox records..."
        $current = 0
        
        foreach ($mbx in $exoMailboxes) {
            $current++
            
            # Look up pre-fetched statistics
            $stats = $allStats[$mbx.ExchangeGuid.ToString()]
            $archiveStat = $archiveStats[$mbx.ExchangeGuid.ToString()]
            
            # Convert sizes to MB using robust helper
            $totalSizeMB = ConvertTo-SizeMB -SizeObject $stats.TotalItemSize
            $archiveSizeMB = if ($archiveStat) { ConvertTo-SizeMB -SizeObject $archiveStat.TotalItemSize } else { 0 }
            
            $mailboxes += @{
                ExchangeGuid         = $mbx.ExchangeGuid.ToString()
                UserPrincipalName    = $mbx.UserPrincipalName
                PrimarySmtpAddress   = $mbx.PrimarySmtpAddress
                EmailAddresses       = $mbx.EmailAddresses
                DisplayName          = $mbx.DisplayName
                RecipientTypeDetails = $mbx.RecipientTypeDetails
                TotalItemSize_MB     = [math]::Round($totalSizeMB, 2)
                ItemCount            = if ($stats) { $stats.ItemCount } else { 0 }
                DeletedItemCount     = if ($stats) { $stats.DeletedItemCount } else { 0 }
                ArchiveStatus        = $mbx.ArchiveStatus
                ArchiveGuid          = if ($mbx.ArchiveGuid) { $mbx.ArchiveGuid.ToString() } else { $null }
                ArchiveSize_MB       = [math]::Round($archiveSizeMB, 2)
                LitigationHoldEnabled = $mbx.LitigationHoldEnabled
                InPlaceHolds         = $mbx.InPlaceHolds
            }
            
            if ($current % 500 -eq 0) {
                Write-Host "  Built $current of $totalMailboxes mailbox records..."
            }
        }
        
        Write-Host "  Completed processing $totalMailboxes mailboxes"
        return $mailboxes
    }
    catch {
        throw "Failed to get mailboxes: $($_.Exception.Message)"
    }
}

Export-ModuleMember -Function @(
    "Connect-ToGraph",
    "Connect-ToExchangeOnline",
    "Get-GraphUsers",
    "Get-GraphContacts",
    "Get-GraphGroups",
    "Get-GraphGroupMembers",
    "Get-GraphOneDriveSites",
    "Get-GraphSharePointSites",
    "Get-ExoMailboxes"
)
