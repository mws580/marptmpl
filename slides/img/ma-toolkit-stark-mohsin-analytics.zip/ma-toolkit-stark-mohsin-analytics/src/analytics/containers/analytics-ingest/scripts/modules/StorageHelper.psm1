<#
.SYNOPSIS
    Storage helper functions for writing to ADLS Gen2.
#>

function Write-ToAdls {
    <#
    .SYNOPSIS
        Writes data as JSON to Azure Data Lake Storage Gen2.
    
    .PARAMETER StorageAccountName
        Name of the storage account.
    
    .PARAMETER ContainerName
        Name of the container (e.g., 'bronze').
    
    .PARAMETER BlobPath
        Path within the container (e.g., 'raw/entra_users/source/2026-01-21/users.json').
    
    .PARAMETER Data
        Data to write (will be converted to JSON).
    
    .PARAMETER BatchId
        Batch identifier for tracking.

    .PARAMETER CompressJson
        Whether to compress JSON output (removes whitespace). Default is $true for smaller file sizes.
        Set to $false for human-readable output useful during development/debugging.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$StorageAccountName,
        
        [Parameter(Mandatory = $true)]
        [string]$ContainerName,
        
        [Parameter(Mandatory = $true)]
        [string]$BlobPath,
        
        [Parameter(Mandatory = $true)]
        [object]$Data,
        
        [Parameter(Mandatory = $false)]
        [string]$BatchId = [guid]::NewGuid().ToString(),

        [Parameter(Mandatory = $false)]
        [string]$TenantId = "",

        [Parameter(Mandatory = $false)]
        [string]$TenantName = "",

        [Parameter(Mandatory = $false)]
        [string]$EntityType = "",

        [Parameter(Mandatory = $false)]
        [string]$Environment = "",

        [Parameter(Mandatory = $false)]
        [bool]$CompressJson = $true
    )
    
    try {
        # Get storage context using Managed Identity
        $context = New-AzStorageContext -StorageAccountName $StorageAccountName -UseConnectedAccount
        
        # Ensure container exists
        $container = Get-AzStorageContainer -Name $ContainerName -Context $context -ErrorAction SilentlyContinue
        if (-not $container) {
            throw "Container '$ContainerName' not found in storage account '$StorageAccountName'"
        }
        
        # Prepare data with metadata wrapper
        $wrapper = @{
            batch_id     = $BatchId
            tenant_id    = $TenantId
            tenant_name  = $TenantName
            entity_type  = $EntityType
            environment  = $Environment
            ingested_at  = (Get-Date).ToString("o")
            record_count = ($Data | Measure-Object).Count
            data         = $Data
        }
        
        # Convert to JSON
        $jsonParams = @{
            Depth = 20
        }
        if ($CompressJson) {
            $jsonParams.Compress = $true
        }
        $json = $wrapper | ConvertTo-Json @jsonParams

        # Write to temp file first (required for upload)
        # Use BatchId + timestamp + random suffix for uniqueness to avoid collisions
        $tempDir = if ([System.Environment]::GetEnvironmentVariable('TEMP')) { [System.Environment]::GetEnvironmentVariable('TEMP') } else { '/tmp' }
        $timestamp = (Get-Date).ToString("yyyyMMddHHmmssfff")
        $randomSuffix = [System.IO.Path]::GetRandomFileName().Split('.')[0]
        $tempFileName = "upload_${BatchId}_${timestamp}_${randomSuffix}.json"
        $tempFile = Join-Path $tempDir $tempFileName
        
        # Additional safety: ensure we don't overwrite an existing file
        $retryCount = 0
        while ((Test-Path $tempFile) -and $retryCount -lt 5) {
            $randomSuffix = [System.IO.Path]::GetRandomFileName().Split('.')[0]
            $tempFileName = "upload_${BatchId}_${timestamp}_${randomSuffix}.json"
            $tempFile = Join-Path $tempDir $tempFileName
            $retryCount++
        }
        
        $json | Out-File -FilePath $tempFile -Encoding UTF8 -Force
        
        # Upload to ADLS
        $blob = Set-AzStorageBlobContent -File $tempFile `
                                         -Container $ContainerName `
                                         -Blob $BlobPath `
                                         -Context $context `
                                         -Force
        
        # Cleanup temp file
        Remove-Item $tempFile -Force -ErrorAction SilentlyContinue
        
        Write-Host "  Uploaded to: $ContainerName/$BlobPath"
        Write-Host "  Records: $(($Data | Measure-Object).Count)"
        Write-Host "  Size: $([math]::Round($blob.Length / 1024, 2)) KB"
        
        return $blob
    }
    catch {
        throw "Failed to write to ADLS: $($_.Exception.Message)"
    }
}

function Test-AdlsConnection {
    <#
    .SYNOPSIS
        Tests connectivity to ADLS storage account.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$StorageAccountName,
        
        [Parameter(Mandatory = $true)]
        [string]$ContainerName
    )
    
    try {
        $context = New-AzStorageContext -StorageAccountName $StorageAccountName -UseConnectedAccount
        $container = Get-AzStorageContainer -Name $ContainerName -Context $context -ErrorAction Stop
        
        return @{
            Success      = $true
            StorageAccount = $StorageAccountName
            Container    = $ContainerName
            Message      = "Connection successful"
        }
    }
    catch {
        return @{
            Success      = $false
            StorageAccount = $StorageAccountName
            Container    = $ContainerName
            Message      = $_.Exception.Message
        }
    }
}

Export-ModuleMember -Function @(
    "Write-ToAdls",
    "Test-AdlsConnection"
)
