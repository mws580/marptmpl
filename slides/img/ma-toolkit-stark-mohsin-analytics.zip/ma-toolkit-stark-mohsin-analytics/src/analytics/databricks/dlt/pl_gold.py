# Databricks notebook source
# MAGIC %md
# MAGIC # M365 Migration - Gold Layer Pipeline
# MAGIC 
# MAGIC **Pipeline:** `pl_m365_gold`  
# MAGIC **Target Schema:** `m365_migration.gold`
# MAGIC 
# MAGIC ## Purpose
# MAGIC Business-ready dimensions, approved mappings, and migration summaries.
# MAGIC 
# MAGIC ## Key Concepts
# MAGIC - **person_map**: Approved mappings with match_context
# MAGIC   - `primary_migration`: Source Member → Target Member
# MAGIC   - `external_linkage`: Source Member → Target External Member
# MAGIC - **dim_people**: Canonical person identity with both linkage types
# MAGIC - **Mapping approval**: Auto-approved if score >= 85

# COMMAND ----------

import dlt
from pyspark.sql.functions import (
    col, current_timestamp, lit, coalesce, when, count, sum as spark_sum,
    row_number, concat_ws, collect_list, collect_set, split, size, expr,
    first, max as spark_max, min as spark_min, array_distinct, flatten,
    to_json, struct
)
from pyspark.sql.window import Window

# COMMAND ----------

# MAGIC %md
# MAGIC ## Configuration

# COMMAND ----------

CATALOG = "m365_migration"
SILVER_SCHEMA = "silver"
GOLD_SCHEMA = "gold"

AUTO_APPROVE_THRESHOLD = 85.0

# COMMAND ----------

# MAGIC %md
# MAGIC ## Gold Tables - User Dimension

# COMMAND ----------

@dlt.table(
    name="dim_users",
    comment="User dimension - enriched user data with mailbox and OneDrive storage sizes",
    table_properties={"quality": "gold", "pipelines.autoOptimize.managed": "true"}
)
def dim_users():
    users = spark.table(f"{CATALOG}.{SILVER_SCHEMA}.users")
    mailboxes = spark.table(f"{CATALOG}.{SILVER_SCHEMA}.mailboxes")
    onedrive = spark.table(f"{CATALOG}.{SILVER_SCHEMA}.onedrive_sites")
    
    users_enriched = (
        users.alias("u")
        .join(
            mailboxes.alias("m"),
            (col("u.environment") == col("m.environment")) & 
            (col("u.mail") == col("m.primary_smtp_address")),
            "left"
        )
        .join(
            onedrive.alias("o"),
            (col("u.environment") == col("o.environment")) & 
            (col("u.mail") == col("o.owner_email")),
            "left"
        )
        .select(
            col("u.user_id"), col("u.environment"), col("u.tenant_name"),
            col("u.entra_object_id"), col("u.user_principal_name"),
            col("u.display_name"), col("u.given_name"), col("u.surname"),
            col("u.mail"), col("u.proxy_addresses"),
            col("u.user_type"), col("u.account_enabled"),
            col("u.employee_id"), col("u.job_title"), col("u.department"),
            col("u.company_name"), col("u.office_location"),
            col("u.has_e3_license"), col("u.has_e5_license"),
            col("u.has_f3_license"), col("u.has_e1_license"),
            col("u.on_prem_immutable_id"), col("u.on_prem_sam_account_name"),
            col("u.on_prem_sync_enabled"),
            col("m.mailbox_id"), col("m.recipient_type_details"),
            col("m.total_item_size_mb").alias("mailbox_size_mb"),
            col("m.item_count").alias("mailbox_item_count"),
            col("m.archive_status"), col("m.archive_size_mb"),
            col("m.litigation_hold_enabled"),
            when(col("m.mailbox_id").isNotNull(), lit(True)).otherwise(lit(False)).alias("has_mailbox"),
            when(col("m.archive_status") == "Active", lit(True)).otherwise(lit(False)).alias("has_archive"),
            col("o.onedrive_id"),
            col("o.quota_used_bytes").alias("onedrive_size_bytes"),
            (col("o.quota_used_bytes") / 1048576).cast("decimal(18,2)").alias("onedrive_size_mb"),
            col("o.quota_used_gb").alias("onedrive_size_gb"),
            when(col("o.onedrive_id").isNotNull(), lit(True)).otherwise(lit(False)).alias("has_onedrive"),
            (
                coalesce(col("m.total_item_size_mb"), lit(0)) +
                coalesce(col("m.archive_size_mb"), lit(0)) +
                coalesce((col("o.quota_used_bytes") / 1048576), lit(0))
            ).cast("decimal(18,2)").alias("total_storage_mb"),
            lit(None).cast("string").alias("person_id"),
            lit(None).cast("string").alias("cdo_name"),
            col("u.last_updated_at")
        )
    )
    
    return users_enriched

# COMMAND ----------

# MAGIC %md
# MAGIC ## Gold Tables - Mail Users Dimension (External Members)

# COMMAND ----------

@dlt.table(
    name="dim_mail_users",
    comment="Mail User dimension - external members in target tenant with ExternalEmailAddress",
    table_properties={"quality": "gold", "pipelines.autoOptimize.managed": "true"}
)
def dim_mail_users():
    mail_users = spark.table(f"{CATALOG}.{SILVER_SCHEMA}.mail_users")
    
    return (
        mail_users
        .select(
            col("mail_user_id"), col("environment"), col("tenant_name"),
            col("guid"), col("display_name"), col("first_name"), col("last_name"),
            col("external_email_address"), col("primary_smtp_address"),
            col("email_addresses"), col("alias"),
            col("recipient_type"), col("recipient_type_details"),
            col("department"), col("company"), col("title"),
            col("external_directory_object_id"), col("is_dir_synced"), col("hidden_from_gal"),
            lit(None).cast("string").alias("linked_source_user_id"),
            lit(None).cast("string").alias("person_id"),
            col("source_created_at"), col("source_changed_at"), col("last_updated_at")
        )
    )

# COMMAND ----------

# MAGIC %md
# MAGIC ## Gold Tables - Contact Dimension

# COMMAND ----------

@dlt.table(
    name="dim_contacts",
    comment="Contact dimension - organizational contacts (external mail recipients)",
    table_properties={"quality": "gold", "pipelines.autoOptimize.managed": "true"}
)
def dim_contacts():
    contacts = spark.table(f"{CATALOG}.{SILVER_SCHEMA}.contacts")
    
    return (
        contacts
        .select(
            col("contact_id"), col("environment"), col("tenant_name"),
            col("entra_object_id"), col("display_name"), col("given_name"), col("surname"),
            col("mail"), col("proxy_addresses"),
            col("company_name"), col("department"), col("job_title"),
            lit(None).cast("string").alias("mapped_to_user_id"),
            lit(None).cast("string").alias("mapped_to_entity_type"),
            col("last_updated_at")
        )
    )

# COMMAND ----------

# MAGIC %md
# MAGIC ## Gold Tables - Group Dimension

# COMMAND ----------

@dlt.table(
    name="dim_groups",
    comment="Group dimension - security, M365, and distribution groups",
    table_properties={"quality": "gold", "pipelines.autoOptimize.managed": "true"}
)
def dim_groups():
    groups = spark.table(f"{CATALOG}.{SILVER_SCHEMA}.groups")
    memberships = spark.table(f"{CATALOG}.{SILVER_SCHEMA}.group_memberships")
    
    member_counts = (
        memberships
        .groupBy("group_id")
        .agg(
            count("*").alias("member_count"),
            spark_sum(when(col("member_type") == "user", 1).otherwise(0)).alias("user_member_count"),
            spark_sum(when(col("member_type") == "group", 1).otherwise(0)).alias("group_member_count")
        )
    )
    
    return (
        groups.alias("g")
        .join(member_counts.alias("m"), col("g.group_id") == col("m.group_id"), "left")
        .select(
            col("g.group_id"), col("g.environment"), col("g.tenant_name"),
            col("g.entra_object_id"), col("g.display_name"), col("g.mail"),
            col("g.proxy_addresses"), col("g.group_types"),
            col("g.mail_enabled"), col("g.security_enabled"),
            coalesce(col("m.member_count"), lit(0)).alias("member_count"),
            coalesce(col("m.user_member_count"), lit(0)).alias("user_member_count"),
            coalesce(col("m.group_member_count"), lit(0)).alias("group_member_count"),
            lit(None).cast("string").alias("mapped_to_group_id"),
            col("g.last_updated_at")
        )
    )

# COMMAND ----------

# MAGIC %md
# MAGIC ## Gold Tables - Person Map
# MAGIC 
# MAGIC Approved source↔target mappings with match_context.

# COMMAND ----------

@dlt.table(
    name="person_map",
    comment="Approved source-to-target mappings with match_context (primary_migration/external_linkage).",
    table_properties={"quality": "gold", "pipelines.autoOptimize.managed": "true"}
)
def person_map():
    candidates = spark.table(f"{CATALOG}.{SILVER_SCHEMA}.user_mapping_candidates")
    
    # Rank: for each (source_user, match_context), pick highest scoring target
    window_spec = Window.partitionBy("source_user_id", "match_context").orderBy(
        col("match_score").desc(),
        col("created_at").asc()
    )
    
    ranked = candidates.withColumn("rank", row_number().over(window_spec))
    best_matches = ranked.filter(col("rank") == 1)
    
    return (
        best_matches
        .withColumn(
            "mapping_status",
            when(col("match_score") >= AUTO_APPROVE_THRESHOLD, lit("approved"))
            .otherwise(lit("pending_review"))
        )
        .withColumn(
            "approval_method",
            when(col("match_score") >= AUTO_APPROVE_THRESHOLD, lit("auto"))
            .otherwise(lit(None).cast("string"))
        )
        .withColumn("person_id", concat_ws("_", lit("person"), col("source_user_id")))
        .withColumn("approved_at",
            when(col("mapping_status") == "approved", current_timestamp())
            .otherwise(lit(None).cast("timestamp"))
        )
        .withColumn("approved_by",
            when(col("mapping_status") == "approved", lit("system"))
            .otherwise(lit(None).cast("string"))
        )
        .withColumn("target_entity_id",
            when(col("target_user_id").isNotNull(), col("target_user_id"))
            .otherwise(col("target_mail_user_id"))
        )
        .select(
            "person_id", "source_user_id",
            "target_user_id", "target_mail_user_id", "target_entity_id",
            "match_context", "target_user_type",
            "match_score", "match_type", "match_attributes",
            "mapping_status", "approval_method", "approved_at", "approved_by",
            current_timestamp().alias("created_at"),
            current_timestamp().alias("updated_at")
        )
    )

# COMMAND ----------

# MAGIC %md
# MAGIC ## Gold Tables - Group Map

# COMMAND ----------

@dlt.table(
    name="group_map",
    comment="Approved source-to-target group mappings.",
    table_properties={"quality": "gold", "pipelines.autoOptimize.managed": "true"}
)
def group_map():
    candidates = spark.table(f"{CATALOG}.{SILVER_SCHEMA}.group_mapping_candidates")
    
    window_spec = Window.partitionBy("source_group_id").orderBy(
        col("match_score").desc(),
        col("created_at").asc()
    )
    
    ranked = candidates.withColumn("rank", row_number().over(window_spec))
    best_matches = ranked.filter(col("rank") == 1)
    
    return (
        best_matches
        .withColumn(
            "mapping_status",
            when(col("match_score") >= AUTO_APPROVE_THRESHOLD, lit("approved"))
            .otherwise(lit("pending_review"))
        )
        .withColumn(
            "approval_method",
            when(col("match_score") >= AUTO_APPROVE_THRESHOLD, lit("auto"))
            .otherwise(lit(None).cast("string"))
        )
        .withColumn("approved_at",
            when(col("mapping_status") == "approved", current_timestamp())
            .otherwise(lit(None).cast("timestamp"))
        )
        .select(
            "source_group_id", "target_group_id",
            "match_score", "match_type", "match_attributes",
            "mapping_status", "approval_method", "approved_at",
            current_timestamp().alias("created_at"),
            current_timestamp().alias("updated_at")
        )
    )

# COMMAND ----------

# MAGIC %md
# MAGIC ## Gold Tables - Dim People
# MAGIC 
# MAGIC Canonical person identity with both primary and external linkage.

# COMMAND ----------

@dlt.table(
    name="dim_people",
    comment="Canonical person identities with both primary_migration and external_linkage mappings",
    table_properties={"quality": "gold", "pipelines.autoOptimize.managed": "true"}
)
def dim_people():
    users = spark.table(f"{CATALOG}.{SILVER_SCHEMA}.users")
    mail_users = spark.table(f"{CATALOG}.{SILVER_SCHEMA}.mail_users")
    person_map = dlt.read("person_map")
    
    # Separate approved mappings by context
    approved_primary = person_map.filter(
        (col("mapping_status") == "approved") & 
        (col("match_context") == "primary_migration")
    )
    approved_external = person_map.filter(
        (col("mapping_status") == "approved") & 
        (col("match_context") == "external_linkage")
    )
    
    source_users = users.filter(col("environment") == "source").alias("su")
    target_users = users.filter((col("environment") == "target") & (col("user_type") == "Member")).alias("tu")
    
    # Base: all source users
    base_people = (
        source_users
        .select(
            concat_ws("_", lit("person"), col("user_id")).alias("person_id"),
            col("user_id").alias("source_user_id"),
            col("display_name"), col("given_name"), col("surname"),
            col("mail").alias("primary_email"),
            col("employee_id"),
            col("user_principal_name").alias("source_upn"),
            col("account_enabled").alias("source_account_enabled"),
            col("has_e3_license").alias("source_has_e3"),
            col("has_e5_license").alias("source_has_e5"),
            col("department").alias("source_department"),
            col("company_name").alias("source_company")
        )
    )
    
    # Join with primary_migration mapping → target user
    with_primary = (
        base_people.alias("bp")
        .join(approved_primary.alias("pm"), col("bp.source_user_id") == col("pm.source_user_id"), "left")
        .join(target_users.alias("tu"), col("pm.target_user_id") == col("tu.user_id"), "left")
        .select(
            col("bp.person_id"), col("bp.source_user_id"),
            col("bp.display_name"), col("bp.given_name"), col("bp.surname"),
            col("bp.primary_email"), col("bp.employee_id"),
            col("bp.source_upn"), col("bp.source_account_enabled"),
            col("bp.source_has_e3"), col("bp.source_has_e5"),
            col("bp.source_department"), col("bp.source_company"),
            col("pm.target_user_id").alias("target_user_id"),
            col("tu.user_principal_name").alias("target_upn"),
            col("tu.account_enabled").alias("target_account_enabled"),
            col("tu.has_e3_license").alias("target_has_e3"),
            col("tu.has_e5_license").alias("target_has_e5"),
            col("pm.match_score").alias("primary_match_score"),
            col("pm.match_type").alias("primary_match_type"),
            when(col("pm.target_user_id").isNotNull(), lit(True))
                .otherwise(lit(False)).alias("has_primary_mapping")
        )
    )
    
    # Join with external_linkage mapping → mail_user
    with_external = (
        with_primary.alias("wp")
        .join(approved_external.alias("ex"), col("wp.source_user_id") == col("ex.source_user_id"), "left")
        .join(mail_users.alias("mu"), col("ex.target_mail_user_id") == col("mu.mail_user_id"), "left")
        .select(
            col("wp.*"),
            col("ex.target_mail_user_id").alias("target_mail_user_id"),
            col("mu.display_name").alias("external_member_display_name"),
            col("mu.external_email_address").alias("external_member_email"),
            col("mu.primary_smtp_address").alias("external_member_smtp"),
            col("ex.match_score").alias("external_match_score"),
            col("ex.match_type").alias("external_match_type"),
            when(col("ex.target_mail_user_id").isNotNull(), lit(True))
                .otherwise(lit(False)).alias("has_external_linkage")
        )
    )
    
    # Derive mapping status
    mapped_people = (
        with_external
        .withColumn("has_source_account", lit(True))
        .withColumn("has_target_account", col("has_primary_mapping"))
        .withColumn("mapping_status",
            when(col("has_primary_mapping") & col("has_external_linkage"), lit("fully_linked"))
            .when(col("has_primary_mapping"), lit("primary_only"))
            .when(col("has_external_linkage"), lit("external_only"))
            .otherwise(lit("source_only"))
        )
        .withColumn("created_at", current_timestamp())
        .withColumn("updated_at", current_timestamp())
    )
    
    # Add target-only users (not mapped from any source)
    all_mapped_target_ids = approved_primary.select("target_user_id").filter(col("target_user_id").isNotNull())
    
    target_only = (
        target_users
        .join(all_mapped_target_ids, col("tu.user_id") == col("target_user_id"), "left_anti")
        .select(
            concat_ws("_", lit("person"), col("user_id")).alias("person_id"),
            lit(None).cast("string").alias("source_user_id"),
            col("display_name"), col("given_name"), col("surname"),
            col("mail").alias("primary_email"),
            col("employee_id"),
            lit(None).cast("string").alias("source_upn"),
            lit(None).cast("boolean").alias("source_account_enabled"),
            lit(None).cast("boolean").alias("source_has_e3"),
            lit(None).cast("boolean").alias("source_has_e5"),
            lit(None).cast("string").alias("source_department"),
            lit(None).cast("string").alias("source_company"),
            col("user_id").alias("target_user_id"),
            col("user_principal_name").alias("target_upn"),
            col("account_enabled").alias("target_account_enabled"),
            col("has_e3_license").alias("target_has_e3"),
            col("has_e5_license").alias("target_has_e5"),
            lit(None).cast("decimal(5,2)").alias("primary_match_score"),
            lit(None).cast("string").alias("primary_match_type"),
            lit(False).alias("has_primary_mapping"),
            lit(None).cast("string").alias("target_mail_user_id"),
            lit(None).cast("string").alias("external_member_display_name"),
            lit(None).cast("string").alias("external_member_email"),
            lit(None).cast("string").alias("external_member_smtp"),
            lit(None).cast("decimal(5,2)").alias("external_match_score"),
            lit(None).cast("string").alias("external_match_type"),
            lit(False).alias("has_external_linkage"),
            lit(False).alias("has_source_account"),
            lit(True).alias("has_target_account"),
            lit("target_only").alias("mapping_status"),
            current_timestamp().alias("created_at"),
            current_timestamp().alias("updated_at")
        )
    )
    
    return mapped_people.unionByName(target_only)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Gold Tables - Mapping Issues

# COMMAND ----------

@dlt.table(
    name="mapping_issues",
    comment="Flagged mapping issues requiring review",
    table_properties={"quality": "gold", "pipelines.autoOptimize.managed": "true"}
)
def mapping_issues():
    candidates = spark.table(f"{CATALOG}.{SILVER_SCHEMA}.user_mapping_candidates")
    users = spark.table(f"{CATALOG}.{SILVER_SCHEMA}.users")
    source_users = users.filter(col("environment") == "source")
    
    # Issue 1: Ambiguous matches within same context
    high_score_counts = (
        candidates
        .filter(col("match_score") >= 80)
        .groupBy("source_user_id", "match_context")
        .agg(count("*").alias("high_score_count"))
        .filter(col("high_score_count") > 1)
    )
    
    ambiguous = (
        high_score_counts
        .withColumn("issue_type", lit("ambiguous_match"))
        .withColumn("issue_description", 
            concat_ws(" ", lit("Multiple high-scoring matches in"), col("match_context"),
                lit("context:"), col("high_score_count"), lit("candidates")))
        .withColumn("severity", lit("high"))
        .select(
            concat_ws("_", lit("issue"), col("source_user_id"), col("match_context")).alias("issue_id"),
            col("source_user_id").alias("entity_id"),
            lit("user").alias("entity_type"),
            col("issue_type"), col("issue_description"), col("severity"),
            col("match_context"),
            current_timestamp().alias("detected_at")
        )
    )
    
    # Issue 2: Low confidence matches (primary_migration only)
    best_scores = (
        candidates
        .filter(col("match_context") == "primary_migration")
        .groupBy("source_user_id")
        .agg(spark_max("match_score").alias("best_score"))
        .filter((col("best_score") < 70) & (col("best_score") > 0))
    )
    
    low_confidence = (
        best_scores
        .withColumn("issue_type", lit("low_confidence_match"))
        .withColumn("issue_description",
            concat_ws(" ", lit("Best primary_migration score is only"), col("best_score").cast("string")))
        .withColumn("severity", lit("medium"))
        .withColumn("match_context", lit("primary_migration"))
        .select(
            concat_ws("_", lit("issue"), col("source_user_id")).alias("issue_id"),
            col("source_user_id").alias("entity_id"),
            lit("user").alias("entity_type"),
            col("issue_type"), col("issue_description"), col("severity"),
            col("match_context"),
            current_timestamp().alias("detected_at")
        )
    )
    
    # Issue 3: No primary_migration candidates at all
    source_with_primary = (
        candidates
        .filter(col("match_context") == "primary_migration")
        .select("source_user_id")
        .distinct()
    )
    
    no_primary = (
        source_users
        .join(source_with_primary, source_users["user_id"] == source_with_primary["source_user_id"], "left_anti")
        .select(
            concat_ws("_", lit("issue"), col("user_id")).alias("issue_id"),
            col("user_id").alias("entity_id"),
            lit("user").alias("entity_type"),
            lit("no_primary_migration_match").alias("issue_type"),
            lit("No primary_migration candidates - user may not have target Member account").alias("issue_description"),
            lit("high").alias("severity"),
            lit("primary_migration").alias("match_context"),
            current_timestamp().alias("detected_at")
        )
    )
    
    return ambiguous.unionByName(low_confidence).unionByName(no_primary)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Gold Tables - Summaries

# COMMAND ----------

@dlt.table(
    name="migration_summary",
    comment="High-level migration metrics by environment",
    table_properties={"quality": "gold", "pipelines.autoOptimize.managed": "true"}
)
def migration_summary():
    users = spark.table(f"{CATALOG}.{SILVER_SCHEMA}.users")
    groups = spark.table(f"{CATALOG}.{SILVER_SCHEMA}.groups")
    contacts = spark.table(f"{CATALOG}.{SILVER_SCHEMA}.contacts")
    mailboxes = spark.table(f"{CATALOG}.{SILVER_SCHEMA}.mailboxes")
    mail_users = spark.table(f"{CATALOG}.{SILVER_SCHEMA}.mail_users")
    
    user_stats = (
        users.groupBy("environment").agg(
            count("*").alias("user_count"),
            spark_sum(col("account_enabled").cast("int")).alias("enabled_user_count"),
            spark_sum(col("has_e3_license").cast("int")).alias("e3_license_count"),
            spark_sum(col("has_e5_license").cast("int")).alias("e5_license_count")
        )
    )
    
    group_stats = groups.groupBy("environment").agg(count("*").alias("group_count"))
    contact_stats = contacts.groupBy("environment").agg(count("*").alias("contact_count"))
    mailbox_stats = (
        mailboxes.groupBy("environment").agg(
            count("*").alias("mailbox_count"),
            spark_sum("total_item_size_mb").alias("total_mailbox_size_mb")
        )
    )
    mail_user_stats = mail_users.groupBy("environment").agg(count("*").alias("mail_user_count"))
    
    return (
        user_stats.alias("u")
        .join(group_stats.alias("g"), "environment", "left")
        .join(contact_stats.alias("c"), "environment", "left")
        .join(mailbox_stats.alias("m"), "environment", "left")
        .join(mail_user_stats.alias("mu"), "environment", "left")
        .select(
            col("environment"),
            col("user_count"), col("enabled_user_count"),
            col("e3_license_count"), col("e5_license_count"),
            coalesce(col("group_count"), lit(0)).alias("group_count"),
            coalesce(col("contact_count"), lit(0)).alias("contact_count"),
            coalesce(col("mailbox_count"), lit(0)).alias("mailbox_count"),
            coalesce(col("total_mailbox_size_mb"), lit(0)).alias("total_mailbox_size_mb"),
            coalesce(col("mail_user_count"), lit(0)).alias("mail_user_count"),
            current_timestamp().alias("snapshot_at")
        )
    )

# COMMAND ----------

@dlt.table(
    name="people_summary",
    comment="Summary of people mapping status including external linkage",
    table_properties={"quality": "gold", "pipelines.autoOptimize.managed": "true"}
)
def people_summary():
    people = dlt.read("dim_people")
    
    return (
        people.agg(
            count("*").alias("total_people"),
            spark_sum(when(col("mapping_status") == "fully_linked", 1).otherwise(0)).alias("fully_linked_count"),
            spark_sum(when(col("mapping_status") == "primary_only", 1).otherwise(0)).alias("primary_only_count"),
            spark_sum(when(col("mapping_status") == "external_only", 1).otherwise(0)).alias("external_only_count"),
            spark_sum(when(col("mapping_status") == "source_only", 1).otherwise(0)).alias("source_only_count"),
            spark_sum(when(col("mapping_status") == "target_only", 1).otherwise(0)).alias("target_only_count"),
            spark_sum(col("has_source_account").cast("int")).alias("people_with_source"),
            spark_sum(col("has_target_account").cast("int")).alias("people_with_target"),
            spark_sum(col("has_primary_mapping").cast("int")).alias("people_with_primary_mapping"),
            spark_sum(col("has_external_linkage").cast("int")).alias("people_with_external_linkage")
        )
        .withColumn("primary_mapping_pct",
            (col("people_with_primary_mapping") / col("people_with_source")).cast("decimal(5,4)"))
        .withColumn("external_linkage_pct",
            (col("people_with_external_linkage") / col("people_with_source")).cast("decimal(5,4)"))
        .withColumn("snapshot_at", current_timestamp())
    )

# COMMAND ----------

@dlt.table(
    name="mapping_candidates_summary",
    comment="Summary of mapping candidates by context, target type, and score band",
    table_properties={"quality": "gold", "pipelines.autoOptimize.managed": "true"}
)
def mapping_candidates_summary():
    candidates = spark.table(f"{CATALOG}.{SILVER_SCHEMA}.user_mapping_candidates")
    
    return (
        candidates
        .withColumn("score_band",
            when(col("match_score") >= 90, lit("90-100 (High)"))
            .when(col("match_score") >= 80, lit("80-89 (Good)"))
            .when(col("match_score") >= 70, lit("70-79 (Moderate)"))
            .otherwise(lit("Below 70 (Low)"))
        )
        .groupBy("match_context", "target_user_type", "score_band", "match_type")
        .agg(count("*").alias("candidate_count"))
        .withColumn("snapshot_at", current_timestamp())
    )

# COMMAND ----------

# MAGIC %md
# MAGIC ## Gold Tables - Non-Person Mailboxes

# COMMAND ----------

@dlt.table(
    name="non_person_mailboxes",
    comment="Non-person mailboxes: shared, room, equipment, and other resource mailboxes",
    table_properties={"quality": "gold", "pipelines.autoOptimize.managed": "true"}
)
def non_person_mailboxes():
    mailboxes = spark.table(f"{CATALOG}.{SILVER_SCHEMA}.mailboxes")
    
    non_person_types = [
        "SharedMailbox", "RoomMailbox", "EquipmentMailbox", 
        "SchedulingMailbox", "GroupMailbox", "DiscoveryMailbox", "TeamMailbox"
    ]
    
    return (
        mailboxes
        .filter(col("recipient_type_details").isin(non_person_types))
        .withColumn("mailbox_category",
            when(col("recipient_type_details") == "SharedMailbox", lit("shared"))
            .when(col("recipient_type_details") == "RoomMailbox", lit("room"))
            .when(col("recipient_type_details") == "EquipmentMailbox", lit("equipment"))
            .when(col("recipient_type_details") == "SchedulingMailbox", lit("scheduling"))
            .when(col("recipient_type_details") == "GroupMailbox", lit("group"))
            .otherwise(lit("other"))
        )
        .select(
            col("mailbox_id"), col("environment"), col("tenant_name"),
            col("exchange_guid"), col("display_name"), col("primary_smtp_address"),
            col("recipient_type_details"), col("mailbox_category"),
            col("total_item_size_mb"), col("item_count"),
            col("archive_status"), col("archive_size_mb"),
            col("litigation_hold_enabled"),
            lit(None).cast("string").alias("mapped_to_mailbox_id"),
            lit(None).cast("string").alias("mapping_status"),
            col("last_updated_at")
        )
    )

# COMMAND ----------

# MAGIC %md
# MAGIC ## Gold Tables - Data Volumes

# COMMAND ----------

@dlt.table(
    name="data_volumes",
    comment="Aggregate data volumes by environment for migration planning",
    table_properties={"quality": "gold", "pipelines.autoOptimize.managed": "true"}
)
def data_volumes():
    mailboxes = spark.table(f"{CATALOG}.{SILVER_SCHEMA}.mailboxes")
    onedrive = spark.table(f"{CATALOG}.{SILVER_SCHEMA}.onedrive_sites")
    sharepoint = spark.table(f"{CATALOG}.{SILVER_SCHEMA}.sharepoint_sites")
    
    mailbox_volumes = (
        mailboxes.groupBy("environment").agg(
            count("*").alias("mailbox_count"),
            spark_sum("total_item_size_mb").alias("mailbox_size_mb"),
            spark_sum("item_count").alias("mailbox_item_count"),
            spark_sum(when(col("archive_status") == "Active", col("archive_size_mb")).otherwise(0)).alias("archive_size_mb"),
            spark_sum(when(col("archive_status") == "Active", 1).otherwise(0)).alias("archive_count"),
            spark_sum(when(col("litigation_hold_enabled"), 1).otherwise(0)).alias("litigation_hold_count")
        )
        .withColumn("data_type", lit("mailbox"))
    )
    
    onedrive_volumes = (
        onedrive.groupBy("environment").agg(
            count("*").alias("onedrive_count"),
            spark_sum("quota_used_bytes").alias("onedrive_size_bytes"),
            (spark_sum("quota_used_bytes") / 1048576).alias("onedrive_size_mb"),
            (spark_sum("quota_used_bytes") / 1073741824).alias("onedrive_size_gb")
        )
        .withColumn("data_type", lit("onedrive"))
    )
    
    sharepoint_volumes = (
        sharepoint.groupBy("environment").agg(count("*").alias("sharepoint_site_count"))
        .withColumn("data_type", lit("sharepoint"))
    )
    
    mailbox_summary = mailbox_volumes.select(
        col("environment"), col("data_type"),
        col("mailbox_count").alias("item_count"),
        col("mailbox_size_mb").alias("size_mb"),
        (col("mailbox_size_mb") / 1024).alias("size_gb"),
        (col("mailbox_size_mb") / 1048576).alias("size_tb"),
        col("litigation_hold_count")
    )
    
    archive_summary = mailbox_volumes.select(
        col("environment"), lit("archive").alias("data_type"),
        col("archive_count").alias("item_count"),
        col("archive_size_mb").alias("size_mb"),
        (col("archive_size_mb") / 1024).alias("size_gb"),
        (col("archive_size_mb") / 1048576).alias("size_tb"),
        lit(None).cast("long").alias("litigation_hold_count")
    )
    
    onedrive_summary = onedrive_volumes.select(
        col("environment"), col("data_type"),
        col("onedrive_count").alias("item_count"),
        col("onedrive_size_mb").alias("size_mb"),
        col("onedrive_size_gb").alias("size_gb"),
        (col("onedrive_size_gb") / 1024).alias("size_tb"),
        lit(None).cast("long").alias("litigation_hold_count")
    )
    
    sharepoint_summary = sharepoint_volumes.select(
        col("environment"), col("data_type"),
        col("sharepoint_site_count").alias("item_count"),
        lit(None).cast("decimal(18,2)").alias("size_mb"),
        lit(None).cast("decimal(18,2)").alias("size_gb"),
        lit(None).cast("decimal(18,2)").alias("size_tb"),
        lit(None).cast("long").alias("litigation_hold_count")
    )
    
    return (
        mailbox_summary
        .unionByName(archive_summary)
        .unionByName(onedrive_summary)
        .unionByName(sharepoint_summary)
        .withColumn("snapshot_at", current_timestamp())
    )

# COMMAND ----------

@dlt.table(
    name="storage_summary",
    comment="Total storage summary across all data types",
    table_properties={"quality": "gold", "pipelines.autoOptimize.managed": "true"}
)
def storage_summary():
    volumes = dlt.read("data_volumes")
    
    by_environment = (
        volumes.filter(col("size_mb").isNotNull())
        .groupBy("environment")
        .agg(
            spark_sum("size_mb").alias("total_size_mb"),
            spark_sum("item_count").alias("total_items")
        )
        .withColumn("total_size_gb", (col("total_size_mb") / 1024).cast("decimal(18,2)"))
        .withColumn("total_size_tb", (col("total_size_mb") / 1048576).cast("decimal(18,2)"))
    )
    
    by_type = (
        volumes.filter(col("size_mb").isNotNull())
        .groupBy("data_type")
        .agg(
            spark_sum("size_mb").alias("total_size_mb"),
            spark_sum("item_count").alias("total_items")
        )
        .withColumn("environment", lit("all"))
        .withColumn("total_size_gb", (col("total_size_mb") / 1024).cast("decimal(18,2)"))
        .withColumn("total_size_tb", (col("total_size_mb") / 1048576).cast("decimal(18,2)"))
        .select("environment", "data_type", "total_items", "total_size_mb", "total_size_gb", "total_size_tb")
    )
    
    return (
        by_environment
        .withColumn("data_type", lit("all"))
        .select("environment", "data_type", "total_items", "total_size_mb", "total_size_gb", "total_size_tb")
        .unionByName(by_type)
        .withColumn("snapshot_at", current_timestamp())
    )