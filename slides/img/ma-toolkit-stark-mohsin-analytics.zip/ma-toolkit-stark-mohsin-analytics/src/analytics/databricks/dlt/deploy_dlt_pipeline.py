# Databricks notebook source
# MAGIC %md
# MAGIC # Deploy DLT Pipeline - M365 Migration
# MAGIC 
# MAGIC Run this notebook to create/update the DLT pipeline programmatically.
# MAGIC 
# MAGIC **Prerequisites:**
# MAGIC - Databricks workspace with Unity Catalog enabled
# MAGIC - `m365_migration` catalog with bronze, silver, gold, audit schemas
# MAGIC - Storage credential and external locations configured
# MAGIC - User has permission to create DLT pipelines

# COMMAND ----------

# MAGIC %md
# MAGIC ## Configuration

# COMMAND ----------

# Pipeline configuration
PIPELINE_NAME = "dlt_m365_migration"
CATALOG = "m365_migration"
STORAGE_ACCOUNT = "stm365analyticsdev001"

# Notebook paths - update the base path to match your Databricks workspace
# If using Repos: /Repos/<user-or-folder>/<repo-name>/databricks/dlt
# If uploaded to Workspace: /Workspace/Users/<user>/databricks/dlt
REPO_BASE_PATH = "/Repos/m365-migration-toolkit/databricks/dlt"  # UPDATE THIS

# DLT pipeline notebooks (in execution order)
NOTEBOOK_PATHS = [
    f"{REPO_BASE_PATH}/pl_bronze",   # Bronze layer - raw data ingestion
    f"{REPO_BASE_PATH}/pl_silver",   # Silver layer - cleansed/transformed
    f"{REPO_BASE_PATH}/pl_gold",     # Gold layer - business-ready aggregates
    f"{REPO_BASE_PATH}/pl_audit",    # Audit tables - pipeline metadata
]

# Cluster configuration
CLUSTER_CONFIG = {
    "label": "default",
    "autoscale": {
        "min_workers": 1,
        "max_workers": 4,
        "mode": "ENHANCED"
    }
}

# COMMAND ----------

# MAGIC %md
# MAGIC ## Create Pipeline via API

# COMMAND ----------

import requests
import json

# Get workspace URL and token
try:
    workspace_url = dbutils.notebook.entry_point.getDbutils().notebook().getContext().apiUrl().get()
    token = dbutils.notebook.entry_point.getDbutils().notebook().getContext().apiToken().get()
except Exception as e:
    raise RuntimeError(
        "This notebook must be run in a Databricks environment with dbutils available "
        "and a valid notebook context. Failed to obtain workspace URL and token."
    ) from e

headers = {
    "Authorization": f"Bearer {token}",
    "Content-Type": "application/json"
}

# Pipeline specification
# Note: With Unity Catalog, tables are written to schemas specified in each @dlt.table decorator
# The pipeline notebooks (pl_bronze, pl_silver, pl_gold, pl_audit) define their target schemas:
#   - pl_bronze.py -> m365_migration.bronze
#   - pl_silver.py -> m365_migration.silver
#   - pl_gold.py   -> m365_migration.gold
#   - pl_audit.py  -> m365_migration.audit
pipeline_spec = {
    "name": PIPELINE_NAME,
    "catalog": CATALOG,
    # No "target" specified - each notebook defines its own schema via @dlt.table(schema=...)
    # or by using fully qualified table names in CATALOG.SCHEMA.TABLE format
    "development": True,  # Set to False for production
    "continuous": False,  # Triggered mode (not continuous)
    "channel": "CURRENT",  # Use current Databricks Runtime
    "photon": True,  # Enable Photon acceleration
    "edition": "ADVANCED",  # Required for APPLY CHANGES
    "libraries": [
        {"notebook": {"path": path}} for path in NOTEBOOK_PATHS
    ],
    "configuration": {
        "storage_account": STORAGE_ACCOUNT,
        "catalog": CATALOG,
        # Schema names for reference in notebooks
        "bronze_schema": "bronze",
        "silver_schema": "silver",
        "gold_schema": "gold",
        "audit_schema": "audit",
        # Tenant configuration - set these for your environment
        "source_tenant_name": "",  # e.g., "MADEV2"
        "source_tenant_id": "",    # e.g., "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx"
        "target_tenant_name": "",  # e.g., "MADEV1"
        "target_tenant_id": "",    # e.g., "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx"
    },
    "clusters": [CLUSTER_CONFIG]
}

print("Pipeline specification:")
print(json.dumps(pipeline_spec, indent=2))

# COMMAND ----------

# MAGIC %md
# MAGIC ## Check if Pipeline Exists

# COMMAND ----------

# List existing pipelines
response = requests.get(
    f"{workspace_url}/api/2.0/pipelines",
    headers=headers
)

existing_pipeline_id = None
if response.status_code == 200:
    pipelines = response.json().get("statuses", [])
    for p in pipelines:
        if p.get("name") == PIPELINE_NAME:
            existing_pipeline_id = p.get("pipeline_id")
            print(f"Found existing pipeline: {existing_pipeline_id}")
            break

if not existing_pipeline_id:
    print("No existing pipeline found. Will create new one.")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Create or Update Pipeline

# COMMAND ----------

if existing_pipeline_id:
    # Update existing pipeline
    response = requests.put(
        f"{workspace_url}/api/2.0/pipelines/{existing_pipeline_id}",
        headers=headers,
        json=pipeline_spec
    )
    action = "Updated"
else:
    # Create new pipeline
    response = requests.post(
        f"{workspace_url}/api/2.0/pipelines",
        headers=headers,
        json=pipeline_spec
    )
    action = "Created"

if response.status_code in [200, 201]:
    result = response.json()
    pipeline_id = result.get("pipeline_id", existing_pipeline_id)
    print(f"{action} pipeline successfully!")
    print(f"Pipeline ID: {pipeline_id}")
    print(f"\nView in UI: {workspace_url}/#joblist/pipelines/{pipeline_id}")
else:
    print(f"Error: {response.status_code}")
    print(response.text)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Start Pipeline (Optional)

# COMMAND ----------

# Uncomment to start the pipeline immediately
# response = requests.post(
#     f"{workspace_url}/api/2.0/pipelines/{pipeline_id}/updates",
#     headers=headers,
#     json={"full_refresh": False}  # Set to True to reprocess all data
# )
# 
# if response.status_code == 200:
#     update_id = response.json().get("update_id")
#     print(f"Pipeline started! Update ID: {update_id}")
# else:
#     print(f"Error starting pipeline: {response.text}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Useful Commands
# MAGIC 
# MAGIC ```python
# MAGIC # Start pipeline
# MAGIC POST /api/2.0/pipelines/{pipeline_id}/updates
# MAGIC {"full_refresh": false}
# MAGIC 
# MAGIC # Stop pipeline
# MAGIC POST /api/2.0/pipelines/{pipeline_id}/stop
# MAGIC 
# MAGIC # Get pipeline status
# MAGIC GET /api/2.0/pipelines/{pipeline_id}
# MAGIC 
# MAGIC # Get latest update status
# MAGIC GET /api/2.0/pipelines/{pipeline_id}/updates
# MAGIC ```
# MAGIC 
# MAGIC ## Query DLT Event Log
# MAGIC 
# MAGIC ```sql
# MAGIC -- Get pipeline events
# MAGIC SELECT * FROM event_log("{pipeline_id}")
# MAGIC WHERE event_type = 'flow_progress'
# MAGIC ORDER BY timestamp DESC
# MAGIC LIMIT 100;
# MAGIC 
# MAGIC -- Check data quality expectations
# MAGIC SELECT * FROM event_log("{pipeline_id}")
# MAGIC WHERE event_type = 'expectation_result'
# MAGIC ORDER BY timestamp DESC;
# MAGIC ```
