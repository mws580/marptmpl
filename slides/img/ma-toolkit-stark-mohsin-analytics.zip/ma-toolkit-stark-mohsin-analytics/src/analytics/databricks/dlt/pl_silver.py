# Databricks notebook source
# MAGIC %md
# MAGIC # M365 Migration - Silver Layer Pipeline
# MAGIC 
# MAGIC **Pipeline:** `pl_m365_silver`  
# MAGIC **Target Schema:** `m365_migration.silver`
# MAGIC 
# MAGIC ## Purpose
# MAGIC Reads from Bronze tables, explodes nested JSON arrays, cleanses/normalizes,
# MAGIC and deduplicates using APPLY CHANGES (SCD Type 1).
# MAGIC 
# MAGIC ## Silver Tables
# MAGIC | Table | Source | Description |
# MAGIC |-------|--------|-------------|
# MAGIC | `users` | entra_users_source/target | Cleansed user identities with license flags |
# MAGIC | `contacts` | entra_contacts_source/target | Org contacts (external mail recipients) |
# MAGIC | `groups` | entra_groups_source/target | Security, M365, distribution groups |
# MAGIC | `group_memberships` | entra_group_members_source/target | Group membership relationships |
# MAGIC | `mailboxes` | exo_mailboxes_source/target | Exchange mailboxes with sizes |
# MAGIC | `mail_users` | exo_mail_users_target | External members with ExternalEmailAddress |
# MAGIC | `onedrive_sites` | onedrive_sites_source | OneDrive storage per user |
# MAGIC | `sharepoint_sites` | sharepoint_sites_source | SharePoint site collections |
# MAGIC | `contact_entity_mapping` | contacts ↔ users/groups | Cross-tenant contact-to-entity email matching |
# MAGIC | `user_mapping_candidates` | users ↔ mail_users | Multi-context identity matching |
# MAGIC | `group_mapping_candidates` | groups (source ↔ target) | Group matching |
# MAGIC 
# MAGIC ## User Mapping Contexts
# MAGIC - **primary_migration**: Source Member → Target Member (migration target account)
# MAGIC - **external_linkage**: Source Member → Target External Member (pre-existing corp access)

# COMMAND ----------

import dlt
from pyspark.sql.functions import (
    col, lit, lower, explode, current_timestamp, array_contains,
    when, concat_ws, trim, expr, to_timestamp, regexp_replace,
    collect_set, max as spark_max, array, split, coalesce,
    round as spark_round
)
from pyspark.sql.types import StructType

# COMMAND ----------

# MAGIC %md
# MAGIC ## Configuration

# COMMAND ----------

CATALOG = "m365_migration"
BRONZE_SCHEMA = "bronze"

def get_tenant_config():
    """Retrieves tenant configuration from DLT pipeline parameters."""
    try:
        source_tenant_name = spark.conf.get("source_tenant_name", "")
        source_tenant_id = spark.conf.get("source_tenant_id", "")
        target_tenant_name = spark.conf.get("target_tenant_name", "")
        target_tenant_id = spark.conf.get("target_tenant_id", "")
    except Exception:
        source_tenant_name = ""
        source_tenant_id = ""
        target_tenant_name = ""
        target_tenant_id = ""
    
    return {
        "source": {"tenant_name": source_tenant_name, "tenant_id": source_tenant_id},
        "target": {"tenant_name": target_tenant_name, "tenant_id": target_tenant_id}
    }

TENANT_CONFIG = get_tenant_config()

DEFAULT_LICENSE_SKUS = {
    "E3": "05e9a617-0261-4cee-bb44-138d3ef5d965",
    "E5": "06ebc4ee-1bb5-47dd-8120-11324bc54e06",
    "F3": "66b55226-6b4f-492c-910c-a3b7a3c9d993",
    "E1": "18181a46-0d4e-45cd-891e-60aabd171b4e",
}

def get_license_skus():
    try:
        skus_json = spark.conf.get("license_skus_json", "")
        if skus_json:
            import json
            return json.loads(skus_json)
        return {
            "E3": spark.conf.get("license_sku_e3", DEFAULT_LICENSE_SKUS["E3"]),
            "E5": spark.conf.get("license_sku_e5", DEFAULT_LICENSE_SKUS["E5"]),
            "F3": spark.conf.get("license_sku_f3", DEFAULT_LICENSE_SKUS["F3"]),
            "E1": spark.conf.get("license_sku_e1", DEFAULT_LICENSE_SKUS["E1"]),
        }
    except Exception:
        return DEFAULT_LICENSE_SKUS

LICENSE_SKUS = get_license_skus()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Helper Functions

# COMMAND ----------

def get_tenant_name(environment: str) -> str:
    return TENANT_CONFIG.get(environment, {}).get("tenant_name", "Unknown")

def check_license_sku(sku_id: str):
    return expr(f"exists(assignedLicenses, x -> x.skuId = '{sku_id}')")

def extract_license_skus():
    return expr("transform(assignedLicenses, x -> x.skuId)")

def tenant_name_col():
    return when(col("_environment") == "source", lit(get_tenant_name("source"))).otherwise(lit(get_tenant_name("target")))

def safe_explode_data(df, data_col="data"):
    data_type = df.schema[data_col].dataType
    if isinstance(data_type, StructType):
        df = df.withColumn(data_col, array(col(data_col)))
    return df

def ensure_columns(df, columns):
    for c in columns:
        if c not in df.columns:
            df = df.withColumn(c, lit(None).cast("string"))
    return df

# COMMAND ----------

# MAGIC %md
# MAGIC ## Silver Tables - Users

# COMMAND ----------

@dlt.table(
    name="users_staged",
    comment="Staged user records before deduplication",
    temporary=True
)
@dlt.expect_or_drop("valid_id", "entra_object_id IS NOT NULL")
@dlt.expect("valid_upn", "user_principal_name IS NOT NULL")
def users_staged():
    def transform_users(df):
        df = safe_explode_data(df)
        expanded = (
            df
            .select(explode(col("data")).alias("user"), col("batch_id"), col("_dlt_ingested_at"), col("_environment"))
            .select(col("user.*"), col("batch_id"), col("_dlt_ingested_at"), col("_environment"))
        )
        expanded = ensure_columns(expanded, [
            "onPremisesSamAccountName", "onPremisesImmutableId", "onPremisesDistinguishedName",
            "onPremisesSecurityIdentifier", "onPremisesSyncEnabled", "onPremisesLastSyncDateTime",
            "onPremisesDomainName", "mobilePhone", "usageLocation", "preferredLanguage",
            "lastPasswordChangeDateTime", "businessPhones"
        ])
        return (
            expanded
            .withColumn("user_id", concat_ws("_", col("_environment"), col("id")))
            .withColumn("entra_object_id", col("id"))
            .withColumn("environment", col("_environment"))
            .withColumn("tenant_name", tenant_name_col())
            .withColumn("user_principal_name", trim(col("userPrincipalName")))
            .withColumn("display_name", trim(col("displayName")))
            .withColumn("given_name", trim(col("givenName")))
            .withColumn("surname", trim(col("surname")))
            .withColumn("mail", lower(trim(col("mail"))))
            .withColumn("proxy_addresses", col("proxyAddresses"))
            .withColumn("user_type", col("userType"))
            .withColumn("account_enabled", col("accountEnabled").cast("boolean"))
            .withColumn("employee_id", col("employeeId"))
            .withColumn("job_title", col("jobTitle"))
            .withColumn("department", col("department"))
            .withColumn("company_name", col("companyName"))
            .withColumn("office_location", col("officeLocation"))
            .withColumn("assigned_licenses", extract_license_skus())
            .withColumn("has_e3_license", check_license_sku(LICENSE_SKUS["E3"]))
            .withColumn("has_e5_license", check_license_sku(LICENSE_SKUS["E5"]))
            .withColumn("has_f3_license", check_license_sku(LICENSE_SKUS["F3"]))
            .withColumn("has_e1_license", check_license_sku(LICENSE_SKUS["E1"]))
            .withColumn("on_prem_sam_account_name", col("onPremisesSamAccountName"))
            .withColumn("on_prem_immutable_id", col("onPremisesImmutableId"))
            .withColumn("on_prem_distinguished_name", col("onPremisesDistinguishedName"))
            .withColumn("on_prem_security_identifier", col("onPremisesSecurityIdentifier"))
            .withColumn("on_prem_sync_enabled", col("onPremisesSyncEnabled").cast("boolean"))
            .withColumn("on_prem_last_sync_at", to_timestamp(col("onPremisesLastSyncDateTime")))
            .withColumn("on_prem_domain_name", col("onPremisesDomainName"))
            .withColumn("mobile_phone", col("mobilePhone"))
            .withColumn("usage_location", col("usageLocation"))
            .withColumn("preferred_language", col("preferredLanguage"))
            .withColumn("source_created_at", to_timestamp(col("createdDateTime")))
            .withColumn("last_password_change_at", to_timestamp(col("lastPasswordChangeDateTime")))
            .withColumn("last_updated_at", col("_dlt_ingested_at"))
            .select(
                "user_id", "entra_object_id", "environment", "tenant_name",
                "user_principal_name", "display_name", "given_name", "surname",
                "mail", "proxy_addresses",
                "user_type", "account_enabled",
                "employee_id", "job_title", "department", "company_name", "office_location",
                "assigned_licenses", "has_e3_license", "has_e5_license", "has_f3_license", "has_e1_license",
                "on_prem_sam_account_name", "on_prem_immutable_id", "on_prem_distinguished_name",
                "on_prem_security_identifier", "on_prem_sync_enabled", "on_prem_last_sync_at",
                "on_prem_domain_name",
                "mobile_phone", "usage_location", "preferred_language",
                "source_created_at", "last_password_change_at", "last_updated_at"
            )
        )
    
    source_df = transform_users(spark.readStream.table(f"{CATALOG}.{BRONZE_SCHEMA}.entra_users_source"))
    target_df = transform_users(spark.readStream.table(f"{CATALOG}.{BRONZE_SCHEMA}.entra_users_target"))
    return source_df.unionByName(target_df)

dlt.create_streaming_table(
    name="users",
    comment="Deduplicated user accounts from source and target tenants. SCD Type 1.",
    table_properties={"quality": "silver", "pipelines.autoOptimize.managed": "true"}
)

dlt.apply_changes(
    target="users",
    source="users_staged",
    keys=["user_id"],
    sequence_by=col("last_updated_at"),
    stored_as_scd_type=1
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Silver Tables - Contacts

# COMMAND ----------

@dlt.table(
    name="contacts_staged",
    comment="Staged contact records before deduplication",
    temporary=True
)
@dlt.expect_or_drop("valid_id", "entra_object_id IS NOT NULL")
def contacts_staged():
    def transform_contacts(df):
        df = safe_explode_data(df)
        return (
            df
            .select(explode(col("data")).alias("contact"), col("batch_id"), col("_dlt_ingested_at"), col("_environment"))
            .select(col("contact.*"), col("batch_id"), col("_dlt_ingested_at"), col("_environment"))
            .withColumn("contact_id", concat_ws("_", col("_environment"), col("id")))
            .withColumn("entra_object_id", col("id"))
            .withColumn("environment", col("_environment"))
            .withColumn("tenant_name", tenant_name_col())
            .withColumn("display_name", trim(col("displayName")))
            .withColumn("given_name", trim(col("givenName")))
            .withColumn("surname", trim(col("surname")))
            .withColumn("mail", lower(trim(col("mail"))))
            .withColumn("proxy_addresses", col("proxyAddresses"))
            .withColumn("company_name", col("companyName"))
            .withColumn("department", col("department"))
            .withColumn("job_title", col("jobTitle"))
            .withColumn("last_updated_at", col("_dlt_ingested_at"))
            .select(
                "contact_id", "entra_object_id", "environment", "tenant_name",
                "display_name", "given_name", "surname",
                "mail", "proxy_addresses",
                "company_name", "department", "job_title",
                "last_updated_at"
            )
        )
    
    source_df = transform_contacts(spark.readStream.table(f"{CATALOG}.{BRONZE_SCHEMA}.entra_contacts_source"))
    target_df = transform_contacts(spark.readStream.table(f"{CATALOG}.{BRONZE_SCHEMA}.entra_contacts_target"))
    return source_df.unionByName(target_df)

dlt.create_streaming_table(
    name="contacts",
    comment="Deduplicated organizational contacts. SCD Type 1.",
    table_properties={"quality": "silver", "pipelines.autoOptimize.managed": "true"}
)

dlt.apply_changes(
    target="contacts",
    source="contacts_staged",
    keys=["contact_id"],
    sequence_by=col("last_updated_at"),
    stored_as_scd_type=1
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Silver Tables - Groups

# COMMAND ----------

@dlt.table(
    name="groups_staged",
    comment="Staged group records before deduplication",
    temporary=True
)
@dlt.expect_or_drop("valid_id", "entra_object_id IS NOT NULL")
def groups_staged():
    def transform_groups(df):
        df = safe_explode_data(df)
        return (
            df
            .select(explode(col("data")).alias("grp"), col("batch_id"), col("_dlt_ingested_at"), col("_environment"))
            .select(col("grp.*"), col("batch_id"), col("_dlt_ingested_at"), col("_environment"))
            .withColumn("group_id", concat_ws("_", col("_environment"), col("id")))
            .withColumn("entra_object_id", col("id"))
            .withColumn("environment", col("_environment"))
            .withColumn("tenant_name", tenant_name_col())
            .withColumn("display_name", trim(col("displayName")))
            .withColumn("description", col("description"))
            .withColumn("mail", lower(trim(col("mail"))))
            .withColumn("proxy_addresses", col("proxyAddresses"))
            .withColumn("mail_enabled", col("mailEnabled").cast("boolean"))
            .withColumn("security_enabled", col("securityEnabled").cast("boolean"))
            .withColumn("group_types", col("groupTypes"))
            .withColumn("group_type",
                when(array_contains(col("groupTypes"), "Unified"), lit("Microsoft365"))
                .when(col("mailEnabled") & col("securityEnabled"), lit("MailEnabledSecurity"))
                .when(col("mailEnabled"), lit("Distribution"))
                .otherwise(lit("Security"))
            )
            .withColumn("is_dynamic",
                when(array_contains(col("groupTypes"), "DynamicMembership"), lit(True))
                .otherwise(lit(False))
            )
            .withColumn("membership_rule", col("membershipRule"))
            .withColumn("source_created_at", to_timestamp(col("createdDateTime")))
            .withColumn("last_updated_at", col("_dlt_ingested_at"))
            .select(
                "group_id", "entra_object_id", "environment", "tenant_name",
                "display_name", "description", "mail", "proxy_addresses",
                "mail_enabled", "security_enabled", "group_types",
                "group_type", "is_dynamic", "membership_rule",
                "source_created_at", "last_updated_at"
            )
        )
    
    source_df = transform_groups(spark.readStream.table(f"{CATALOG}.{BRONZE_SCHEMA}.entra_groups_source"))
    target_df = transform_groups(spark.readStream.table(f"{CATALOG}.{BRONZE_SCHEMA}.entra_groups_target"))
    return source_df.unionByName(target_df)

dlt.create_streaming_table(
    name="groups",
    comment="Deduplicated groups. SCD Type 1.",
    table_properties={"quality": "silver", "pipelines.autoOptimize.managed": "true"}
)

dlt.apply_changes(
    target="groups",
    source="groups_staged",
    keys=["group_id"],
    sequence_by=col("last_updated_at"),
    stored_as_scd_type=1
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Silver Tables - Group Memberships

# COMMAND ----------

@dlt.table(
    name="group_memberships_staged",
    comment="Staged group membership records before deduplication",
    temporary=True
)
@dlt.expect_or_drop("valid_group", "group_id IS NOT NULL")
@dlt.expect_or_drop("valid_member", "member_id IS NOT NULL")
def group_memberships_staged():
    def transform_members(df):
        df = safe_explode_data(df)
        return (
            df
            .select(explode(col("data")).alias("mem"), col("batch_id"), col("_dlt_ingested_at"), col("_environment"))
            .select(col("mem.*"), col("batch_id"), col("_dlt_ingested_at"), col("_environment"))
            .withColumn("membership_id", concat_ws("_", col("_environment"), col("group_id"), col("member_id")))
            .withColumn("environment", col("_environment"))
            .withColumn("tenant_name", tenant_name_col())
            .withColumn("last_updated_at", col("_dlt_ingested_at"))
            .select(
                "membership_id", "group_id", "member_id", "member_type",
                "environment", "tenant_name", "last_updated_at"
            )
        )
    
    source_df = transform_members(spark.readStream.table(f"{CATALOG}.{BRONZE_SCHEMA}.entra_group_members_source"))
    target_df = transform_members(spark.readStream.table(f"{CATALOG}.{BRONZE_SCHEMA}.entra_group_members_target"))
    return source_df.unionByName(target_df)

dlt.create_streaming_table(
    name="group_memberships",
    comment="Deduplicated group membership relationships. SCD Type 1.",
    table_properties={"quality": "silver", "pipelines.autoOptimize.managed": "true"}
)

dlt.apply_changes(
    target="group_memberships",
    source="group_memberships_staged",
    keys=["membership_id"],
    sequence_by=col("last_updated_at"),
    stored_as_scd_type=1
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Silver Tables - Exchange Online Mailboxes

# COMMAND ----------

@dlt.table(
    name="mailboxes_staged",
    comment="Staged mailbox records before deduplication",
    temporary=True
)
@dlt.expect_or_drop("valid_guid", "exchange_guid IS NOT NULL")
def mailboxes_staged():
    def transform_mailboxes(df):
        df = safe_explode_data(df)
        expanded = (
            df
            .select(explode(col("data")).alias("mbx"), col("batch_id"), col("_dlt_ingested_at"), col("_environment"))
            .select(col("mbx.*"), col("batch_id"), col("_dlt_ingested_at"), col("_environment"))
        )
        expanded = ensure_columns(expanded, ["ArchiveSize_MB"])
        return (
            expanded
            .withColumn("mailbox_id", concat_ws("_", col("_environment"), col("ExchangeGuid")))
            .withColumn("exchange_guid", col("ExchangeGuid"))
            .withColumn("environment", col("_environment"))
            .withColumn("tenant_name", tenant_name_col())
            .withColumn("user_principal_name", lower(trim(col("UserPrincipalName"))))
            .withColumn("primary_smtp_address", lower(trim(col("PrimarySmtpAddress"))))
            .withColumn("display_name", trim(col("DisplayName")))
            .withColumn("recipient_type_details", col("RecipientTypeDetails"))
            .withColumn("total_item_size_mb", col("TotalItemSizeMB").cast("decimal(18,2)"))
            .withColumn("item_count", col("ItemCount").cast("long"))
            .withColumn("deleted_item_count", col("DeletedItemCount").cast("long"))
            .withColumn("archive_status", col("ArchiveStatus"))
            .withColumn("archive_guid", col("ArchiveGuid"))
            .withColumn("archive_size_mb", col("ArchiveSize_MB").cast("decimal(18,2)"))
            .withColumn("litigation_hold_enabled", col("LitigationHoldEnabled").cast("boolean"))
            .withColumn("last_updated_at", col("_dlt_ingested_at"))
            .select(
                "mailbox_id", "exchange_guid", "environment", "tenant_name",
                "user_principal_name", "primary_smtp_address", "display_name",
                "recipient_type_details",
                "total_item_size_mb", "item_count", "deleted_item_count",
                "archive_status", "archive_guid", "archive_size_mb",
                "litigation_hold_enabled",
                "last_updated_at"
            )
        )
    
    source_df = transform_mailboxes(spark.readStream.table(f"{CATALOG}.{BRONZE_SCHEMA}.exo_mailboxes_source"))
    target_df = transform_mailboxes(spark.readStream.table(f"{CATALOG}.{BRONZE_SCHEMA}.exo_mailboxes_target"))
    return source_df.unionByName(target_df)

dlt.create_streaming_table(
    name="mailboxes",
    comment="Deduplicated Exchange Online mailboxes. SCD Type 1.",
    table_properties={"quality": "silver", "pipelines.autoOptimize.managed": "true"}
)

dlt.apply_changes(
    target="mailboxes",
    source="mailboxes_staged",
    keys=["mailbox_id"],
    sequence_by=col("last_updated_at"),
    stored_as_scd_type=1
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Silver Tables - Mail Users (External Members)
# MAGIC 
# MAGIC **Source:** `exo_mail_users_target` (target tenant only)  
# MAGIC **Key:** `mail_user_id` = `target_{guid}`  
# MAGIC 
# MAGIC Mail Users represent external members in the target tenant whose primary
# MAGIC mailbox is in the source org. ExternalEmailAddress is critical for
# MAGIC external linkage identity matching.

# COMMAND ----------

@dlt.table(
    name="mail_users_staged",
    comment="Staged mail user records before deduplication",
    temporary=True
)
@dlt.expect_or_drop("valid_guid", "guid IS NOT NULL")
def mail_users_staged():
    df = safe_explode_data(
        spark.readStream.table(f"{CATALOG}.{BRONZE_SCHEMA}.exo_mail_users_target")
    )
    expanded = (
        df
        .select(explode(col("data")).alias("mu"), col("batch_id"), col("_dlt_ingested_at"), col("_environment"))
        .select(col("mu.*"), col("batch_id"), col("_dlt_ingested_at"), col("_environment"))
    )
    # Handle optional columns
    expanded = ensure_columns(expanded, [
        "FirstName", "LastName", "Title", "Department", "Company",
        "ExternalDirectoryObjectId", "HiddenFromAddressListsEnabled"
    ])
    return (
        expanded
        .withColumn("mail_user_id", concat_ws("_", col("_environment"), col("Guid")))
        .withColumn("guid", col("Guid"))
        .withColumn("environment", col("_environment"))
        .withColumn("tenant_name", tenant_name_col())
        .withColumn("display_name", trim(col("DisplayName")))
        .withColumn("first_name", trim(col("FirstName")))
        .withColumn("last_name", trim(col("LastName")))
        # CRITICAL: ExternalEmailAddress points to source mailbox - strip SMTP: prefix
        .withColumn("external_email_address", 
            lower(regexp_replace(col("ExternalEmailAddress"), "^(?i)smtp:", "")))
        .withColumn("primary_smtp_address", lower(trim(col("PrimarySmtpAddress"))))
        .withColumn("email_addresses", col("EmailAddresses"))
        .withColumn("alias", col("Alias"))
        .withColumn("recipient_type", col("RecipientType"))
        .withColumn("recipient_type_details", col("RecipientTypeDetails"))
        .withColumn("department", col("Department"))
        .withColumn("company", col("Company"))
        .withColumn("title", col("Title"))
        .withColumn("external_directory_object_id", col("ExternalDirectoryObjectId"))
        .withColumn("is_dir_synced", col("IsDirSynced").cast("boolean"))
        .withColumn("hidden_from_gal", col("HiddenFromAddressListsEnabled").cast("boolean"))
        .withColumn("source_created_at", to_timestamp(col("WhenCreated")))
        .withColumn("source_changed_at", to_timestamp(col("WhenChanged")))
        .withColumn("last_updated_at", col("_dlt_ingested_at"))
        .select(
            "mail_user_id", "guid", "environment", "tenant_name",
            "display_name", "first_name", "last_name",
            "external_email_address", "primary_smtp_address", "email_addresses", "alias",
            "recipient_type", "recipient_type_details",
            "department", "company", "title",
            "external_directory_object_id", "is_dir_synced", "hidden_from_gal",
            "source_created_at", "source_changed_at", "last_updated_at"
        )
    )

dlt.create_streaming_table(
    name="mail_users",
    comment="Deduplicated mail users (external members) from target tenant. SCD Type 1.",
    table_properties={"quality": "silver", "pipelines.autoOptimize.managed": "true"}
)

dlt.apply_changes(
    target="mail_users",
    source="mail_users_staged",
    keys=["mail_user_id"],
    sequence_by=col("last_updated_at"),
    stored_as_scd_type=1
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Silver Tables - OneDrive Sites

# COMMAND ----------

@dlt.table(
    name="onedrive_sites_staged",
    comment="Staged OneDrive site records before deduplication",
    temporary=True
)
@dlt.expect_or_drop("valid_id", "drive_id IS NOT NULL")
def onedrive_sites_staged():
    return (
        spark.readStream.table(f"{CATALOG}.{BRONZE_SCHEMA}.onedrive_sites_source")
        .select(explode(col("data.sites")).alias("site"), col("batch_id"), col("_dlt_ingested_at"), col("_environment"))
        .select(col("site.*"), col("batch_id"), col("_dlt_ingested_at"), col("_environment"))
        .withColumn("onedrive_id", concat_ws("_", col("_environment"), col("id")))
        .withColumn("drive_id", col("id"))
        .withColumn("environment", col("_environment"))
        .withColumn("tenant_name", tenant_name_col())
        .withColumn("web_url", col("webUrl"))
        .withColumn("owner_email", lower(trim(col("owner_email"))))
        .withColumn("quota_used_bytes", col("quota_used").cast("long"))
        .withColumn("quota_total_bytes", col("quota_total").cast("long"))
        .withColumn("quota_used_gb", spark_round(col("quota_used").cast("double") / 1073741824, 2))
        .withColumn("source_created_at", to_timestamp(col("createdDateTime")))
        .withColumn("source_modified_at", to_timestamp(col("lastModifiedDateTime")))
        .withColumn("last_updated_at", col("_dlt_ingested_at"))
        .select(
            "onedrive_id", "drive_id", "environment", "tenant_name",
            "web_url", "owner_id", "owner_email",
            "quota_used_bytes", "quota_total_bytes", "quota_used_gb",
            "source_created_at", "source_modified_at", "last_updated_at"
        )
    )

dlt.create_streaming_table(
    name="onedrive_sites",
    comment="OneDrive sites from source tenant. SCD Type 1.",
    table_properties={"quality": "silver", "pipelines.autoOptimize.managed": "true"}
)

dlt.apply_changes(
    target="onedrive_sites",
    source="onedrive_sites_staged",
    keys=["onedrive_id"],
    sequence_by=col("last_updated_at"),
    stored_as_scd_type=1
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Silver Tables - SharePoint Sites

# COMMAND ----------

@dlt.table(
    name="sharepoint_sites_staged",
    comment="Staged SharePoint site records before deduplication",
    temporary=True
)
@dlt.expect_or_drop("valid_id", "sharepoint_id IS NOT NULL")
def sharepoint_sites_staged():
    df = safe_explode_data(
        spark.readStream.table(f"{CATALOG}.{BRONZE_SCHEMA}.sharepoint_sites_source")
    )
    return (
        df
        .select(explode(col("data")).alias("site"), col("batch_id"), col("_dlt_ingested_at"), col("_environment"))
        .select(col("site.*"), col("batch_id"), col("_dlt_ingested_at"), col("_environment"))
        .withColumn("site_id", concat_ws("_", col("_environment"), col("id")))
        .withColumn("sharepoint_id", col("id"))
        .withColumn("environment", col("_environment"))
        .withColumn("tenant_name", tenant_name_col())
        .withColumn("site_name", col("name"))
        .withColumn("display_name", trim(col("displayName")))
        .withColumn("web_url", col("webUrl"))
        .withColumn("source_created_at", to_timestamp(col("createdDateTime")))
        .withColumn("source_modified_at", to_timestamp(col("lastModifiedDateTime")))
        .withColumn("last_updated_at", col("_dlt_ingested_at"))
        .select(
            "site_id", "sharepoint_id", "environment", "tenant_name",
            "site_name", "display_name", "web_url",
            "source_created_at", "source_modified_at", "last_updated_at"
        )
    )

dlt.create_streaming_table(
    name="sharepoint_sites",
    comment="SharePoint site collections from source tenant. SCD Type 1.",
    table_properties={"quality": "silver", "pipelines.autoOptimize.managed": "true"}
)

dlt.apply_changes(
    target="sharepoint_sites",
    source="sharepoint_sites_staged",
    keys=["site_id"],
    sequence_by=col("last_updated_at"),
    stored_as_scd_type=1
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Silver Tables - Contact Entity Mapping

# COMMAND ----------

@dlt.table(
    name="contact_entity_mapping",
    comment="System-level mapping of contacts to users/groups based on email address match across tenants.",
    table_properties={"quality": "silver", "pipelines.autoOptimize.managed": "true"}
)
def contact_entity_mapping():
    contacts = dlt.read("contacts").filter(col("mail").isNotNull())
    users = dlt.read("users")
    groups = dlt.read("groups")

    users_exploded = (
        users.filter(col("proxy_addresses").isNotNull())
        .select(
            col("user_id").alias("matched_entity_id"),
            col("environment").alias("matched_entity_environment"),
            explode(col("proxy_addresses")).alias("raw_address")
        )
        .withColumn("clean_address",
            lower(regexp_replace(col("raw_address"), "^(?i)(smtp:|sip:|x500:|x400:)", ""))
        )
        .filter(col("clean_address") != "")
        .distinct()
    )

    groups_exploded = (
        groups.filter(col("proxy_addresses").isNotNull())
        .select(
            col("group_id").alias("matched_entity_id"),
            col("environment").alias("matched_entity_environment"),
            explode(col("proxy_addresses")).alias("raw_address")
        )
        .withColumn("clean_address",
            lower(regexp_replace(col("raw_address"), "^(?i)(smtp:|sip:|x500:|x400:)", ""))
        )
        .filter(col("clean_address") != "")
        .distinct()
    )

    user_matches = (
        contacts.alias("c")
        .join(
            users_exploded.alias("u"),
            (col("c.mail") == col("u.clean_address"))
            & (col("c.environment") != col("u.matched_entity_environment")),
            "inner"
        )
        .select(
            concat_ws("_", col("c.contact_id"), col("u.matched_entity_id")).alias("mapping_id"),
            col("c.contact_id"),
            col("c.environment").alias("contact_environment"),
            col("c.mail").alias("contact_mail"),
            lit("user").alias("matched_entity_type"),
            col("u.matched_entity_id"),
            col("u.matched_entity_environment"),
            col("u.raw_address").alias("matched_on_address"),
            current_timestamp().alias("mapped_at"),
            lit("email_match").alias("mapping_rule")
        )
    )

    group_matches = (
        contacts.alias("c")
        .join(
            groups_exploded.alias("g"),
            (col("c.mail") == col("g.clean_address"))
            & (col("c.environment") != col("g.matched_entity_environment")),
            "inner"
        )
        .select(
            concat_ws("_", col("c.contact_id"), col("g.matched_entity_id")).alias("mapping_id"),
            col("c.contact_id"),
            col("c.environment").alias("contact_environment"),
            col("c.mail").alias("contact_mail"),
            lit("group").alias("matched_entity_type"),
            col("g.matched_entity_id"),
            col("g.matched_entity_environment"),
            col("g.raw_address").alias("matched_on_address"),
            current_timestamp().alias("mapped_at"),
            lit("email_match").alias("mapping_rule")
        )
    )

    return user_matches.unionByName(group_matches).dropDuplicates(["mapping_id"])

# COMMAND ----------

# MAGIC %md
# MAGIC ## Silver Tables - User Mapping Candidates
# MAGIC 
# MAGIC **Two Matching Contexts:**
# MAGIC - `primary_migration`: Source Member → Target Member (migration target account)
# MAGIC - `external_linkage`: Source Member → Target External Member (pre-existing corp access)
# MAGIC 
# MAGIC **Matching Passes (per Owen's feedback - different AD forests):**
# MAGIC 
# MAGIC | Pass | Match Key | Score | Context | Target Type |
# MAGIC |------|-----------|-------|---------|-------------|
# MAGIC | 1 | `employee_id` | 95 | primary_migration | Member |
# MAGIC | 2 | ExternalEmailAddress → source proxyAddresses | 90 | external_linkage | External Member |
# MAGIC | 3 | Shared SMTP proxy address | 85 | external_linkage | External Member |
# MAGIC 
# MAGIC **Removed (won't work - different AD forests):**
# MAGIC - on_prem_immutable_id
# MAGIC - on_prem_security_identifier (SID)
# MAGIC - UPN local part

# COMMAND ----------

@dlt.table(
    name="user_mapping_candidates",
    comment="User mapping candidates with match_context (primary_migration/external_linkage) and target_user_type (Member/External Member).",
    table_properties={"quality": "silver", "pipelines.autoOptimize.managed": "true"}
)
def user_mapping_candidates():
    users = dlt.read("users")
    mail_users = dlt.read("mail_users")
    
    source_users = users.filter((col("environment") == "source") & (col("user_type") == "Member"))
    target_members = users.filter((col("environment") == "target") & (col("user_type") == "Member"))
    
    # --- PASS 1: employee_id match (primary_migration context) ---
    # Source Member → Target Member via employee_id
    employee_matches = (
        source_users.alias("s")
        .join(target_members.alias("t"),
              col("s.employee_id") == col("t.employee_id"), "inner")
        .filter(col("s.employee_id").isNotNull() & (col("s.employee_id") != ""))
        .select(
            col("s.user_id").alias("source_user_id"),
            col("t.user_id").alias("target_user_id"),
            lit(None).cast("string").alias("target_mail_user_id"),
            lit(95.0).cast("decimal(5,2)").alias("match_score"),
            lit("exact_employee_id").alias("match_type"),
            lit("primary_migration").alias("match_context"),
            lit("Member").alias("target_user_type")
        )
    )

    # --- PASS 2: ExternalEmailAddress → source proxyAddresses (external_linkage) ---
    # Target Mail User's ExternalEmailAddress matches source user's proxyAddresses
    source_proxies = (
        source_users.filter(col("proxy_addresses").isNotNull())
        .select(col("user_id").alias("source_user_id"),
                explode(col("proxy_addresses")).alias("raw_addr"))
        .filter(col("raw_addr").rlike("^(?i)smtp:"))
        .withColumn("clean_addr", lower(regexp_replace(col("raw_addr"), "^(?i)smtp:", "")))
        .select("source_user_id", "clean_addr")
        .distinct()
    )
    
    external_email_matches = (
        mail_users.alias("mu")
        .filter(col("mu.external_email_address").isNotNull())
        .join(source_proxies.alias("sp"),
              col("mu.external_email_address") == col("sp.clean_addr"), "inner")
        .select(
            col("sp.source_user_id"),
            lit(None).cast("string").alias("target_user_id"),
            col("mu.mail_user_id").alias("target_mail_user_id"),
            lit(90.0).cast("decimal(5,2)").alias("match_score"),
            lit("external_email_to_proxy").alias("match_type"),
            lit("external_linkage").alias("match_context"),
            lit("External Member").alias("target_user_type")
        )
        .distinct()
    )

    # --- PASS 3: Shared SMTP proxy address (external_linkage) ---
    # Source user shares SMTP proxy with target Mail User's email_addresses
    mail_user_proxies = (
        mail_users.filter(col("email_addresses").isNotNull())
        .select(col("mail_user_id"),
                explode(split(col("email_addresses"), ";")).alias("raw_addr"))
        .filter(col("raw_addr").rlike("^(?i)smtp:"))
        .withColumn("clean_addr", lower(regexp_replace(col("raw_addr"), "^(?i)smtp:", "")))
        .select("mail_user_id", "clean_addr")
        .distinct()
    )
    
    shared_proxy_matches = (
        source_proxies.alias("sp")
        .join(mail_user_proxies.alias("mup"),
              col("sp.clean_addr") == col("mup.clean_addr"), "inner")
        .select(
            col("sp.source_user_id"),
            lit(None).cast("string").alias("target_user_id"),
            col("mup.mail_user_id").alias("target_mail_user_id"),
            lit(85.0).cast("decimal(5,2)").alias("match_score"),
            lit("shared_proxy_address").alias("match_type"),
            lit("external_linkage").alias("match_context"),
            lit("External Member").alias("target_user_type")
        )
        .distinct()
    )

    # --- Combine all passes ---
    all_matches = (
        employee_matches
        .unionByName(external_email_matches)
        .unionByName(shared_proxy_matches)
    )

    # Aggregate: one row per (source_user_id, target_entity, match_context)
    # Use coalesce to get the target entity ID regardless of type
    aggregated = (
        all_matches
        .withColumn("target_entity_key", 
            coalesce(col("target_user_id"), col("target_mail_user_id")))
        .groupBy("source_user_id", "target_entity_key", "match_context")
        .agg(
            spark_max("match_score").alias("match_score"),
            collect_set("match_type").alias("match_types_arr"),
            # Keep track of actual target columns
            spark_max("target_user_id").alias("target_user_id"),
            spark_max("target_mail_user_id").alias("target_mail_user_id"),
            spark_max("target_user_type").alias("target_user_type")
        )
        .withColumn("candidate_id",
            concat_ws("_", col("source_user_id"), col("target_entity_key"), col("match_context")))
        .withColumn("match_type",
            when(array_contains(col("match_types_arr"), "exact_employee_id"), lit("exact_employee_id"))
            .when(array_contains(col("match_types_arr"), "external_email_to_proxy"), lit("external_email_to_proxy"))
            .when(array_contains(col("match_types_arr"), "shared_proxy_address"), lit("shared_proxy_address"))
            .otherwise(lit("unknown"))
        )
        .withColumn("match_attributes", concat_ws(",", col("match_types_arr")))
        # Auto-approve threshold: >= 85
        .withColumn("candidate_status",
            when(col("match_score") >= 85.0, lit("approved"))
            .otherwise(lit("pending_review"))
        )
        .withColumn("created_at", current_timestamp())
        .withColumn("updated_at", current_timestamp())
        .select(
            "candidate_id",
            "source_user_id",
            "target_user_id",
            "target_mail_user_id",
            "match_context",
            "target_user_type",
            "match_score",
            "match_type",
            "match_attributes",
            "candidate_status",
            "created_at",
            "updated_at"
        )
    )

    return aggregated

# COMMAND ----------

# MAGIC %md
# MAGIC ## Silver Tables - Group Mapping Candidates

# COMMAND ----------

@dlt.table(
    name="group_mapping_candidates",
    comment="Group mapping candidates between source and target tenants.",
    table_properties={"quality": "silver", "pipelines.autoOptimize.managed": "true"}
)
def group_mapping_candidates():
    groups = dlt.read("groups")
    source_groups = groups.filter(col("environment") == "source")
    target_groups = groups.filter(col("environment") == "target")

    # Pass 1: Exact mail match (score: 90)
    mail_matches = (
        source_groups.alias("s")
        .join(target_groups.alias("t"),
              col("s.mail") == col("t.mail"), "inner")
        .filter(col("s.mail").isNotNull())
        .select(
            col("s.group_id").alias("source_group_id"),
            col("t.group_id").alias("target_group_id"),
            lit(90.0).cast("decimal(5,2)").alias("match_score"),
            lit("exact_mail").alias("match_type")
        )
    )

    # Pass 2: Shared SMTP proxy address (score: 85)
    source_proxies = (
        source_groups.filter(col("proxy_addresses").isNotNull())
        .select(col("group_id").alias("source_group_id"),
                explode(col("proxy_addresses")).alias("raw_addr"))
        .filter(col("raw_addr").rlike("^(?i)smtp:"))
        .withColumn("clean_addr", lower(regexp_replace(col("raw_addr"), "^(?i)smtp:", "")))
        .select("source_group_id", "clean_addr")
        .distinct()
    )
    target_proxies = (
        target_groups.filter(col("proxy_addresses").isNotNull())
        .select(col("group_id").alias("target_group_id"),
                explode(col("proxy_addresses")).alias("raw_addr"))
        .filter(col("raw_addr").rlike("^(?i)smtp:"))
        .withColumn("clean_addr", lower(regexp_replace(col("raw_addr"), "^(?i)smtp:", "")))
        .select("target_group_id", "clean_addr")
        .distinct()
    )
    proxy_matches = (
        source_proxies.alias("s")
        .join(target_proxies.alias("t"),
              col("s.clean_addr") == col("t.clean_addr"), "inner")
        .select(
            col("s.source_group_id"),
            col("t.target_group_id"),
            lit(85.0).cast("decimal(5,2)").alias("match_score"),
            lit("shared_proxy_address").alias("match_type")
        )
        .distinct()
    )

    # Pass 3: Exact display_name match (score: 75)
    name_matches = (
        source_groups.alias("s")
        .join(target_groups.alias("t"),
              lower(trim(col("s.display_name"))) == lower(trim(col("t.display_name"))),
              "inner")
        .filter(col("s.display_name").isNotNull())
        .select(
            col("s.group_id").alias("source_group_id"),
            col("t.group_id").alias("target_group_id"),
            lit(75.0).cast("decimal(5,2)").alias("match_score"),
            lit("exact_display_name").alias("match_type")
        )
    )

    all_matches = (
        mail_matches
        .unionByName(proxy_matches)
        .unionByName(name_matches)
    )

    return (
        all_matches
        .groupBy("source_group_id", "target_group_id")
        .agg(
            spark_max("match_score").alias("match_score"),
            collect_set("match_type").alias("match_types_arr")
        )
        .withColumn("candidate_id",
            concat_ws("_", col("source_group_id"), col("target_group_id")))
        .withColumn("match_type",
            when(array_contains(col("match_types_arr"), "exact_mail"), lit("exact_mail"))
            .when(array_contains(col("match_types_arr"), "shared_proxy_address"), lit("shared_proxy_address"))
            .otherwise(lit("exact_display_name"))
        )
        .withColumn("match_attributes", concat_ws(",", col("match_types_arr")))
        .withColumn("candidate_status", lit("pending"))
        .withColumn("created_at", current_timestamp())
        .withColumn("updated_at", current_timestamp())
        .select(
            "candidate_id",
            "source_group_id", "target_group_id",
            "match_score", "match_type", "match_attributes",
            "candidate_status",
            "created_at", "updated_at"
        )
    )