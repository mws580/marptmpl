# Databricks notebook source
# MAGIC %md
# MAGIC # M365 Migration - Bronze Layer Pipeline
# MAGIC 
# MAGIC **Pipeline:** `pl_m365_bronze`  
# MAGIC **Target Schema:** `m365_migration.bronze`
# MAGIC 
# MAGIC ## Purpose
# MAGIC Ingests raw JSON files from ADLS landing zone using Databricks Auto Loader.
# MAGIC This is the **raw data landing zone** - no transformations, append-only.
# MAGIC 
# MAGIC ## Entity Types Ingested
# MAGIC | Entity | Source System | Description |
# MAGIC |--------|---------------|-------------|
# MAGIC | `entra_users` | Graph API | Entra ID (Azure AD) user accounts |
# MAGIC | `entra_groups` | Graph API | Entra ID security & M365 groups |
# MAGIC | `entra_contacts` | Graph API | Organizational contacts (mail contacts) |
# MAGIC | `entra_group_members` | Graph API | Group membership relationships |
# MAGIC | `exo_mailboxes` | Exchange Online | User mailboxes with sizes & holds |
# MAGIC | `exo_mail_users` | Exchange Online | Mail Users (external members) - target only |
# MAGIC | `onedrive_sites` | Graph API | OneDrive storage per user |
# MAGIC | `sharepoint_sites` | Graph API | SharePoint site collections |
# MAGIC 
# MAGIC ## JSON Wrapper Structure
# MAGIC All ingested files follow this structure:
# MAGIC ```json
# MAGIC {
# MAGIC   "tenant_id": "guid",
# MAGIC   "tenant_name": "TenantName",
# MAGIC   "batch_id": "guid",
# MAGIC   "entity_type": "entra_users",
# MAGIC   "environment": "source",
# MAGIC   "ingested_at": "2026-02-04T12:00:00Z",
# MAGIC   "record_count": 1000,
# MAGIC   "data": [ ... array of entities ... ]
# MAGIC }
# MAGIC ```
# MAGIC 
# MAGIC ## Medallion Architecture
# MAGIC ```
# MAGIC Bronze (this layer)    → Raw, append-only, schema inferred
# MAGIC Silver (pl_silver.py)  → Deduplicated, transformed, SCD Type 1
# MAGIC Gold (pl_gold.py)      → Business dimensions, aggregates
# MAGIC ```

# COMMAND ----------

import dlt
from pyspark.sql.functions import col, current_timestamp, lit, coalesce
from pyspark.sql.types import StringType

# COMMAND ----------

# MAGIC %md
# MAGIC ## Configuration

# COMMAND ----------

# Storage configuration - set via pipeline parameters or use defaults
STORAGE_ACCOUNT = spark.conf.get("storage_account", "stm365analyticsdev001")
LANDING_ZONE_BASE = f"abfss://bronze@{STORAGE_ACCOUNT}.dfs.core.windows.net/raw"
SCHEMA_BASE = f"abfss://bronze@{STORAGE_ACCOUNT}.dfs.core.windows.net/_schemas"

# COMMAND ----------

# MAGIC %md
# MAGIC ## Helper Function

# COMMAND ----------

def create_bronze_stream(entity_path: str, schema_name: str, environment: str, source_system: str = "graph_api"):
    """
    Create a bronze streaming table from ADLS landing zone.
    """
    schema_hints = "batch_id STRING, tenant_id STRING, tenant_name STRING, entity_type STRING, environment STRING, ingested_at STRING, record_count LONG"
    
    return (
        spark.readStream
        .format("cloudFiles")
        .option("cloudFiles.format", "json")
        .option("cloudFiles.schemaLocation", f"{SCHEMA_BASE}/{schema_name}")
        .option("cloudFiles.schemaHints", schema_hints)
        .option("cloudFiles.inferColumnTypes", "true")
        .option("cloudFiles.schemaEvolutionMode", "addNewColumns")
        .option("multiLine", "true")
        .load(f"{LANDING_ZONE_BASE}/{entity_path}")
        .withColumn("_dlt_ingested_at", current_timestamp())
        .withColumn("_source_file", col("_metadata.file_path"))
        .withColumn("_source_system", lit(source_system))
        .withColumn("_environment", lit(environment))
        .withColumn("batch_id", coalesce(col("batch_id"), lit(None).cast(StringType())))
        .withColumn("tenant_id", coalesce(col("tenant_id"), lit(None).cast(StringType())))
        .withColumn("tenant_name", coalesce(col("tenant_name"), lit(None).cast(StringType())))
        .withColumn("entity_type", coalesce(col("entity_type"), lit(None).cast(StringType())))
        .withColumn("ingested_at", coalesce(col("ingested_at"), lit(None).cast(StringType())))
        .withColumn("record_count", coalesce(col("record_count"), lit(None)))
    )

# COMMAND ----------

# MAGIC %md
# MAGIC ## Bronze Tables - Entra ID Users

# COMMAND ----------

@dlt.table(
    name="entra_users_source",
    comment="Raw user data from source tenant - append only.",
    table_properties={
        "quality": "bronze",
        "pipelines.autoOptimize.managed": "true",
        "delta.autoOptimize.optimizeWrite": "true",
        "delta.autoOptimize.autoCompact": "true",
        "delta.columnMapping.mode": "name"
    }
)
@dlt.expect("has_data_array", "data IS NOT NULL")
@dlt.expect("has_batch_id", "batch_id IS NOT NULL")
def entra_users_source():
    return create_bronze_stream("entra_users/source", "entra_users_source", "source")

# COMMAND ----------

@dlt.table(
    name="entra_users_target",
    comment="Raw user data from target tenant - append only.",
    table_properties={
        "quality": "bronze",
        "pipelines.autoOptimize.managed": "true",
        "delta.autoOptimize.optimizeWrite": "true",
        "delta.autoOptimize.autoCompact": "true",
        "delta.columnMapping.mode": "name"
    }
)
@dlt.expect("has_data_array", "data IS NOT NULL")
@dlt.expect("has_batch_id", "batch_id IS NOT NULL")
def entra_users_target():
    return create_bronze_stream("entra_users/target", "entra_users_target", "target")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Bronze Tables - Entra ID Groups

# COMMAND ----------

@dlt.table(
    name="entra_groups_source",
    comment="Raw group data from source tenant - append only.",
    table_properties={
        "quality": "bronze",
        "pipelines.autoOptimize.managed": "true",
        "delta.autoOptimize.optimizeWrite": "true",
        "delta.autoOptimize.autoCompact": "true",
        "delta.columnMapping.mode": "name"
    }
)
@dlt.expect("has_data_array", "data IS NOT NULL")
@dlt.expect("has_batch_id", "batch_id IS NOT NULL")
def entra_groups_source():
    return create_bronze_stream("entra_groups/source", "entra_groups_source", "source")

# COMMAND ----------

@dlt.table(
    name="entra_groups_target",
    comment="Raw group data from target tenant - append only.",
    table_properties={
        "quality": "bronze",
        "pipelines.autoOptimize.managed": "true",
        "delta.autoOptimize.optimizeWrite": "true",
        "delta.autoOptimize.autoCompact": "true",
        "delta.columnMapping.mode": "name"
    }
)
@dlt.expect("has_data_array", "data IS NOT NULL")
@dlt.expect("has_batch_id", "batch_id IS NOT NULL")
def entra_groups_target():
    return create_bronze_stream("entra_groups/target", "entra_groups_target", "target")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Bronze Tables - Entra ID Contacts

# COMMAND ----------

@dlt.table(
    name="entra_contacts_source",
    comment="Raw organizational contact data from source tenant - append only.",
    table_properties={
        "quality": "bronze",
        "pipelines.autoOptimize.managed": "true",
        "delta.autoOptimize.optimizeWrite": "true",
        "delta.autoOptimize.autoCompact": "true",
        "delta.columnMapping.mode": "name"
    }
)
@dlt.expect("has_data_array", "data IS NOT NULL")
@dlt.expect("has_batch_id", "batch_id IS NOT NULL")
def entra_contacts_source():
    return create_bronze_stream("entra_contacts/source", "entra_contacts_source", "source")

# COMMAND ----------

@dlt.table(
    name="entra_contacts_target",
    comment="Raw organizational contact data from target tenant - append only.",
    table_properties={
        "quality": "bronze",
        "pipelines.autoOptimize.managed": "true",
        "delta.autoOptimize.optimizeWrite": "true",
        "delta.autoOptimize.autoCompact": "true",
        "delta.columnMapping.mode": "name"
    }
)
@dlt.expect("has_data_array", "data IS NOT NULL")
@dlt.expect("has_batch_id", "batch_id IS NOT NULL")
def entra_contacts_target():
    return create_bronze_stream("entra_contacts/target", "entra_contacts_target", "target")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Bronze Tables - Group Memberships

# COMMAND ----------

@dlt.table(
    name="entra_group_members_source",
    comment="Raw group membership data from source tenant - append only.",
    table_properties={
        "quality": "bronze",
        "pipelines.autoOptimize.managed": "true",
        "delta.autoOptimize.optimizeWrite": "true",
        "delta.autoOptimize.autoCompact": "true",
        "delta.columnMapping.mode": "name"
    }
)
@dlt.expect("has_data_array", "data IS NOT NULL")
@dlt.expect("has_batch_id", "batch_id IS NOT NULL")
def entra_group_members_source():
    return create_bronze_stream("entra_group_members/source", "entra_group_members_source", "source")

# COMMAND ----------

@dlt.table(
    name="entra_group_members_target",
    comment="Raw group membership data from target tenant - append only.",
    table_properties={
        "quality": "bronze",
        "pipelines.autoOptimize.managed": "true",
        "delta.autoOptimize.optimizeWrite": "true",
        "delta.autoOptimize.autoCompact": "true",
        "delta.columnMapping.mode": "name"
    }
)
@dlt.expect("has_data_array", "data IS NOT NULL")
@dlt.expect("has_batch_id", "batch_id IS NOT NULL")
def entra_group_members_target():
    return create_bronze_stream("entra_group_members/target", "entra_group_members_target", "target")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Bronze Tables - Exchange Online Mailboxes

# COMMAND ----------

@dlt.table(
    name="exo_mailboxes_source",
    comment="Raw mailbox data from source tenant - append only.",
    table_properties={
        "quality": "bronze",
        "pipelines.autoOptimize.managed": "true",
        "delta.autoOptimize.optimizeWrite": "true",
        "delta.autoOptimize.autoCompact": "true",
        "delta.columnMapping.mode": "name"
    }
)
@dlt.expect("has_data_array", "data IS NOT NULL")
@dlt.expect("has_batch_id", "batch_id IS NOT NULL")
def exo_mailboxes_source():
    return create_bronze_stream("exo_mailboxes/source", "exo_mailboxes_source", "source", "exchange_online")

# COMMAND ----------

@dlt.table(
    name="exo_mailboxes_target",
    comment="Raw mailbox data from target tenant - append only.",
    table_properties={
        "quality": "bronze",
        "pipelines.autoOptimize.managed": "true",
        "delta.autoOptimize.optimizeWrite": "true",
        "delta.autoOptimize.autoCompact": "true",
        "delta.columnMapping.mode": "name"
    }
)
@dlt.expect("has_data_array", "data IS NOT NULL")
@dlt.expect("has_batch_id", "batch_id IS NOT NULL")
def exo_mailboxes_target():
    return create_bronze_stream("exo_mailboxes/target", "exo_mailboxes_target", "target", "exchange_online")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Bronze Tables - Exchange Online Mail Users (External Members)
# MAGIC 
# MAGIC **Entity:** Mail Users from Exchange Online (target tenant only)  
# MAGIC **Source:** Exchange Online PowerShell (Get-MailUser)  
# MAGIC **Key Fields:** Guid, ExternalEmailAddress, PrimarySmtpAddress, EmailAddresses
# MAGIC 
# MAGIC Mail Users are **external members** whose primary mailbox is in an external org.
# MAGIC The `ExternalEmailAddress` (targetAddress) points to their source tenant mailbox.
# MAGIC Critical for **external linkage** identity matching.

# COMMAND ----------

@dlt.table(
    name="exo_mail_users_target",
    comment="Raw mail user (external member) data from target tenant - append only. ExternalEmailAddress used for identity linkage.",
    table_properties={
        "quality": "bronze",
        "pipelines.autoOptimize.managed": "true",
        "delta.autoOptimize.optimizeWrite": "true",
        "delta.autoOptimize.autoCompact": "true",
        "delta.columnMapping.mode": "name"
    }
)
@dlt.expect("has_data_array", "data IS NOT NULL")
@dlt.expect("has_batch_id", "batch_id IS NOT NULL")
def exo_mail_users_target():
    return create_bronze_stream("exo_mail_users/target", "exo_mail_users_target", "target", "exchange_online")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Bronze Tables - OneDrive for Business

# COMMAND ----------

@dlt.table(
    name="onedrive_sites_source",
    comment="Raw OneDrive site data from source tenant - append only.",
    table_properties={
        "quality": "bronze",
        "pipelines.autoOptimize.managed": "true",
        "delta.autoOptimize.optimizeWrite": "true",
        "delta.autoOptimize.autoCompact": "true",
        "delta.columnMapping.mode": "name"
    }
)
@dlt.expect("has_data_array", "data IS NOT NULL")
@dlt.expect("has_batch_id", "batch_id IS NOT NULL")
def onedrive_sites_source():
    return create_bronze_stream("onedrive_sites/source", "onedrive_sites_source", "source")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Bronze Tables - SharePoint Sites

# COMMAND ----------

@dlt.table(
    name="sharepoint_sites_source",
    comment="Raw SharePoint site collection data from source tenant - append only.",
    table_properties={
        "quality": "bronze",
        "pipelines.autoOptimize.managed": "true",
        "delta.autoOptimize.optimizeWrite": "true",
        "delta.autoOptimize.autoCompact": "true",
        "delta.columnMapping.mode": "name"
    }
)
@dlt.expect("has_data_array", "data IS NOT NULL")
@dlt.expect("has_batch_id", "batch_id IS NOT NULL")
def sharepoint_sites_source():
    return create_bronze_stream("sharepoint_sites/source", "sharepoint_sites_source", "source")