-- ============================================================================
-- Unity Catalog Setup - Configuration
-- ============================================================================
-- INSTRUCTIONS: Edit the variables below before running subsequent scripts.
-- Run this script first in a Databricks SQL notebook to set up widgets.
-- 
-- UPDATED: January 2026 - New M365 Migration Toolkit naming convention
-- ============================================================================

-- Remove existing widgets if re-running
REMOVE WIDGET IF EXISTS storage_account_name;
REMOVE WIDGET IF EXISTS resource_group;
REMOVE WIDGET IF EXISTS subscription_id;
REMOVE WIDGET IF EXISTS access_connector_name;
REMOVE WIDGET IF EXISTS credential_name;
REMOVE WIDGET IF EXISTS catalog_name;
REMOVE WIDGET IF EXISTS environment;

-- ============================================================================
-- EDIT THESE VALUES FOR YOUR ENVIRONMENT
-- ============================================================================

-- Azure Resource Names (M365 Migration Toolkit naming convention)
CREATE WIDGET TEXT storage_account_name DEFAULT 'stm365analyticsdev001';
CREATE WIDGET TEXT resource_group DEFAULT 'rg-m365-analytics-dev-eastus2-001';
CREATE WIDGET TEXT subscription_id DEFAULT '<your-subscription-id>';
CREATE WIDGET TEXT access_connector_name DEFAULT 'ac-m365-analytics-dev';

-- Unity Catalog Names
CREATE WIDGET TEXT credential_name DEFAULT 'cred-adls-m365';
CREATE WIDGET TEXT catalog_name DEFAULT 'm365_migration';

-- Environment identifier (for tracking)
CREATE WIDGET TEXT environment DEFAULT 'dev';

-- ============================================================================
-- DISPLAY CURRENT CONFIGURATION
-- ============================================================================

SELECT 
  'Configuration Summary' as section,
  getArgument('environment') as environment,
  getArgument('storage_account_name') as storage_account,
  getArgument('resource_group') as resource_group,
  getArgument('access_connector_name') as access_connector,
  getArgument('catalog_name') as catalog_name,
  getArgument('credential_name') as credential_name;

-- ============================================================================
-- RESOURCE NAMING CONVENTION
-- ============================================================================
-- Resource Group:     rg-m365-{subsystem}-{env}-{region}-{instance}
-- Storage Account:    st{purpose}{env}{instance}
-- Access Connector:   ac-m365-{subsystem}-{env}
-- Key Vault:          kv-m365-{env}-{instance}
-- Databricks:         dbw-m365-{subsystem}-{env}-{region}
-- Catalog:            m365_migration
-- Credential:         cred-adls-m365
-- External Locations: bronze, silver, gold
-- ============================================================================
