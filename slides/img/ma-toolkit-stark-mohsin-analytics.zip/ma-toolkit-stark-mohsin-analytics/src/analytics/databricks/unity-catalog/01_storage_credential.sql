-- ============================================================================
-- Unity Catalog Setup - Step 1: Storage Credential
-- ============================================================================
-- PREREQUISITES:
--   1. Run 00_config.sql first to set up widgets
--   2. Access Connector must exist in Azure with Storage Blob Data Contributor 
--      role on the storage account
--   3. You must be a Metastore Admin or have CREATE STORAGE CREDENTIAL privilege
-- ============================================================================

-- Build the Access Connector Resource ID
-- Format: /subscriptions/{sub}/resourceGroups/{rg}/providers/Microsoft.Databricks/accessConnectors/{name}

DECLARE OR REPLACE access_connector_id STRING;
SET VAR access_connector_id = CONCAT(
  '/subscriptions/', getArgument('subscription_id'),
  '/resourceGroups/', getArgument('resource_group'),
  '/providers/Microsoft.Databricks/accessConnectors/', getArgument('access_connector_name')
);

-- Display what we're about to create
SELECT 
  'Creating Storage Credential' as action,
  getArgument('credential_name') as credential_name,
  access_connector_id as access_connector_resource_id;

-- ============================================================================
-- CREATE STORAGE CREDENTIAL
-- ============================================================================

CREATE STORAGE CREDENTIAL IF NOT EXISTS IDENTIFIER(getArgument('credential_name'))
WITH (
  AZURE_MANAGED_IDENTITY = (
    ACCESS_CONNECTOR_ID = access_connector_id
  )
);

-- Verify creation
DESCRIBE STORAGE CREDENTIAL IDENTIFIER(getArgument('credential_name'));

-- ============================================================================
-- GRANT PERMISSIONS (Optional - adjust as needed)
-- ============================================================================
-- Uncomment and modify the following to grant access to specific groups/users

-- GRANT CREATE EXTERNAL LOCATION ON STORAGE CREDENTIAL IDENTIFIER(getArgument('credential_name')) 
-- TO `data-engineers@yourdomain.com`;

-- GRANT READ FILES ON STORAGE CREDENTIAL IDENTIFIER(getArgument('credential_name'))
-- TO `data-analysts@yourdomain.com`;

SELECT 'Storage Credential created successfully' as status;
