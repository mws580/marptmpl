-- ============================================================================
-- Unity Catalog Setup - Step 3: Catalog and Schemas
-- ============================================================================
-- PREREQUISITES:
--   1. Run 00_config.sql first to set up widgets
--   2. Run 01_storage_credential.sql and 02_external_locations.sql
--   3. You must be a Metastore Admin or have CREATE CATALOG privilege
-- ============================================================================

-- Display what we're about to create
SELECT 
  'Creating Catalog and Schemas' as action,
  getArgument('catalog_name') as catalog_name,
  getArgument('environment') as environment;

-- ============================================================================
-- CREATE CATALOG
-- ============================================================================

CREATE CATALOG IF NOT EXISTS IDENTIFIER(getArgument('catalog_name'))
COMMENT CONCAT('M365 Migration Data Platform - ', getArgument('environment'), ' environment');

-- Set as current catalog for subsequent operations
USE CATALOG IDENTIFIER(getArgument('catalog_name'));

-- ============================================================================
-- CREATE SCHEMAS (Medallion Architecture)
-- ============================================================================

-- BRONZE Schema - Raw ingested data
CREATE SCHEMA IF NOT EXISTS bronze
MANAGED LOCATION CONCAT('abfss://bronze@', getArgument('storage_account_name'), '.dfs.core.windows.net/tables')
COMMENT 'Bronze layer - raw data as ingested from source systems';

-- SILVER Schema - Cleansed and conformed
CREATE SCHEMA IF NOT EXISTS silver
MANAGED LOCATION CONCAT('abfss://silver@', getArgument('storage_account_name'), '.dfs.core.windows.net/tables')
COMMENT 'Silver layer - cleansed, validated, and conformed data';

-- GOLD Schema - Business-ready data products
CREATE SCHEMA IF NOT EXISTS gold
MANAGED LOCATION CONCAT('abfss://gold@', getArgument('storage_account_name'), '.dfs.core.windows.net/tables')
COMMENT 'Gold layer - aggregated and business-ready data products';

-- ============================================================================
-- OPTIONAL: Additional Utility Schemas
-- ============================================================================

-- Staging schema for intermediate processing
CREATE SCHEMA IF NOT EXISTS staging
COMMENT 'Staging area for data processing workflows';

-- Audit/logging schema
CREATE SCHEMA IF NOT EXISTS audit
COMMENT 'Pipeline audit logs and data quality metrics';

-- ============================================================================
-- VERIFY CREATION
-- ============================================================================

SHOW SCHEMAS IN IDENTIFIER(getArgument('catalog_name'));

-- ============================================================================
-- GRANT PERMISSIONS (Adjust as needed)
-- ============================================================================

-- Grant usage on catalog to all account users (dev environment)
GRANT USE CATALOG ON CATALOG IDENTIFIER(getArgument('catalog_name')) TO `account users`;
GRANT USE SCHEMA ON SCHEMA bronze TO `account users`;
GRANT USE SCHEMA ON SCHEMA silver TO `account users`;
GRANT USE SCHEMA ON SCHEMA gold TO `account users`;

-- Grant create/modify for data engineers
GRANT CREATE TABLE ON SCHEMA bronze TO `account users`;
GRANT CREATE TABLE ON SCHEMA silver TO `account users`;
GRANT CREATE TABLE ON SCHEMA gold TO `account users`;

-- More restrictive example (production):
-- GRANT USE CATALOG ON CATALOG IDENTIFIER(getArgument('catalog_name')) TO `data-team@yourdomain.com`;
-- GRANT SELECT ON SCHEMA gold TO `analysts@yourdomain.com`;

SELECT 'Catalog and Schemas created successfully' as status;
