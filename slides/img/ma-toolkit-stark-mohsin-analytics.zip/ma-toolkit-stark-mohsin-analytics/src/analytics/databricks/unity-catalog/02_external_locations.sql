-- ============================================================================
-- Unity Catalog Setup - Step 2: External Locations
-- ============================================================================
-- PREREQUISITES:
--   1. Run 00_config.sql first to set up widgets
--   2. Run 01_storage_credential.sql to create the credential
--   3. You must be a Metastore Admin or have CREATE EXTERNAL LOCATION privilege
-- ============================================================================

-- Build the base storage URL
DECLARE OR REPLACE storage_base_url STRING;
SET VAR storage_base_url = CONCAT(
  'abfss://',
  '@',
  getArgument('storage_account_name'),
  '.dfs.core.windows.net'
);

-- Display what we're about to create
SELECT 
  'Creating External Locations' as action,
  getArgument('storage_account_name') as storage_account,
  getArgument('credential_name') as using_credential;

-- ============================================================================
-- CREATE EXTERNAL LOCATIONS
-- ============================================================================

-- BRONZE (Raw ingestion layer)
CREATE EXTERNAL LOCATION IF NOT EXISTS bronze
URL CONCAT('abfss://bronze@', getArgument('storage_account_name'), '.dfs.core.windows.net')
WITH (STORAGE CREDENTIAL IDENTIFIER(getArgument('credential_name')))
COMMENT 'Bronze layer - raw ingested data';

-- SILVER (Cleansed/transformed layer)
CREATE EXTERNAL LOCATION IF NOT EXISTS silver
URL CONCAT('abfss://silver@', getArgument('storage_account_name'), '.dfs.core.windows.net')
WITH (STORAGE CREDENTIAL IDENTIFIER(getArgument('credential_name')))
COMMENT 'Silver layer - cleansed and conformed data';

-- GOLD (Business-ready layer)
CREATE EXTERNAL LOCATION IF NOT EXISTS gold
URL CONCAT('abfss://gold@', getArgument('storage_account_name'), '.dfs.core.windows.net')
WITH (STORAGE CREDENTIAL IDENTIFIER(getArgument('credential_name')))
COMMENT 'Gold layer - business-ready data products';

-- ============================================================================
-- VERIFY CREATION
-- ============================================================================

SHOW EXTERNAL LOCATIONS;

-- ============================================================================
-- GRANT PERMISSIONS (Adjust as needed for your environment)
-- ============================================================================
-- By default, only creator has access. Uncomment and modify as needed.

-- Grant all privileges to all account users (dev environment - permissive)
GRANT ALL PRIVILEGES ON EXTERNAL LOCATION bronze TO `account users`;
GRANT ALL PRIVILEGES ON EXTERNAL LOCATION silver TO `account users`;
GRANT ALL PRIVILEGES ON EXTERNAL LOCATION gold TO `account users`;

-- More restrictive example (production):
-- GRANT READ FILES ON EXTERNAL LOCATION bronze TO `data-engineers@yourdomain.com`;
-- GRANT WRITE FILES ON EXTERNAL LOCATION bronze TO `data-engineers@yourdomain.com`;
-- GRANT READ FILES ON EXTERNAL LOCATION silver TO `data-analysts@yourdomain.com`;
-- GRANT READ FILES ON EXTERNAL LOCATION gold TO `report-users@yourdomain.com`;

SELECT 'External Locations created successfully' as status;
