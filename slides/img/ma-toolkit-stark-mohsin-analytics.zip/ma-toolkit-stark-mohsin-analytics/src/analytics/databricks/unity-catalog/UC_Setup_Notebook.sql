-- Databricks notebook source
-- MAGIC %md
-- MAGIC # Unity Catalog Setup - M365 Migration
-- MAGIC 
-- MAGIC This notebook configures Unity Catalog for the M365 Migration data platform.
-- MAGIC 
-- MAGIC **Run cells in order:**
-- MAGIC 1. Configuration (edit values first!)
-- MAGIC 2. Storage Credential
-- MAGIC 3. External Locations
-- MAGIC 4. Catalog and Schemas
-- MAGIC 5. Validation
-- MAGIC 
-- MAGIC **Prerequisites:**
-- MAGIC - Access Connector for Azure Databricks exists with Storage Blob Data Contributor role
-- MAGIC - ADLS Gen2 storage account with bronze/silver/gold containers
-- MAGIC - User has Metastore Admin privileges (or appropriate CREATE privileges)

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ## 1. Configuration
-- MAGIC **EDIT THESE VALUES FOR YOUR ENVIRONMENT**

-- COMMAND ----------

-- Remove existing widgets if re-running
REMOVE WIDGET IF EXISTS storage_account_name;
REMOVE WIDGET IF EXISTS resource_group;
REMOVE WIDGET IF EXISTS subscription_id;
REMOVE WIDGET IF EXISTS access_connector_name;
REMOVE WIDGET IF EXISTS credential_name;
REMOVE WIDGET IF EXISTS catalog_name;
REMOVE WIDGET IF EXISTS environment;

-- ============================================================================
-- EDIT THESE DEFAULT VALUES FOR YOUR ENVIRONMENT
-- ============================================================================
-- All placeholder values (starting with '<' and ending with '>') MUST be 
-- replaced with your actual Azure resource names before running this notebook.
-- ============================================================================

-- Azure Resource Names (UPDATE ALL PLACEHOLDERS)
CREATE WIDGET TEXT storage_account_name DEFAULT '<your-storage-account-name>';
CREATE WIDGET TEXT resource_group DEFAULT '<your-resource-group-name>';
CREATE WIDGET TEXT subscription_id DEFAULT '<your-subscription-id>';
CREATE WIDGET TEXT access_connector_name DEFAULT '<your-access-connector-name>';

-- Unity Catalog Names
CREATE WIDGET TEXT credential_name DEFAULT 'cred-adls-m365';
CREATE WIDGET TEXT catalog_name DEFAULT 'm365_migration';

-- Environment identifier (dev, test, prod)
CREATE WIDGET TEXT environment DEFAULT 'dev';

-- COMMAND ----------

-- Validate configuration - check for placeholder values
SELECT 
  CASE 
    WHEN getArgument('storage_account_name') LIKE '<%>' 
      OR getArgument('resource_group') LIKE '<%>'
      OR getArgument('subscription_id') LIKE '<%>'
      OR getArgument('access_connector_name') LIKE '<%>'
    THEN 'WARNING: Placeholder values detected! Update widget values before proceeding.'
    ELSE 'OK: Configuration values have been set'
  END as config_status;

-- COMMAND ----------

-- Display current configuration
SELECT 
  'Current Configuration' as section,
  getArgument('environment') as environment,
  getArgument('storage_account_name') as storage_account,
  getArgument('catalog_name') as catalog_name,
  getArgument('credential_name') as credential_name,
  getArgument('access_connector_name') as access_connector;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ## 2. Storage Credential
-- MAGIC Creates a storage credential linked to the Azure Access Connector (Managed Identity)

-- COMMAND ----------

-- Build Access Connector Resource ID
DECLARE OR REPLACE access_connector_id STRING;
SET VAR access_connector_id = CONCAT(
  '/subscriptions/', getArgument('subscription_id'),
  '/resourceGroups/', getArgument('resource_group'),
  '/providers/Microsoft.Databricks/accessConnectors/', getArgument('access_connector_name')
);

-- Show what we're creating
SELECT 
  'Creating Storage Credential' as action,
  getArgument('credential_name') as credential_name,
  access_connector_id as access_connector_resource_id;

-- COMMAND ----------

-- Create the storage credential
CREATE STORAGE CREDENTIAL IF NOT EXISTS IDENTIFIER(getArgument('credential_name'))
WITH (
  AZURE_MANAGED_IDENTITY = (
    ACCESS_CONNECTOR_ID = CONCAT(
      '/subscriptions/', getArgument('subscription_id'),
      '/resourceGroups/', getArgument('resource_group'),
      '/providers/Microsoft.Databricks/accessConnectors/', getArgument('access_connector_name')
    )
  )
);

-- COMMAND ----------

-- Verify storage credential
DESCRIBE STORAGE CREDENTIAL IDENTIFIER(getArgument('credential_name'));

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ## 3. External Locations
-- MAGIC Creates external locations for Bronze, Silver, and Gold storage containers
-- MAGIC 
-- MAGIC > **SECURITY WARNING**: The grants below use `ALL PRIVILEGES` to `account users` for development convenience.
-- MAGIC > **For production environments**, replace with least-privilege access:
-- MAGIC > 
-- MAGIC > ```sql
-- MAGIC > -- Production example: Grant specific permissions to specific groups
-- MAGIC > -- Data Engineers: Can read/write to bronze, read silver
-- MAGIC > GRANT READ FILES, WRITE FILES ON EXTERNAL LOCATION bronze TO `data-engineers`;
-- MAGIC > GRANT READ FILES ON EXTERNAL LOCATION silver TO `data-engineers`;
-- MAGIC > 
-- MAGIC > -- Data Scientists: Read-only access to silver and gold
-- MAGIC > GRANT READ FILES ON EXTERNAL LOCATION silver TO `data-scientists`;
-- MAGIC > GRANT READ FILES ON EXTERNAL LOCATION gold TO `data-scientists`;
-- MAGIC > 
-- MAGIC > -- BI/Analysts: Read-only access to gold only
-- MAGIC > GRANT READ FILES ON EXTERNAL LOCATION gold TO `analysts`;
-- MAGIC > ```

-- COMMAND ----------

-- Show what we're creating
SELECT 
  'Creating External Locations' as action,
  getArgument('storage_account_name') as storage_account,
  getArgument('credential_name') as using_credential;

-- COMMAND ----------

-- BRONZE - Raw ingestion layer
CREATE EXTERNAL LOCATION IF NOT EXISTS bronze
URL CONCAT('abfss://bronze@', getArgument('storage_account_name'), '.dfs.core.windows.net')
WITH (STORAGE CREDENTIAL IDENTIFIER(getArgument('credential_name')))
COMMENT 'Bronze layer - raw ingested data';

-- SILVER - Cleansed/transformed layer
CREATE EXTERNAL LOCATION IF NOT EXISTS silver
URL CONCAT('abfss://silver@', getArgument('storage_account_name'), '.dfs.core.windows.net')
WITH (STORAGE CREDENTIAL IDENTIFIER(getArgument('credential_name')))
COMMENT 'Silver layer - cleansed and conformed data';

-- GOLD - Business-ready layer
CREATE EXTERNAL LOCATION IF NOT EXISTS gold
URL CONCAT('abfss://gold@', getArgument('storage_account_name'), '.dfs.core.windows.net')
WITH (STORAGE CREDENTIAL IDENTIFIER(getArgument('credential_name')))
COMMENT 'Gold layer - business-ready data products';

-- COMMAND ----------

-- ============================================================================
-- DEV ONLY - OVERLY PERMISSIVE GRANTS
-- ============================================================================
-- The following grants give ALL PRIVILEGES to all account users.
-- This is suitable for development/testing but NOT for production.
-- 
-- For production, replace with role-based grants shown in the documentation above.
-- See: https://docs.databricks.com/en/data-governance/unity-catalog/manage-privileges/privileges.html
-- ============================================================================

GRANT ALL PRIVILEGES ON EXTERNAL LOCATION bronze TO `account users`;
GRANT ALL PRIVILEGES ON EXTERNAL LOCATION silver TO `account users`;
GRANT ALL PRIVILEGES ON EXTERNAL LOCATION gold TO `account users`;

-- COMMAND ----------

-- Verify external locations
SHOW EXTERNAL LOCATIONS;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ## 4. Catalog and Schemas
-- MAGIC Creates the catalog and medallion architecture schemas

-- COMMAND ----------

-- Show what we're creating
SELECT 
  'Creating Catalog and Schemas' as action,
  getArgument('catalog_name') as catalog_name,
  getArgument('environment') as environment;

-- COMMAND ----------

-- Create catalog
CREATE CATALOG IF NOT EXISTS IDENTIFIER(getArgument('catalog_name'))
COMMENT CONCAT('M365 Migration Data Platform - ', getArgument('environment'), ' environment');

-- COMMAND ----------

-- Set as current catalog
USE CATALOG IDENTIFIER(getArgument('catalog_name'));

-- COMMAND ----------

-- BRONZE Schema
CREATE SCHEMA IF NOT EXISTS bronze
MANAGED LOCATION CONCAT('abfss://bronze@', getArgument('storage_account_name'), '.dfs.core.windows.net/tables')
COMMENT 'Bronze layer - raw data as ingested from source systems';

-- SILVER Schema
CREATE SCHEMA IF NOT EXISTS silver
MANAGED LOCATION CONCAT('abfss://silver@', getArgument('storage_account_name'), '.dfs.core.windows.net/tables')
COMMENT 'Silver layer - cleansed, validated, and conformed data';

-- GOLD Schema
CREATE SCHEMA IF NOT EXISTS gold
MANAGED LOCATION CONCAT('abfss://gold@', getArgument('storage_account_name'), '.dfs.core.windows.net/tables')
COMMENT 'Gold layer - aggregated and business-ready data products';

-- STAGING Schema (for intermediate processing)
CREATE SCHEMA IF NOT EXISTS staging
COMMENT 'Staging area for data processing workflows';

-- AUDIT Schema (pipeline logging)
CREATE SCHEMA IF NOT EXISTS audit
COMMENT 'Pipeline audit logs and data quality metrics';

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### Catalog and Schema Permissions
-- MAGIC 
-- MAGIC > **SECURITY WARNING**: The default grants below use permissive settings suitable ONLY for development.
-- MAGIC > 
-- MAGIC > **For production environments**, replace with role-based access control:
-- MAGIC > 
-- MAGIC > ```sql
-- MAGIC > -- Production example: Principle of least privilege
-- MAGIC > 
-- MAGIC > -- Data Engineers Group - Full access to build pipelines
-- MAGIC > GRANT USE CATALOG ON CATALOG m365_migration TO `data-engineers`;
-- MAGIC > GRANT USE SCHEMA, CREATE TABLE, MODIFY ON SCHEMA bronze TO `data-engineers`;
-- MAGIC > GRANT USE SCHEMA, CREATE TABLE, MODIFY ON SCHEMA silver TO `data-engineers`;
-- MAGIC > GRANT USE SCHEMA, CREATE TABLE, MODIFY ON SCHEMA gold TO `data-engineers`;
-- MAGIC > GRANT USE SCHEMA, CREATE TABLE, MODIFY ON SCHEMA staging TO `data-engineers`;
-- MAGIC > GRANT USE SCHEMA, CREATE TABLE, MODIFY ON SCHEMA audit TO `data-engineers`;
-- MAGIC > 
-- MAGIC > -- Data Scientists Group - Read silver/gold, no bronze access
-- MAGIC > GRANT USE CATALOG ON CATALOG m365_migration TO `data-scientists`;
-- MAGIC > GRANT USE SCHEMA, SELECT ON SCHEMA silver TO `data-scientists`;
-- MAGIC > GRANT USE SCHEMA, SELECT ON SCHEMA gold TO `data-scientists`;
-- MAGIC > 
-- MAGIC > -- BI/Analysts Group - Read-only gold layer
-- MAGIC > GRANT USE CATALOG ON CATALOG m365_migration TO `analysts`;
-- MAGIC > GRANT USE SCHEMA, SELECT ON SCHEMA gold TO `analysts`;
-- MAGIC > 
-- MAGIC > -- Service Principal for DLT Pipelines
-- MAGIC > GRANT USE CATALOG ON CATALOG m365_migration TO `dlt-service-principal`;
-- MAGIC > GRANT USE SCHEMA, CREATE TABLE, MODIFY ON SCHEMA bronze TO `dlt-service-principal`;
-- MAGIC > GRANT USE SCHEMA, CREATE TABLE, MODIFY ON SCHEMA silver TO `dlt-service-principal`;
-- MAGIC > GRANT USE SCHEMA, CREATE TABLE, MODIFY ON SCHEMA gold TO `dlt-service-principal`;
-- MAGIC > GRANT USE SCHEMA, CREATE TABLE, MODIFY ON SCHEMA audit TO `dlt-service-principal`;
-- MAGIC > ```

-- COMMAND ----------

-- ============================================================================
-- DEV ONLY - OVERLY PERMISSIVE GRANTS
-- ============================================================================
-- The following grants give broad access to all account users.
-- This is suitable for development/testing but NOT for production.
-- 
-- Environment check: Only apply these grants in non-production environments
-- ============================================================================

-- Verify this is not a production environment before applying permissive grants
SELECT 
  CASE 
    WHEN lower(getArgument('environment')) IN ('prod', 'production', 'prd')
    THEN 'ERROR: Production environment detected! Do not use permissive grants. See documentation above for production-ready permissions.'
    ELSE CONCAT('Environment: ', getArgument('environment'), ' - Applying development grants')
  END as permission_check;

-- COMMAND ----------

-- Development grants (skip this cell in production - use role-based grants instead)
-- These grants should be reviewed and replaced with appropriate role-based access for production

GRANT USE CATALOG ON CATALOG IDENTIFIER(getArgument('catalog_name')) TO `account users`;
GRANT USE SCHEMA ON SCHEMA bronze TO `account users`;
GRANT USE SCHEMA ON SCHEMA silver TO `account users`;
GRANT USE SCHEMA ON SCHEMA gold TO `account users`;
GRANT USE SCHEMA ON SCHEMA staging TO `account users`;
GRANT USE SCHEMA ON SCHEMA audit TO `account users`;

GRANT CREATE TABLE ON SCHEMA bronze TO `account users`;
GRANT CREATE TABLE ON SCHEMA silver TO `account users`;
GRANT CREATE TABLE ON SCHEMA gold TO `account users`;
GRANT CREATE TABLE ON SCHEMA staging TO `account users`;
GRANT CREATE TABLE ON SCHEMA audit TO `account users`;

-- COMMAND ----------

-- Verify schemas
SHOW SCHEMAS IN IDENTIFIER(getArgument('catalog_name'));

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ## 5. Validation
-- MAGIC Tests that everything is configured correctly

-- COMMAND ----------

-- Test 1: Verify storage credential exists
SELECT 'Test 1: Storage Credential' as test;
DESCRIBE STORAGE CREDENTIAL IDENTIFIER(getArgument('credential_name'));

-- COMMAND ----------

-- Test 2: Verify external locations exist
SELECT 'Test 2: External Locations' as test;
SHOW EXTERNAL LOCATIONS;

-- COMMAND ----------

-- Test 3: Verify catalog and schemas exist
SELECT 'Test 3: Catalog and Schemas' as test;
SHOW SCHEMAS IN IDENTIFIER(getArgument('catalog_name'));

-- COMMAND ----------

-- Test 4: Write/Read test
SELECT 'Test 4: Storage Write/Read' as test;

USE CATALOG IDENTIFIER(getArgument('catalog_name'));
USE SCHEMA bronze;

CREATE OR REPLACE TABLE _validation_test (
  id INT,
  message STRING,
  tested_at TIMESTAMP
);

INSERT INTO _validation_test VALUES (1, 'Setup validation successful', current_timestamp());

SELECT * FROM _validation_test;

DROP TABLE _validation_test;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ## Setup Complete!
-- MAGIC 
-- MAGIC **Summary of what was created:**
-- MAGIC 
-- MAGIC | Object | Name |
-- MAGIC |--------|------|
-- MAGIC | Storage Credential | `cred-adls-optumcare` |
-- MAGIC | External Location | `bronze` |
-- MAGIC | External Location | `silver` |
-- MAGIC | External Location | `gold` |
-- MAGIC | Catalog | `m365_migration` |
-- MAGIC | Schema | `bronze` |
-- MAGIC | Schema | `silver` |
-- MAGIC | Schema | `gold` |
-- MAGIC | Schema | `staging` |
-- MAGIC | Schema | `audit` |
-- MAGIC 
-- MAGIC **Next Steps:**
-- MAGIC 1. Create ingestion notebooks for source data
-- MAGIC 2. Build transformation pipelines (Bronze → Silver → Gold)
-- MAGIC 3. Set up ADF orchestration

-- COMMAND ----------

-- Final summary
SELECT 
  'Unity Catalog Setup Complete!' as status,
  getArgument('environment') as environment,
  getArgument('catalog_name') as catalog,
  getArgument('storage_account_name') as storage_account,
  current_timestamp() as completed_at;
