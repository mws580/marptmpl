-- Databricks notebook source
-- MAGIC %md
-- MAGIC # M365 Migration Toolkit - Data Model v3
-- MAGIC 
-- MAGIC **Updates from v2:**
-- MAGIC - Bronze tables removed - Auto Loader creates them dynamically from JSON
-- MAGIC - Catalog standardized as `m365_migration`
-- MAGIC - Schema evolution handled by Auto Loader + mergeSchema
-- MAGIC 
-- MAGIC **Architecture:**
-- MAGIC - Bronze: Auto Loader ingests JSON → creates Delta tables automatically
-- MAGIC - Silver: Pre-defined schema for cleansed entities
-- MAGIC - Gold: Pre-defined schema for business layer
-- MAGIC - Audit: Pre-defined schema for logging
-- MAGIC 
-- MAGIC **Total Tables:** 25 (Silver: 8, Gold: 14, Audit: 3)

-- COMMAND ----------

USE CATALOG m365_migration;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ## Bronze Layer
-- MAGIC 
-- MAGIC **NOTE:** Bronze tables are NOT created here.
-- MAGIC 
-- MAGIC Auto Loader will create these tables dynamically when ingesting JSON files:
-- MAGIC - `entra_users_source`, `entra_users_target`
-- MAGIC - `entra_contacts_source`, `entra_contacts_target`
-- MAGIC - `entra_groups_source`, `entra_groups_target`
-- MAGIC - `entra_group_members_source`, `entra_group_members_target`
-- MAGIC - `exo_mailboxes_source`, `exo_mailboxes_target`
-- MAGIC - `onedrive_sites_source`
-- MAGIC - `sharepoint_sites_source`
-- MAGIC 
-- MAGIC Benefits:
-- MAGIC - Schema inferred from JSON automatically
-- MAGIC - New API fields added automatically (with mergeSchema=true)
-- MAGIC - No manual schema maintenance

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ## Silver Layer
-- MAGIC Cleansed, deduplicated entities with environment tagging.
-- MAGIC **Contact → User mapping here** (consistent/system-level logic).
-- MAGIC Mapping candidates here (potential matches before confirmation).

-- COMMAND ----------

USE SCHEMA silver;

-- ============================================================================
-- USERS (All user accounts with environment tagging)
-- ============================================================================

CREATE TABLE IF NOT EXISTS users (
    user_id STRING COMMENT 'Surrogate key: {environment}_{entra_object_id}',
    
    -- Original IDs
    entra_object_id STRING,
    environment STRING COMMENT 'source, target',
    tenant_name STRING COMMENT 'MADEV1, MADEV2',
    
    -- Identity
    user_principal_name STRING,
    display_name STRING,
    mail STRING,
    proxy_addresses ARRAY<STRING> COMMENT 'All email addresses',
    user_type STRING COMMENT 'Member, Guest',
    account_enabled BOOLEAN,
    
    -- Employment
    employee_id STRING,
    job_title STRING,
    department STRING,
    company_name STRING,
    cdo_name STRING,
    
    -- Licensing (for people derivation rules)
    assigned_licenses ARRAY<STRING>,
    has_e3_license BOOLEAN,
    has_e5_license BOOLEAN,
    
    -- Timestamps
    source_created_at TIMESTAMP COMMENT 'When created in Entra',
    last_updated_at TIMESTAMP COMMENT 'When updated in Silver'
)
USING DELTA
COMMENT 'Cleansed user accounts from source and target with environment tagging';

-- ============================================================================
-- CONTACTS (All org contacts with environment tagging)
-- ============================================================================

CREATE TABLE IF NOT EXISTS contacts (
    contact_id STRING COMMENT 'Surrogate key: {environment}_{entra_object_id}',
    entra_object_id STRING,
    environment STRING,
    tenant_name STRING,
    
    display_name STRING,
    mail STRING COMMENT 'Target/external email address',
    proxy_addresses ARRAY<STRING>,
    company_name STRING,
    department STRING,
    
    last_updated_at TIMESTAMP
)
USING DELTA
COMMENT 'Cleansed org contacts from source and target';

-- ============================================================================
-- GROUPS (All groups with environment tagging)
-- ============================================================================

CREATE TABLE IF NOT EXISTS groups (
    group_id STRING COMMENT 'Surrogate key: {environment}_{entra_object_id}',
    entra_object_id STRING,
    environment STRING,
    tenant_name STRING,
    
    display_name STRING,
    description STRING,
    mail STRING,
    proxy_addresses ARRAY<STRING>,
    mail_enabled BOOLEAN,
    security_enabled BOOLEAN,
    group_type STRING COMMENT 'Microsoft365, Security, Distribution, MailEnabled',
    
    member_count INT,
    
    source_created_at TIMESTAMP,
    last_updated_at TIMESTAMP
)
USING DELTA
COMMENT 'Cleansed groups from source and target with environment tagging';

-- ============================================================================
-- GROUP MEMBERSHIPS (Cleansed)
-- ============================================================================

CREATE TABLE IF NOT EXISTS group_memberships (
    group_id STRING COMMENT 'FK to silver.groups',
    member_id STRING COMMENT 'FK to silver.users or silver.groups',
    member_type STRING COMMENT 'user, group',
    environment STRING,
    
    last_updated_at TIMESTAMP
)
USING DELTA
COMMENT 'Cleansed group memberships';

-- ============================================================================
-- MAILBOXES (Consolidated view)
-- ============================================================================

CREATE TABLE IF NOT EXISTS mailboxes (
    mailbox_id STRING COMMENT 'Surrogate key',
    user_id STRING COMMENT 'FK to silver.users (NULL for shared/room)',
    environment STRING,
    
    exchange_guid STRING,
    primary_smtp_address STRING,
    email_addresses ARRAY<STRING>,
    recipient_type STRING COMMENT 'UserMailbox, SharedMailbox, RoomMailbox, EquipmentMailbox',
    
    -- Size
    total_size_mb DECIMAL(18,2),
    item_count BIGINT,
    archive_size_mb DECIMAL(18,2),
    
    -- Flags
    has_archive BOOLEAN,
    litigation_hold BOOLEAN,
    
    last_updated_at TIMESTAMP
)
USING DELTA
COMMENT 'Cleansed mailbox data from source and target';

-- ============================================================================
-- CONTACT → USER/GROUP MAPPING (System-level, consistent logic)
-- ============================================================================

CREATE TABLE IF NOT EXISTS contact_entity_mapping (
    mapping_id STRING COMMENT 'Surrogate key',
    
    -- Contact side
    contact_id STRING COMMENT 'FK to silver.contacts',
    contact_environment STRING,
    contact_mail STRING COMMENT 'The targetAddress on the contact',
    
    -- Matched entity (user or group)
    matched_entity_type STRING COMMENT 'user, group',
    matched_entity_id STRING COMMENT 'FK to silver.users or silver.groups',
    matched_entity_environment STRING,
    matched_on_address STRING COMMENT 'Which proxy address matched',
    
    -- Metadata
    mapped_at TIMESTAMP,
    mapping_rule STRING COMMENT 'Always email_match for system-level'
)
USING DELTA
COMMENT 'System-level mapping of contacts to users/groups based on email address match';

-- ============================================================================
-- USER MAPPING CANDIDATES (Potential matches - not yet confirmed)
-- ============================================================================

CREATE TABLE IF NOT EXISTS user_mapping_candidates (
    candidate_id STRING,
    
    -- Source user
    source_user_id STRING COMMENT 'FK to silver.users',
    source_environment STRING,
    
    -- Target user
    target_user_id STRING COMMENT 'FK to silver.users',
    target_environment STRING,
    
    -- Match quality
    match_score DECIMAL(5,2) COMMENT '0-100 confidence score',
    match_type STRING COMMENT 'exact_email, exact_employeeid, exact_upn, fuzzy_name',
    match_attributes STRING COMMENT 'JSON: which attributes matched',
    
    -- Status
    candidate_status STRING COMMENT 'pending, confirmed, rejected',
    
    created_at TIMESTAMP,
    updated_at TIMESTAMP
)
USING DELTA
COMMENT 'User mapping candidates between source and target (before confirmation)';

-- ============================================================================
-- GROUP MAPPING CANDIDATES
-- ============================================================================

CREATE TABLE IF NOT EXISTS group_mapping_candidates (
    candidate_id STRING,
    
    source_group_id STRING COMMENT 'FK to silver.groups',
    target_group_id STRING COMMENT 'FK to silver.groups',
    
    match_score DECIMAL(5,2),
    match_type STRING COMMENT 'exact_mail, exact_name, fuzzy_name',
    match_attributes STRING,
    
    candidate_status STRING,
    
    created_at TIMESTAMP,
    updated_at TIMESTAMP
)
USING DELTA
COMMENT 'Group mapping candidates between source and target';

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ## Gold Layer
-- MAGIC **People derivation here** (opinionated/customer-specific rules).
-- MAGIC Final confirmed maps using FKs to dimensions.
-- MAGIC Dimensions, assessments, and reporting aggregates.

-- COMMAND ----------

USE SCHEMA gold;

-- ============================================================================
-- DIMENSION TABLES
-- ============================================================================

-- People dimension (derived using customer-specific rules)
CREATE TABLE IF NOT EXISTS dim_people (
    person_id STRING COMMENT 'Generated unique person identifier',
    
    -- Best known identity
    display_name STRING,
    given_name STRING,
    surname STRING,
    primary_email STRING,
    employee_id STRING,
    
    -- Primary account reference
    primary_user_id STRING COMMENT 'FK to dim_users - the "main" account',
    primary_environment STRING COMMENT 'source or target',
    
    -- CDO association
    cdo_name STRING,
    
    -- Derivation metadata
    derivation_rule STRING COMMENT 'Rule used: e.g., has_e5_license, has_employee_id',
    derived_at TIMESTAMP,
    
    -- Aggregated flags
    has_source_account BOOLEAN,
    has_target_account BOOLEAN,
    source_account_count INT,
    target_account_count INT,
    
    last_updated_at TIMESTAMP
)
USING DELTA
COMMENT 'People dimension - canonical identities derived using customer-specific rules';

-- Users dimension
CREATE TABLE IF NOT EXISTS dim_users (
    user_id STRING COMMENT 'FK to silver.users',
    person_id STRING COMMENT 'FK to dim_people (NULL if not yet linked)',
    
    environment STRING,
    tenant_name STRING,
    entra_object_id STRING,
    
    user_principal_name STRING,
    display_name STRING,
    mail STRING,
    user_type STRING,
    account_enabled BOOLEAN,
    
    employee_id STRING,
    job_title STRING,
    department STRING,
    cdo_name STRING,
    
    -- Licensing
    has_e3_license BOOLEAN,
    has_e5_license BOOLEAN,
    
    -- Related data sizes
    mailbox_size_mb DECIMAL(18,2),
    mailbox_item_count BIGINT,
    archive_size_mb DECIMAL(18,2),
    onedrive_size_mb DECIMAL(18,2),
    
    -- Flags
    has_mailbox BOOLEAN,
    has_archive BOOLEAN,
    has_onedrive BOOLEAN,
    
    last_updated_at TIMESTAMP
)
USING DELTA
COMMENT 'Users dimension for reporting - enriched with data sizes';

-- Contacts dimension
CREATE TABLE IF NOT EXISTS dim_contacts (
    contact_id STRING COMMENT 'FK to silver.contacts',
    
    environment STRING,
    entra_object_id STRING,
    
    display_name STRING,
    mail STRING,
    company_name STRING,
    
    -- Mapping status
    is_mapped_to_user BOOLEAN,
    mapped_user_id STRING COMMENT 'FK to dim_users if mapped',
    mapped_group_id STRING COMMENT 'FK to dim_groups if mapped to group',
    
    last_updated_at TIMESTAMP
)
USING DELTA
COMMENT 'Contacts dimension for reporting';

-- Groups dimension
CREATE TABLE IF NOT EXISTS dim_groups (
    group_id STRING COMMENT 'FK to silver.groups',
    
    environment STRING,
    tenant_name STRING,
    entra_object_id STRING,
    
    display_name STRING,
    mail STRING,
    group_type STRING,
    member_count INT,
    
    -- Mapping status
    is_mapped BOOLEAN,
    mapped_to_group_id STRING COMMENT 'FK to target group if mapped',
    
    last_updated_at TIMESTAMP
)
USING DELTA
COMMENT 'Groups dimension for reporting';

-- CDO dimension
CREATE TABLE IF NOT EXISTS dim_cdo (
    cdo_id STRING,
    cdo_name STRING,
    region STRING,
    
    -- Counts
    user_count INT,
    mailbox_count INT,
    group_count INT,
    
    -- Volumes
    total_mailbox_size_tb DECIMAL(10,4),
    total_onedrive_size_tb DECIMAL(10,4),
    
    last_updated_at TIMESTAMP
)
USING DELTA
COMMENT 'Care Delivery Organization dimension';

-- ============================================================================
-- FINAL CONFIRMED MAPS (FK-based, not denormalized)
-- ============================================================================

-- Person Map (primary output)
CREATE TABLE IF NOT EXISTS person_map (
    mapping_id STRING COMMENT 'Surrogate key',
    person_id STRING COMMENT 'FK to dim_people',
    
    -- Primary source and target accounts
    source_user_id STRING COMMENT 'FK to dim_users - primary source account',
    target_user_id STRING COMMENT 'FK to dim_users - primary target account',
    
    -- Tertiary accounts (guests in other tenants, secondary accounts)
    tertiary_user_ids ARRAY<STRING> COMMENT 'Array of FKs to dim_users',
    
    -- Contacts that map to this person
    mapped_contact_ids ARRAY<STRING> COMMENT 'Array of FKs to dim_contacts',
    
    -- Mapping metadata
    mapping_method STRING COMMENT 'auto, manual, rule-based',
    confidence_score DECIMAL(5,2),
    confirmed_by STRING COMMENT 'User who confirmed (NULL if auto)',
    confirmed_at TIMESTAMP,
    
    -- Migration status
    migration_status STRING COMMENT 'not_started, in_progress, completed, failed',
    migration_wave INT,
    scheduled_date DATE,
    completed_date DATE,
    
    -- Audit
    created_at TIMESTAMP,
    updated_at TIMESTAMP
)
USING DELTA
COMMENT 'Final confirmed person mapping - links source user to target user with all related accounts';

-- Non-Person Map (shared mailboxes, rooms, service accounts)
CREATE TABLE IF NOT EXISTS non_person_map (
    mapping_id STRING,
    entity_type STRING COMMENT 'shared_mailbox, room_mailbox, equipment_mailbox, service_account',
    
    -- Source
    source_mailbox_id STRING COMMENT 'FK to silver.mailboxes',
    source_identifier STRING COMMENT 'Primary SMTP for readability',
    
    -- Target
    target_mailbox_id STRING COMMENT 'FK to silver.mailboxes',
    target_identifier STRING,
    
    -- Contacts mapped to this entity
    mapped_contact_ids ARRAY<STRING>,
    
    -- Mapping metadata
    mapping_method STRING,
    
    -- Migration status
    migration_status STRING,
    
    created_at TIMESTAMP,
    updated_at TIMESTAMP
)
USING DELTA
COMMENT 'Mapping for non-person entities (shared mailboxes, rooms, etc.)';

-- Group Map
CREATE TABLE IF NOT EXISTS group_map (
    mapping_id STRING,
    
    source_group_id STRING COMMENT 'FK to dim_groups',
    target_group_id STRING COMMENT 'FK to dim_groups',
    
    -- Mapping metadata
    mapping_method STRING COMMENT 'auto, manual',
    confidence_score DECIMAL(5,2),
    
    -- Migration status
    migration_status STRING,
    
    created_at TIMESTAMP,
    updated_at TIMESTAMP
)
USING DELTA
COMMENT 'Final confirmed group mapping';

-- ============================================================================
-- MAPPING ISSUES (Rule-based assessments)
-- ============================================================================

CREATE TABLE IF NOT EXISTS mapping_issues (
    issue_id STRING,
    issue_type STRING COMMENT 'ambiguous_mapping, missing_target, orphaned_contact, duplicate_identity, missing_license',
    severity STRING COMMENT 'critical, high, medium, low',
    
    -- Affected entity
    entity_type STRING COMMENT 'person, user, group, contact, mailbox',
    entity_id STRING COMMENT 'FK to relevant dimension',
    entity_identifier STRING COMMENT 'UPN or display name for readability',
    environment STRING,
    
    -- Issue details
    issue_description STRING,
    issue_details STRING COMMENT 'JSON with specifics',
    
    -- Resolution
    resolution_status STRING COMMENT 'open, in_progress, resolved, wont_fix',
    assigned_to STRING,
    resolved_by STRING,
    resolved_at TIMESTAMP,
    resolution_notes STRING,
    
    detected_at TIMESTAMP,
    updated_at TIMESTAMP
)
USING DELTA
COMMENT 'Mapping issues detected by rule-based assessments';

-- ============================================================================
-- CHANGE TRACKING
-- ============================================================================

CREATE TABLE IF NOT EXISTS map_changes (
    change_id STRING,
    change_type STRING COMMENT 'mapping_added, mapping_removed, mapping_modified, status_changed',
    
    entity_type STRING COMMENT 'person, group, non_person',
    mapping_id STRING COMMENT 'FK to relevant map table',
    
    -- Before/After
    previous_value STRING COMMENT 'JSON of previous state',
    new_value STRING COMMENT 'JSON of new state',
    changed_field STRING COMMENT 'Which field changed',
    
    -- Metadata
    snapshot_date DATE,
    detected_at TIMESTAMP
)
USING DELTA
COMMENT 'Changes to mappings detected between snapshots';

CREATE TABLE IF NOT EXISTS deleted_objects (
    deletion_id STRING,
    entity_type STRING COMMENT 'user, group, contact, mailbox',
    entity_id STRING,
    environment STRING,
    
    -- Last known state
    last_known_identifier STRING COMMENT 'UPN or display name',
    last_known_attributes STRING COMMENT 'JSON snapshot',
    
    -- Impact
    had_mapping BOOLEAN,
    affected_mapping_id STRING,
    
    -- Deletion info
    last_seen_date DATE,
    deletion_detected_date DATE,
    
    detected_at TIMESTAMP
)
USING DELTA
COMMENT 'Objects deleted from source systems';

-- ============================================================================
-- MIGRATION STATUS & REPORTING
-- ============================================================================

CREATE TABLE IF NOT EXISTS migration_status_summary (
    snapshot_date DATE,
    cdo_name STRING,
    
    -- User/Person counts
    total_people INT,
    people_mapped INT,
    people_migrated INT,
    people_with_issues INT,
    
    total_users_source INT,
    total_users_target INT,
    
    -- Group counts
    total_groups INT,
    groups_mapped INT,
    groups_migrated INT,
    
    -- Non-person counts
    shared_mailboxes INT,
    shared_mailboxes_mapped INT,
    room_mailboxes INT,
    
    -- Data volumes (TB)
    mailbox_size_tb DECIMAL(10,4),
    mailbox_migrated_tb DECIMAL(10,4),
    onedrive_size_tb DECIMAL(10,4),
    onedrive_migrated_tb DECIMAL(10,4),
    
    -- Percentages
    people_mapping_pct DECIMAL(5,2),
    people_migration_pct DECIMAL(5,2),
    data_migration_pct DECIMAL(5,2),
    
    updated_at TIMESTAMP
)
USING DELTA
COMMENT 'Daily migration status summary by CDO';

CREATE TABLE IF NOT EXISTS data_volumes (
    snapshot_date DATE,
    environment STRING,
    cdo_name STRING,
    
    -- Mailbox
    mailbox_count INT,
    mailbox_total_size_tb DECIMAL(10,4),
    mailbox_avg_size_gb DECIMAL(10,2),
    archive_count INT,
    archive_total_size_tb DECIMAL(10,4),
    
    -- OneDrive
    onedrive_count INT,
    onedrive_total_size_tb DECIMAL(10,4),
    onedrive_avg_size_gb DECIMAL(10,2),
    
    -- SharePoint
    sharepoint_site_count INT,
    sharepoint_total_size_tb DECIMAL(10,4),
    
    updated_at TIMESTAMP
)
USING DELTA
COMMENT 'Data volume tracking by CDO and environment';

-- ============================================================================
-- PEOPLE DERIVATION RULES (Customer-configurable)
-- ============================================================================

CREATE TABLE IF NOT EXISTS people_derivation_rules (
    rule_id STRING,
    rule_name STRING,
    rule_priority INT COMMENT 'Lower number = higher priority',
    
    -- Rule definition
    rule_condition STRING COMMENT 'SQL-like condition: e.g., has_e5_license = true',
    rule_description STRING,
    
    -- Applicability
    applies_to_environment STRING COMMENT 'source, target, both',
    is_active BOOLEAN,
    
    created_at TIMESTAMP,
    updated_at TIMESTAMP
)
USING DELTA
COMMENT 'Configurable rules for deriving primary person accounts';

-- Insert default rules
MERGE INTO people_derivation_rules AS target
USING (
    SELECT 
        'rule_001' as rule_id,
        'E5 License Holder' as rule_name,
        1 as rule_priority,
        'has_e5_license = true AND user_type = "Member"' as rule_condition,
        'Users with E5 license are considered primary accounts' as rule_description,
        'both' as applies_to_environment,
        true as is_active,
        current_timestamp() as created_at,
        current_timestamp() as updated_at
    UNION ALL
    SELECT 
        'rule_002', 'E3 License Holder', 2,
        'has_e3_license = true AND user_type = "Member"',
        'Users with E3 license are considered primary accounts',
        'both', true, current_timestamp(), current_timestamp()
    UNION ALL
    SELECT 
        'rule_003', 'Has Employee ID', 3,
        'employee_id IS NOT NULL AND user_type = "Member"',
        'Users with employee ID populated are considered primary accounts',
        'both', true, current_timestamp(), current_timestamp()
    UNION ALL
    SELECT 
        'rule_004', 'Active Member', 4,
        'user_type = "Member" AND account_enabled = true',
        'Fallback: Any active member account',
        'both', true, current_timestamp(), current_timestamp()
) AS source
ON target.rule_id = source.rule_id
WHEN NOT MATCHED THEN INSERT *;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ## Audit Schema Tables

-- COMMAND ----------

USE SCHEMA audit;

-- ============================================================================
-- PIPELINE RUNS
-- ============================================================================

CREATE TABLE IF NOT EXISTS pipeline_runs (
    run_id STRING,
    pipeline_name STRING,
    pipeline_type STRING COMMENT 'ingestion, transformation, mapping, export',
    
    -- Scope
    environment STRING,
    entity_type STRING,
    
    -- Timing
    started_at TIMESTAMP,
    completed_at TIMESTAMP,
    duration_seconds INT,
    
    -- Status
    status STRING COMMENT 'running, succeeded, failed, cancelled',
    error_message STRING,
    
    -- Metrics
    rows_read BIGINT,
    rows_written BIGINT,
    rows_updated BIGINT,
    rows_deleted BIGINT,
    
    -- Context
    triggered_by STRING,
    parameters STRING COMMENT 'JSON of run parameters'
)
USING DELTA
COMMENT 'Pipeline execution audit log';

-- ============================================================================
-- DATA QUALITY
-- ============================================================================

CREATE TABLE IF NOT EXISTS data_quality_results (
    check_id STRING,
    run_id STRING COMMENT 'FK to pipeline_runs',
    
    schema_name STRING,
    table_name STRING,
    check_name STRING,
    check_type STRING COMMENT 'null_check, uniqueness, referential, range, custom',
    
    -- Results
    passed BOOLEAN,
    records_checked BIGINT,
    records_failed BIGINT,
    failure_percentage DECIMAL(5,2),
    
    -- Details
    check_query STRING,
    failure_sample STRING COMMENT 'JSON sample of failed records (max 10)',
    
    executed_at TIMESTAMP
)
USING DELTA
COMMENT 'Data quality check results';

-- ============================================================================
-- INGESTION LOG
-- ============================================================================

CREATE TABLE IF NOT EXISTS ingestion_log (
    batch_id STRING,
    source_system STRING COMMENT 'graph_api, exchange_online, sharepoint',
    entity_type STRING COMMENT 'users, groups, contacts, mailboxes',
    environment STRING,
    tenant_name STRING,
    
    -- Timing
    started_at TIMESTAMP,
    completed_at TIMESTAMP,
    
    -- Results
    status STRING,
    records_fetched BIGINT,
    records_written BIGINT,
    
    -- API details
    api_calls_made INT,
    throttle_delays_seconds INT,
    
    error_details STRING
)
USING DELTA
COMMENT 'Data ingestion audit log';

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ## Verification

-- COMMAND ----------

-- Show all tables created
SELECT 'silver' as schema_name, table_name 
FROM m365_migration.information_schema.tables 
WHERE table_schema = 'silver'
UNION ALL
SELECT 'gold', table_name 
FROM m365_migration.information_schema.tables 
WHERE table_schema = 'gold'
UNION ALL
SELECT 'audit', table_name 
FROM m365_migration.information_schema.tables 
WHERE table_schema = 'audit'
ORDER BY schema_name, table_name;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ## Summary v3
-- MAGIC 
-- MAGIC ### Tables by Schema
-- MAGIC 
-- MAGIC | Schema | Count | Creation Method |
-- MAGIC |--------|-------|-----------------|
-- MAGIC | bronze | 12 | Auto Loader (dynamic) |
-- MAGIC | silver | 8 | Pre-defined (this script) |
-- MAGIC | gold | 14 | Pre-defined (this script) |
-- MAGIC | audit | 3 | Pre-defined (this script) |
-- MAGIC 
-- MAGIC ### Bronze Tables (Created by Auto Loader)
-- MAGIC 
-- MAGIC | Table | Source |
-- MAGIC |-------|--------|
-- MAGIC | entra_users_source | Graph API /users |
-- MAGIC | entra_users_target | Graph API /users |
-- MAGIC | entra_contacts_source | Graph API /contacts |
-- MAGIC | entra_contacts_target | Graph API /contacts |
-- MAGIC | entra_groups_source | Graph API /groups |
-- MAGIC | entra_groups_target | Graph API /groups |
-- MAGIC | entra_group_members_source | Graph API /groups/{id}/members |
-- MAGIC | entra_group_members_target | Graph API /groups/{id}/members |
-- MAGIC | exo_mailboxes_source | EXO Get-Mailbox |
-- MAGIC | exo_mailboxes_target | EXO Get-Mailbox |
-- MAGIC | onedrive_sites_source | Graph API /drives |
-- MAGIC | sharepoint_sites_source | Graph API /sites |
-- MAGIC 
-- MAGIC ### Key Changes from v2
-- MAGIC 
-- MAGIC | Change | Rationale |
-- MAGIC |--------|-----------|
-- MAGIC | Bronze tables removed | Auto Loader creates dynamically with schema inference |
-- MAGIC | Catalog standardized | Uses `m365_migration` catalog |
-- MAGIC | No _raw_json column | Raw JSON preserved in landing zone files |
-- MAGIC 
-- MAGIC ### Data Flow
-- MAGIC 
-- MAGIC ```
-- MAGIC Landing Zone             Bronze                 Silver                 Gold
-- MAGIC (JSON files)          (Auto Loader)         (Pre-defined)         (Pre-defined)
-- MAGIC ─────────────────────────────────────────────────────────────────────────────────
-- MAGIC bronze/raw/            Auto Loader
-- MAGIC  └─entra_users/   ──→  bronze.entra_users_*  ──→  silver.users  ──→  gold.dim_users
-- MAGIC  └─entra_contacts/──→  bronze.entra_contacts_*──→  silver.contacts──→  gold.dim_contacts
-- MAGIC  └─entra_groups/  ──→  bronze.entra_groups_* ──→  silver.groups ──→  gold.dim_groups
-- MAGIC  └─...
-- MAGIC                                                   │
-- MAGIC                                                   ├──→ contact_entity_mapping
-- MAGIC                                                   ├──→ user_mapping_candidates
-- MAGIC                                                   └──→ group_mapping_candidates
-- MAGIC                                                                  │
-- MAGIC                                                                  ▼
-- MAGIC                                                   ┌─────────────────────────┐
-- MAGIC                                                   │ people_derivation_rules │
-- MAGIC                                                   └───────────┬─────────────┘
-- MAGIC                                                               ▼
-- MAGIC                                                          dim_people
-- MAGIC                                                               │
-- MAGIC                                                               ▼
-- MAGIC                                                   person_map (FK-based)
-- MAGIC                                                   group_map
-- MAGIC                                                   non_person_map
-- MAGIC ```
