variable "network_security_group_id" {
  description = "ID of the Network Security Group."
  type        = string
}
variable "subnet_id" {
  description = "ID of the Subnet."
  type        = string
}
