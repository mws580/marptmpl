resource "azurerm_private_endpoint" "this" {
  name                = var.name
  location            = var.location
  resource_group_name = var.resource_group_name
  subnet_id           = var.subnet_id
  tags                = var.tags

  dynamic "private_service_connection" {
    for_each = [var.private_service_connection]
    content {
      is_manual_connection              = lookup(private_service_connection.value, "is_manual_connection", false)
      name                              = private_service_connection.value.name
      private_connection_resource_alias = lookup(private_service_connection.value, "private_connection_resource_alias", null)
      private_connection_resource_id    = private_service_connection.value.private_connection_resource_id
      request_message                   = lookup(private_service_connection.value, "request_message", null)
      subresource_names                 = private_service_connection.value.subresource_names
    }
  }
}
