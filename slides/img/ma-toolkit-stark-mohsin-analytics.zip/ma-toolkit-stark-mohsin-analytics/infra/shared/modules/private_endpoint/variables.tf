variable "name" {
  description = "Name of the private endpoint."
  type        = string
}
variable "location" {
  description = "Azure region."
  type        = string
}
variable "resource_group_name" {
  description = "Resource group name."
  type        = string
}
variable "subnet_id" {
  description = "ID of the subnet."
  type        = string
}
variable "tags" {
  description = "Tags to apply."
  type        = map(string)
  default     = {}
}
variable "private_service_connection" {
  description = "Private service connection block."
  type        = any
}
