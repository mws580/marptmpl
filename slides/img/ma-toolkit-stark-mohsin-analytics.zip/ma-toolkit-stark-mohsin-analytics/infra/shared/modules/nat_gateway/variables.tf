variable "name" {
  description = "Name of the NAT Gateway."
  type        = string
}
variable "location" {
  description = "Azure region."
  type        = string
}
variable "resource_group_name" {
  description = "Resource group name."
  type        = string
}
variable "sku_name" {
  description = "SKU name."
  type        = string
  default     = "Standard"
}
variable "idle_timeout_in_minutes" {
  description = "Idle timeout in minutes."
  type        = number
  default     = 4
}
variable "tags" {
  description = "Tags to apply."
  type        = map(string)
  default     = {}
}
variable "zones" {
  description = "Zones for NAT Gateway."
  type        = list(string)
  default     = []
}
