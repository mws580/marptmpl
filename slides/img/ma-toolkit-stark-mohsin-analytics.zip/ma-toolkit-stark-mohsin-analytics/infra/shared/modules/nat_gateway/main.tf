resource "azurerm_nat_gateway" "this" {
  name                  = var.name
  location              = var.location
  resource_group_name   = var.resource_group_name
  sku_name              = var.sku_name
  idle_timeout_in_minutes = var.idle_timeout_in_minutes
  tags                  = var.tags
  zones                 = var.zones
}
