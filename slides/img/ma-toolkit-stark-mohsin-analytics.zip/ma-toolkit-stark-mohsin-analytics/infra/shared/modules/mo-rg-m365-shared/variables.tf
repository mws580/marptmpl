# Variables for mo-rg-m365-shared module
variable "location" {
  description = "Azure region for resources."
  type        = string
}

variable "resource_group_name" {
  description = "Name of the resource group."
  type        = string
}

variable "tags" {
  description = "Tags to apply to resources."
  type        = map(string)
  default     = {}
}

# Container Registry
variable "acr_name" {
  description = "Name of the Azure Container Registry."
  type        = string
}
variable "acr_sku" {
  description = "SKU for the Azure Container Registry."
  type        = string
  default     = "Basic"
}
variable "acr_admin_enabled" {
  description = "Enable admin for ACR."
  type        = bool
  default     = true
}
variable "acr_public_network_access_enabled" {
  description = "Enable public network access for ACR."
  type        = bool
  default     = true
}
variable "acr_network_rule_bypass_option" {
  description = "Network rule bypass option for ACR."
  type        = string
  default     = "AzureServices"
}
variable "acr_export_policy_enabled" {
  description = "Enable export policy for ACR."
  type        = bool
  default     = true
}
variable "acr_quarantine_policy_enabled" {
  description = "Enable quarantine policy for ACR."
  type        = bool
  default     = false
}
variable "acr_retention_policy_in_days" {
  description = "Retention policy in days for ACR."
  type        = number
  default     = 0
}
variable "acr_zone_redundancy_enabled" {
  description = "Enable zone redundancy for ACR."
  type        = bool
  default     = false
}

# Container Registry Scope Maps
variable "acr_scope_map_admin_actions" {
  description = "Actions for admin scope map."
  type        = list(string)
  default     = ["repositories/*/metadata/read", "repositories/*/metadata/write", "repositories/*/content/read", "repositories/*/content/write", "repositories/*/content/delete"]
}
variable "acr_scope_map_admin_description" {
  description = "Description for admin scope map."
  type        = string
  default     = "Can perform all read, write and delete operations on the registry"
}
variable "acr_scope_map_admin_name" {
  description = "Name for admin scope map."
  type        = string
  default     = "_repositories_admin"
}

variable "acr_scope_map_pull_actions" {
  description = "Actions for pull scope map."
  type        = list(string)
  default     = ["repositories/*/content/read"]
}
variable "acr_scope_map_pull_description" {
  description = "Description for pull scope map."
  type        = string
  default     = "Can pull any repository of the registry"
}
variable "acr_scope_map_pull_name" {
  description = "Name for pull scope map."
  type        = string
  default     = "_repositories_pull"
}

variable "acr_scope_map_pull_metadata_read_actions" {
  description = "Actions for pull_metadata_read scope map."
  type        = list(string)
  default     = ["repositories/*/content/read", "repositories/*/metadata/read"]
}
variable "acr_scope_map_pull_metadata_read_description" {
  description = "Description for pull_metadata_read scope map."
  type        = string
  default     = "Can perform all read operations on the registry"
}
variable "acr_scope_map_pull_metadata_read_name" {
  description = "Name for pull_metadata_read scope map."
  type        = string
  default     = "_repositories_pull_metadata_read"
}

variable "acr_scope_map_push_actions" {
  description = "Actions for push scope map."
  type        = list(string)
  default     = ["repositories/*/content/read", "repositories/*/content/write"]
}
variable "acr_scope_map_push_description" {
  description = "Description for push scope map."
  type        = string
  default     = "Can push to any repository of the registry"
}
variable "acr_scope_map_push_name" {
  description = "Name for push scope map."
  type        = string
  default     = "_repositories_push"
}

variable "acr_scope_map_push_metadata_write_actions" {
  description = "Actions for push_metadata_write scope map."
  type        = list(string)
  default     = ["repositories/*/metadata/read", "repositories/*/metadata/write", "repositories/*/content/read", "repositories/*/content/write"]
}
variable "acr_scope_map_push_metadata_write_description" {
  description = "Description for push_metadata_write scope map."
  type        = string
  default     = "Can perform all read and write operations on the registry"
}
variable "acr_scope_map_push_metadata_write_name" {
  description = "Name for push_metadata_write scope map."
  type        = string
  default     = "_repositories_push_metadata_write"
}

# Add more variables for all other resources as you migrate them.
