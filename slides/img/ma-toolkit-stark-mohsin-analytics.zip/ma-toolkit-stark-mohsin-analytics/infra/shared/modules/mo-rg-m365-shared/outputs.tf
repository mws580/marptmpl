# Outputs for mo-rg-m365-shared module
output "resource_group_id" {
  description = "The ID of the resource group."
  value       = azurerm_resource_group.rg.id
}

output "acr_id" {
  description = "The ID of the Azure Container Registry."
  value       = azurerm_container_registry.acr.id
}

output "acr_scope_map_admin_id" {
  description = "The ID of the admin scope map."
  value       = azurerm_container_registry_scope_map.admin.id
}

output "acr_scope_map_pull_id" {
  description = "The ID of the pull scope map."
  value       = azurerm_container_registry_scope_map.pull.id
}

output "acr_scope_map_pull_metadata_read_id" {
  description = "The ID of the pull_metadata_read scope map."
  value       = azurerm_container_registry_scope_map.pull_metadata_read.id
}

output "acr_scope_map_push_id" {
  description = "The ID of the push scope map."
  value       = azurerm_container_registry_scope_map.push.id
}

output "acr_scope_map_push_metadata_write_id" {
  description = "The ID of the push_metadata_write scope map."
  value       = azurerm_container_registry_scope_map.push_metadata_write.id
}

# Add more outputs for all other resources as you migrate them.
