output "id" {
  description = "The ID of the Private DNS A Record."
  value       = azurerm_private_dns_a_record.this.id
}
