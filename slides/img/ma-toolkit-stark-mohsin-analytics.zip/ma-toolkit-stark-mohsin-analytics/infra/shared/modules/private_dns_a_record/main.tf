resource "azurerm_private_dns_a_record" "this" {
  name                = var.name
  records             = var.records
  resource_group_name = var.resource_group_name
  zone_name           = var.zone_name
  ttl                 = var.ttl
  tags                = var.tags
}
