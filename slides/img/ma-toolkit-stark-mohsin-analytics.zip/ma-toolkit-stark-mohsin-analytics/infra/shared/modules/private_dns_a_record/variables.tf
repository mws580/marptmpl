variable "name" {
  description = "Name of the Private DNS A Record."
  type        = string
}
variable "records" {
  description = "List of IP addresses."
  type        = list(string)
}
variable "resource_group_name" {
  description = "Resource group name."
  type        = string
}
variable "zone_name" {
  description = "DNS zone name."
  type        = string
}
variable "ttl" {
  description = "TTL for the record."
  type        = number
  default     = 3600
}
variable "tags" {
  description = "Tags to apply."
  type        = map(string)
  default     = {}
}
