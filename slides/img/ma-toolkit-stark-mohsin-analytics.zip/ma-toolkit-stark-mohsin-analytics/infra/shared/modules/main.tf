terraform {
  required_providers {
    azurerm = {
      source  = "azurerm"
      version = "4.47.0"
    }
  }
}

provider "azurerm" {
  features {}
}

resource "azurerm_resource_group" "rg" {
  name     = var.resource_group_name
  location = var.location
  tags     = var.tags
}

resource "azurerm_container_registry" "acr" {
  name                          = var.acr_name
  resource_group_name           = azurerm_resource_group.rg.name
  location                      = var.location
  sku                           = var.acr_sku
  admin_enabled                 = var.acr_admin_enabled
  public_network_access_enabled = var.acr_public_network_access_enabled
  network_rule_bypass_option    = var.acr_network_rule_bypass_option
  export_policy_enabled         = var.acr_export_policy_enabled
  quarantine_policy_enabled     = var.acr_quarantine_policy_enabled
  retention_policy_in_days      = var.acr_retention_policy_in_days
  zone_redundancy_enabled       = var.acr_zone_redundancy_enabled
  tags                         = var.tags
}

# Container Registry Scope Maps
resource "azurerm_container_registry_scope_map" "admin" {
  actions                 = var.acr_scope_map_admin_actions
  container_registry_name = azurerm_container_registry.acr.name
  description             = var.acr_scope_map_admin_description
  name                    = var.acr_scope_map_admin_name
  resource_group_name     = azurerm_resource_group.rg.name
  depends_on              = [azurerm_container_registry.acr]
}

resource "azurerm_container_registry_scope_map" "pull" {
  actions                 = var.acr_scope_map_pull_actions
  container_registry_name = azurerm_container_registry.acr.name
  description             = var.acr_scope_map_pull_description
  name                    = var.acr_scope_map_pull_name
  resource_group_name     = azurerm_resource_group.rg.name
  depends_on              = [azurerm_container_registry.acr]
}

resource "azurerm_container_registry_scope_map" "pull_metadata_read" {
  actions                 = var.acr_scope_map_pull_metadata_read_actions
  container_registry_name = azurerm_container_registry.acr.name
  description             = var.acr_scope_map_pull_metadata_read_description
  name                    = var.acr_scope_map_pull_metadata_read_name
  resource_group_name     = azurerm_resource_group.rg.name
  depends_on              = [azurerm_container_registry.acr]
}

resource "azurerm_container_registry_scope_map" "push" {
  actions                 = var.acr_scope_map_push_actions
  container_registry_name = azurerm_container_registry.acr.name
  description             = var.acr_scope_map_push_description
  name                    = var.acr_scope_map_push_name
  resource_group_name     = azurerm_resource_group.rg.name
  depends_on              = [azurerm_container_registry.acr]
}

resource "azurerm_container_registry_scope_map" "push_metadata_write" {
  actions                 = var.acr_scope_map_push_metadata_write_actions
  container_registry_name = azurerm_container_registry.acr.name
  description             = var.acr_scope_map_push_metadata_write_description
  name                    = var.acr_scope_map_push_metadata_write_name
  resource_group_name     = azurerm_resource_group.rg.name
  depends_on              = [azurerm_container_registry.acr]
}

# ...existing code...
# Continue migrating all resources from mo-rg-m365-shared.txt, parameterizing values as variables.
