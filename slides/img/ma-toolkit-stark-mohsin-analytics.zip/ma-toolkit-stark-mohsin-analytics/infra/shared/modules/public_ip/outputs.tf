output "id" {
  description = "The ID of the Public IP."
  value       = azurerm_public_ip.this.id
}
