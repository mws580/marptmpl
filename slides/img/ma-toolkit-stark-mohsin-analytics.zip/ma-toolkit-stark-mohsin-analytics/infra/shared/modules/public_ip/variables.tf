variable "name" {
  description = "Name of the public IP."
  type        = string
}
variable "location" {
  description = "Azure region."
  type        = string
}
variable "resource_group_name" {
  description = "Resource group name."
  type        = string
}
variable "allocation_method" {
  description = "Allocation method."
  type        = string
  default     = "Static"
}
variable "sku" {
  description = "SKU for the public IP."
  type        = string
  default     = "Standard"
}
variable "sku_tier" {
  description = "SKU tier."
  type        = string
  default     = "Regional"
}
variable "ip_version" {
  description = "IP version."
  type        = string
  default     = "IPv4"
}
variable "idle_timeout_in_minutes" {
  description = "Idle timeout in minutes."
  type        = number
  default     = 4
}
variable "tags" {
  description = "Tags to apply."
  type        = map(string)
  default     = {}
}
variable "zones" {
  description = "Zones for the public IP."
  type        = list(string)
  default     = []
}
