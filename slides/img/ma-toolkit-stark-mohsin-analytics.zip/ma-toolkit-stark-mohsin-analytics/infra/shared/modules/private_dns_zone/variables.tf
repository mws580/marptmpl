variable "name" {
  description = "Name of the Private DNS Zone."
  type        = string
}
variable "resource_group_name" {
  description = "Resource group name."
  type        = string
}
variable "tags" {
  description = "Tags to apply."
  type        = map(string)
  default     = {}
}
variable "soa_record" {
  description = "SOA record block."
  type        = any
  default     = null
}
