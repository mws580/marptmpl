output "name" {
  description = "The name of the private DNS zone."
  value       = azurerm_private_dns_zone.this.name
}
output "id" {
  description = "The ID of the Private DNS Zone."
  value       = azurerm_private_dns_zone.this.id
}
