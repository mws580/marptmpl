variable "name" {
  description = "Name of the virtual network link."
  type        = string
}
variable "private_dns_zone_name" {
  description = "Name of the private DNS zone."
  type        = string
}
variable "resource_group_name" {
  description = "Resource group name."
  type        = string
}
variable "virtual_network_id" {
  description = "ID of the virtual network."
  type        = string
}
variable "registration_enabled" {
  description = "Registration enabled."
  type        = bool
  default     = false
}
variable "resolution_policy" {
  description = "Resolution policy."
  type        = string
  default     = "Default"
}
variable "tags" {
  description = "Tags to apply."
  type        = map(string)
  default     = {}
}
