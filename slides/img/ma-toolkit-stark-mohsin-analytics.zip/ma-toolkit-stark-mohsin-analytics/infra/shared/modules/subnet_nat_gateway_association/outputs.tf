output "id" {
  description = "The ID of the Subnet NAT Gateway Association."
  value       = azurerm_subnet_nat_gateway_association.this.id
}
