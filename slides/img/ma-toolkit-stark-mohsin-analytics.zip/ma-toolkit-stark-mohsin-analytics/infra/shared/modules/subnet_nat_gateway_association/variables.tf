variable "nat_gateway_id" {
  description = "ID of the NAT Gateway."
  type        = string
}
variable "subnet_id" {
  description = "ID of the Subnet."
  type        = string
}
