variable "name" {
  description = "Name of the Subnet."
  type        = string
}
variable "resource_group_name" {
  description = "Resource group name."
  type        = string
}
variable "virtual_network_name" {
  description = "Name of the virtual network."
  type        = string
}
variable "address_prefixes" {
  description = "Address prefixes for the subnet."
  type        = list(string)
}
variable "private_endpoint_network_policies" {
  description = "Private endpoint network policies."
  type        = string
  default     = "Disabled"
}
variable "private_link_service_network_policies_enabled" {
  description = "Enable private link service network policies."
  type        = bool
  default     = true
}
variable "tags" {
  description = "Tags to apply."
  type        = map(string)
  default     = {}
}
