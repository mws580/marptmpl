output "id" {
  description = "The ID of the Subnet."
  value       = azurerm_subnet.this.id
}
