variable "name" {
  description = "Name of the Network Security Group."
  type        = string
}
variable "location" {
  description = "Azure region."
  type        = string
}
variable "resource_group_name" {
  description = "Resource group name."
  type        = string
}
variable "tags" {
  description = "Tags to apply."
  type        = map(string)
  default     = {}
}
variable "security_rule" {
  description = "Security rules."
  type        = list(any)
  default     = []
}
