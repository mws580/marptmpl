output "key_vault_id" {
  description = "The ID of the Key Vault."
  value       = azurerm_key_vault.res-7.id
}

output "key_vault_name" {
  description = "The name of the Key Vault."
  value       = azurerm_key_vault.res-7.name
}

output "key_vault_uri" {
  description = "The URI of the Key Vault."
  value       = azurerm_key_vault.res-7.vault_uri
}

output "key_vault_vault_uri" {
  description = "The DNS Vault URI of the Key Vault."
  value       = azurerm_key_vault.res-7.vault_uri
}

output "key_vault_tenant_id" {
  description = "The tenant ID of the Key Vault."
  value       = azurerm_key_vault.res-7.tenant_id
}
