variable "access_policy" {
  description = "List of access policies for the Key Vault."
  type        = list(any)
  default     = []
}

variable "enable_rbac_authorization" {
  description = "Enable RBAC authorization for the Key Vault."
  type        = bool
  default     = true
}

variable "enabled_for_deployment" {
  description = "Whether Key Vault is enabled for deployment."
  type        = bool
  default     = false
}

variable "enabled_for_disk_encryption" {
  description = "Whether Key Vault is enabled for disk encryption."
  type        = bool
  default     = false
}

variable "enabled_for_template_deployment" {
  description = "Whether Key Vault is enabled for template deployment."
  type        = bool
  default     = false
}

variable "location" {
  description = "Azure region for the Key Vault."
  type        = string
  default     = "eastus2"
}

variable "name" {
  description = "Name of the Key Vault."
  type        = string
  default     = "kv-m365-dev-001"
}

variable "public_network_access_enabled" {
  description = "Whether public network access is enabled."
  type        = bool
  default     = false
}

variable "purge_protection_enabled" {
  description = "Whether purge protection is enabled."
  type        = bool
  default     = false
}

variable "rbac_authorization_enabled" {
  description = "Whether RBAC authorization is enabled."
  type        = bool
  default     = true
}

variable "resource_group_name" {
  description = "Resource group name for the Key Vault."
  type        = string
  default     = ""
}

variable "sku_name" {
  description = "SKU name for the Key Vault."
  type        = string
  default     = "standard"
}

variable "soft_delete_retention_days" {
  description = "Soft delete retention days."
  type        = number
  default     = 90
}

variable "tags" {
  description = "Tags for the Key Vault."
  type        = map(string)
  default     = {
    Environment = "dev"
  }
}

variable "tenant_id" {
  description = "Tenant ID for the Key Vault."
  type        = string
  default     = "beef7353-da47-4c47-b28a-e4d289a51a27"
}

variable "network_acls" {
  description = "Network ACLs for the Key Vault."
  type = object({
    bypass                     = string
    default_action             = string
    ip_rules                   = list(string)
    virtual_network_subnet_ids = list(string)
  })
  default = {
    bypass                     = "AzureServices"
    default_action             = "Deny"
    ip_rules                   = ["167.220.149.88/32", "63.198.1.209/32"]
    virtual_network_subnet_ids = []
  }
}
