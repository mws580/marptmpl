variable "actions" {
  description = "Actions for the scope map."
  type        = list(string)
}
variable "container_registry_name" {
  description = "Name of the container registry."
  type        = string
}
variable "description" {
  description = "Description for the scope map."
  type        = string
}
variable "name" {
  description = "Name for the scope map."
  type        = string
}
variable "resource_group_name" {
  description = "Resource group name."
  type        = string
}
