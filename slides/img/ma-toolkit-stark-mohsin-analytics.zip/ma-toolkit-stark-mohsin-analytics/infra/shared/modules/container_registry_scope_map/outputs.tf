output "id" {
  description = "The ID of the scope map."
  value       = azurerm_container_registry_scope_map.this.id
}
