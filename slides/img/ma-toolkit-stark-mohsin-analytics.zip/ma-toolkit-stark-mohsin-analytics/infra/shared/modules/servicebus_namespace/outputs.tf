output "id" {
  description = "The ID of the Service Bus Namespace."
  value       = azurerm_servicebus_namespace.this.id
}
