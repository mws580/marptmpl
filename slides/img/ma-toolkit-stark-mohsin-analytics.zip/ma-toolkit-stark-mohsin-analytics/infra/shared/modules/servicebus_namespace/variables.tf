variable "name" {
  description = "Name of the Service Bus Namespace."
  type        = string
}
variable "location" {
  description = "Azure region."
  type        = string
}
variable "resource_group_name" {
  description = "Resource group name."
  type        = string
}
variable "sku" {
  description = "SKU for the namespace."
  type        = string
  default     = "Standard"
}
variable "tags" {
  description = "Tags to apply."
  type        = map(string)
  default     = {}
}
variable "public_network_access_enabled" {
  description = "Enable public network access."
  type        = bool
  default     = true
}
variable "minimum_tls_version" {
  description = "Minimum TLS version."
  type        = string
  default     = "1.2"
}
