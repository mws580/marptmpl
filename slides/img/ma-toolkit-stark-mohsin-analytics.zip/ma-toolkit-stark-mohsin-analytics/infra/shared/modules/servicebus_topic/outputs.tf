output "id" {
  description = "The ID of the Service Bus Topic."
  value       = azurerm_servicebus_topic.this.id
}
