variable "name" {
  description = "Name of the Service Bus Topic."
  type        = string
}
variable "namespace_id" {
  description = "ID of the Service Bus Namespace."
  type        = string
}
variable "max_size_in_megabytes" {
  description = "Max size in MB."
  type        = number
  default     = 1024
}
variable "default_message_ttl" {
  description = "Default message TTL."
  type        = string
  default     = "P14D"
}
variable "status" {
  description = "Status of the topic."
  type        = string
  default     = "Active"
}
