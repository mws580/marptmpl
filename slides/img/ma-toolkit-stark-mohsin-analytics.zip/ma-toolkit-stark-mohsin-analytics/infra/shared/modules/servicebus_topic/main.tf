resource "azurerm_servicebus_topic" "this" {
  name                      = var.name
  namespace_id              = var.namespace_id
  max_size_in_megabytes     = var.max_size_in_megabytes
  default_message_ttl       = var.default_message_ttl
  status                    = var.status
}
