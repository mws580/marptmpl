output "id" {
  description = "The ID of the Service Bus Namespace Authorization Rule."
  value       = azurerm_servicebus_namespace_authorization_rule.this.id
}
