variable "name" {
  description = "Name of the authorization rule."
  type        = string
}
variable "namespace_id" {
  description = "ID of the Service Bus Namespace."
  type        = string
}
variable "listen" {
  description = "Enable listen."
  type        = bool
  default     = true
}
variable "manage" {
  description = "Enable manage."
  type        = bool
  default     = true
}
variable "send" {
  description = "Enable send."
  type        = bool
  default     = true
}
