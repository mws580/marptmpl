resource "azurerm_servicebus_namespace_authorization_rule" "this" {
  name         = var.name
  namespace_id = var.namespace_id
  listen       = var.listen
  manage       = var.manage
  send         = var.send
}
