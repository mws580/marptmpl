// This file sources the shared infrastructure module and passes variables from this environment

module "shared" {
  source = "../../shared/" // ensure correct case for Shared directory

  subscription_id     = var.subscription_id
  location            = var.location
  environment         = var.environment
  resource_group_name = var.resource_group_name

  subnet_private_endpoints_name                          = var.subnet_private_endpoints_name
  subnet_private_endpoints_address_prefixes              = var.subnet_private_endpoints_address_prefixes
  subnet_private_endpoints_network_policies              = var.subnet_private_endpoints_network_policies
  subnet_private_endpoints_link_service_policies_enabled = var.subnet_private_endpoints_link_service_policies_enabled

  public_ip_nat_name                    = var.public_ip_nat_name
  public_ip_nat_allocation_method       = var.public_ip_nat_allocation_method
  public_ip_nat_sku                     = var.public_ip_nat_sku
  public_ip_nat_sku_tier                = var.public_ip_nat_sku_tier
  public_ip_nat_ip_version              = var.public_ip_nat_ip_version
  public_ip_nat_idle_timeout_in_minutes = var.public_ip_nat_idle_timeout_in_minutes
  public_ip_nat_zones                   = var.public_ip_nat_zones

  private_endpoint_kv_name                    = var.private_endpoint_kv_name
  private_endpoint_kv_is_manual_connection    = var.private_endpoint_kv_is_manual_connection
  private_endpoint_kv_service_connection_name = var.private_endpoint_kv_service_connection_name
  private_endpoint_kv_resource_alias          = var.private_endpoint_kv_resource_alias
  private_endpoint_kv_resource_id             = var.private_endpoint_kv_resource_id
  private_endpoint_kv_request_message         = var.private_endpoint_kv_request_message
  private_endpoint_kv_subresource_names       = var.private_endpoint_kv_subresource_names

  container_registry_name                        = var.container_registry_name
  container_registry_sku                         = var.container_registry_sku
  container_registry_admin_enabled               = var.container_registry_admin_enabled
  container_registry_scope_map_admin_actions     = var.container_registry_scope_map_admin_actions
  container_registry_scope_map_admin_description = var.container_registry_scope_map_admin_description
  container_registry_scope_map_admin_name        = var.container_registry_scope_map_admin_name

  nat_gateway_name                    = var.nat_gateway_name
  nat_gateway_sku_name                = var.nat_gateway_sku_name
  nat_gateway_idle_timeout_in_minutes = var.nat_gateway_idle_timeout_in_minutes
  nat_gateway_zones                   = var.nat_gateway_zones

  nsg_analytics_name                 = var.nsg_analytics_name
  nsg_analytics_security_rule        = var.nsg_analytics_security_rule
  nsg_automation_name                = var.nsg_automation_name
  nsg_automation_security_rule       = var.nsg_automation_security_rule
  nsg_privateendpoints_name          = var.nsg_privateendpoints_name
  nsg_privateendpoints_security_rule = var.nsg_privateendpoints_security_rule

  private_dns_zone_databricks_name       = var.private_dns_zone_databricks_name
  private_dns_zone_databricks_soa_record = var.private_dns_zone_databricks_soa_record
  private_dns_zone_blob_name             = var.private_dns_zone_blob_name
  private_dns_zone_blob_soa_record       = var.private_dns_zone_blob_soa_record
  private_dns_zone_dfs_name              = var.private_dns_zone_dfs_name
  private_dns_zone_dfs_soa_record        = var.private_dns_zone_dfs_soa_record
  private_dns_zone_servicebus_name       = var.private_dns_zone_servicebus_name
  private_dns_zone_servicebus_soa_record = var.private_dns_zone_servicebus_soa_record
  private_dns_zone_vaultcore_name        = var.private_dns_zone_vaultcore_name
  private_dns_zone_vaultcore_soa_record  = var.private_dns_zone_vaultcore_soa_record

  virtual_network_name          = var.virtual_network_name
  virtual_network_address_space = var.virtual_network_address_space

  private_dns_zone_vnet_link_databricks_name                 = var.private_dns_zone_vnet_link_databricks_name
  private_dns_zone_vnet_link_databricks_registration_enabled = var.private_dns_zone_vnet_link_databricks_registration_enabled
  private_dns_zone_vnet_link_databricks_resolution_policy    = var.private_dns_zone_vnet_link_databricks_resolution_policy
  private_dns_zone_vnet_link_blob_name                       = var.private_dns_zone_vnet_link_blob_name
  private_dns_zone_vnet_link_blob_registration_enabled       = var.private_dns_zone_vnet_link_blob_registration_enabled
  private_dns_zone_vnet_link_blob_resolution_policy          = var.private_dns_zone_vnet_link_blob_resolution_policy
  private_dns_zone_vnet_link_dfs_name                        = var.private_dns_zone_vnet_link_dfs_name
  private_dns_zone_vnet_link_dfs_registration_enabled        = var.private_dns_zone_vnet_link_dfs_registration_enabled
  private_dns_zone_vnet_link_dfs_resolution_policy           = var.private_dns_zone_vnet_link_dfs_resolution_policy
  private_dns_zone_vnet_link_servicebus_name                 = var.private_dns_zone_vnet_link_servicebus_name
  private_dns_zone_vnet_link_servicebus_registration_enabled = var.private_dns_zone_vnet_link_servicebus_registration_enabled
  private_dns_zone_vnet_link_servicebus_resolution_policy    = var.private_dns_zone_vnet_link_servicebus_resolution_policy
  private_dns_zone_vnet_link_vaultcore_name                  = var.private_dns_zone_vnet_link_vaultcore_name
  private_dns_zone_vnet_link_vaultcore_registration_enabled  = var.private_dns_zone_vnet_link_vaultcore_registration_enabled
  private_dns_zone_vnet_link_vaultcore_resolution_policy     = var.private_dns_zone_vnet_link_vaultcore_resolution_policy
}
