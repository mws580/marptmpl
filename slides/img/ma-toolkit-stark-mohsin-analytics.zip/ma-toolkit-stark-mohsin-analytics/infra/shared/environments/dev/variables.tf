// Environment-specific variables for dev
variable "key_vault_name" {
  description = "Name of the Key Vault."
  type        = string
  default     = "kv-m365-dev-002"
}
variable "subscription_id" {
  description = "Azure Subscription ID"
  type        = string
  default     = "4293db49-78c9-4e47-bcd0-b44b4f7610a4"
}

variable "location" {
  description = "Azure region for resources"
  type        = string
  default     = "eastus2"
}

variable "environment" {
  description = "Deployment environment (e.g., dev, prod)"
  type        = string
  default     = "dev"
}


variable "resource_group_name" {
  description = "Name of the resource group"
  type        = string
  default     = "rg-m365-dev-shared-eastus2-001"
}

variable "subnet_private_endpoints_name" { default = "snet-private-endpoints" }
variable "subnet_private_endpoints_address_prefixes" { default = ["10.200.1.0/24"] }
variable "subnet_private_endpoints_network_policies" { default = "Disabled" }
variable "subnet_private_endpoints_link_service_policies_enabled" { default = true }

variable "public_ip_nat_name" { default = "pip-nat-m365-dev-eastus2" }
variable "public_ip_nat_allocation_method" { default = "Static" }
variable "public_ip_nat_sku" { default = "Standard" }
variable "public_ip_nat_sku_tier" { default = "Regional" }
variable "public_ip_nat_ip_version" { default = "IPv4" }
variable "public_ip_nat_idle_timeout_in_minutes" { default = 4 }
variable "public_ip_nat_zones" { default = [] }

variable "private_endpoint_kv_name" { default = "pe-kv-m365-dev-001" }
variable "private_endpoint_kv_is_manual_connection" { default = false }
variable "private_endpoint_kv_service_connection_name" { default = "pe-kv-m365-dev-001_870ec253-fc36-4fe0-832b-1c9f1616512c" }
variable "private_endpoint_kv_resource_alias" { default = null }
variable "private_endpoint_kv_resource_id" { default = "/subscriptions/4293db49-78c9-4e47-bcd0-b44b4f7610a4/resourceGroups/rg-m365-shared-dev-eastus2-001/providers/Microsoft.KeyVault/vaults/kv-m365-dev-002" }
variable "private_endpoint_kv_request_message" { default = null }
variable "private_endpoint_kv_subresource_names" { default = ["vault"] }

variable "container_registry_name" { default = "acrm365deveastus2unique" }
variable "container_registry_sku" { default = "Basic" }
variable "container_registry_admin_enabled" { default = true }
variable "container_registry_scope_map_admin_actions" { default = ["repositories/*/metadata/read", "repositories/*/metadata/write", "repositories/*/content/read", "repositories/*/content/write", "repositories/*/content/delete"] }
variable "container_registry_scope_map_admin_description" { default = "Can perform all read, write and delete operations on the registry" }
variable "container_registry_scope_map_admin_name" { default = "repositoriesadmin" }

variable "nat_gateway_name" { default = "nat-m365-dev-eastus2" }
variable "nat_gateway_sku_name" { default = "Standard" }
variable "nat_gateway_idle_timeout_in_minutes" { default = 4 }
variable "nat_gateway_zones" { default = [] }

variable "nsg_analytics_name" { default = "vnet-m365-dev-eastus2-snet-m365-analytics-aca-nsg-eastus2" }
variable "nsg_analytics_security_rule" { default = [] }
variable "nsg_automation_name" { default = "vnet-m365-dev-eastus2-snet-m365-automation-aca-nsg-eastus2" }
variable "nsg_automation_security_rule" { default = [] }
variable "nsg_privateendpoints_name" { default = "vnet-m365-dev-eastus2-snet-privateendpoints-nsg-eastus2" }
variable "nsg_privateendpoints_security_rule" { default = [] }

variable "private_dns_zone_databricks_name" { default = "privatelink.azuredatabricks.net" }
variable "private_dns_zone_databricks_soa_record" { default = null }
variable "private_dns_zone_blob_name" { default = "privatelink.blob.core.windows.net" }
variable "private_dns_zone_blob_soa_record" { default = null }
variable "private_dns_zone_dfs_name" { default = "privatelink.dfs.core.windows.net" }
variable "private_dns_zone_dfs_soa_record" { default = null }
variable "private_dns_zone_servicebus_name" { default = "privatelink.servicebus.windows.net" }
variable "private_dns_zone_servicebus_soa_record" { default = null }
variable "private_dns_zone_vaultcore_name" { default = "privatelink.vaultcore.azure.net" }
variable "private_dns_zone_vaultcore_soa_record" { default = null }

variable "virtual_network_name" { default = "vnet-m365-dev-eastus2" }
variable "virtual_network_address_space" { default = ["10.200.0.0/16"] }

variable "private_dns_zone_vnet_link_databricks_name" { default = "link-vnet-m365-dev" }
variable "private_dns_zone_vnet_link_databricks_registration_enabled" { default = false }
variable "private_dns_zone_vnet_link_databricks_resolution_policy" { default = "Default" }
variable "private_dns_zone_vnet_link_blob_name" { default = "link-vnet-m365-dev" }
variable "private_dns_zone_vnet_link_blob_registration_enabled" { default = false }
variable "private_dns_zone_vnet_link_blob_resolution_policy" { default = "Default" }
variable "private_dns_zone_vnet_link_dfs_name" { default = "link-vnet-m365-dev" }
variable "private_dns_zone_vnet_link_dfs_registration_enabled" { default = false }
variable "private_dns_zone_vnet_link_dfs_resolution_policy" { default = "Default" }
variable "private_dns_zone_vnet_link_servicebus_name" { default = "link-vnet-m365-dev" }
variable "private_dns_zone_vnet_link_servicebus_registration_enabled" { default = false }
variable "private_dns_zone_vnet_link_servicebus_resolution_policy" { default = "Default" }
variable "private_dns_zone_vnet_link_vaultcore_name" { default = "link-vnet-m365-dev" }
variable "private_dns_zone_vnet_link_vaultcore_registration_enabled" { default = false }
variable "private_dns_zone_vnet_link_vaultcore_resolution_policy" { default = "Default" }
