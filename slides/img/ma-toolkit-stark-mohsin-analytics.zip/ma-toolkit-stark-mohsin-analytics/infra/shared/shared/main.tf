# Key Vault
module "key_vault" {
  source                = "../modules/key-vault"
  name                  = var.key_vault_name
  location              = var.location
  resource_group_name   = var.resource_group_name
  sku_name              = var.key_vault_sku_name
  tenant_id             = var.key_vault_tenant_id
  access_policy                   = var.key_vault_access_policy
  enable_rbac_authorization       = var.key_vault_enable_rbac_authorization
  enabled_for_deployment          = var.key_vault_enabled_for_deployment
  enabled_for_disk_encryption     = var.key_vault_enabled_for_disk_encryption
  enabled_for_template_deployment = var.key_vault_enabled_for_template_deployment
  public_network_access_enabled   = var.key_vault_public_network_access_enabled
  purge_protection_enabled        = var.key_vault_purge_protection_enabled
  rbac_authorization_enabled      = var.key_vault_rbac_authorization_enabled
  soft_delete_retention_days      = var.key_vault_soft_delete_retention_days
  tags                            = var.key_vault_tags
  network_acls                    = var.key_vault_network_acls
}
# Subnet for Private Endpoints
module "subnet" {
  source                = "../modules/subnet"
  name                  = var.subnet_private_endpoints_name
  resource_group_name   = var.resource_group_name
  virtual_network_name  = module.virtual_network.name
  address_prefixes      = var.subnet_private_endpoints_address_prefixes
  private_endpoint_network_policies = var.subnet_private_endpoints_network_policies
  private_link_service_network_policies_enabled = var.subnet_private_endpoints_link_service_policies_enabled
  tags = {
    Environment = var.environment
  }
}
# Public IP
module "public_ip_nat" {
  source                = "../modules/public_ip"
  name                  = var.public_ip_nat_name
  location              = var.location
  resource_group_name   = var.resource_group_name
  allocation_method     = var.public_ip_nat_allocation_method
  sku                   = var.public_ip_nat_sku
  sku_tier              = var.public_ip_nat_sku_tier
  ip_version            = var.public_ip_nat_ip_version
  idle_timeout_in_minutes = var.public_ip_nat_idle_timeout_in_minutes
  tags                  = {}
  zones                 = var.public_ip_nat_zones
}
module "private_endpoint_kv" {
  source                = "../modules/private_endpoint"
  name                  = var.private_endpoint_kv_name
  location              = var.location
  resource_group_name   = var.resource_group_name
  subnet_id             = module.subnet.id
  tags = {
    Environment = var.environment
  }
  private_service_connection = {
    is_manual_connection              = var.private_endpoint_kv_is_manual_connection
    name                              = var.private_endpoint_kv_service_connection_name
    private_connection_resource_alias = var.private_endpoint_kv_resource_alias
    private_connection_resource_id    = module.key_vault.key_vault_id
    request_message                   = var.private_endpoint_kv_request_message
    subresource_names                 = var.private_endpoint_kv_subresource_names
  }
}

terraform {
  required_providers {
    azurerm = {
      source  = "azurerm"
      version = "4.58.0"
    }
  }
}

provider "azurerm" {
  subscription_id = var.subscription_id
  features {}
}


module "container_registry" {
  source                = "../modules/container_registry"
  name                  = var.container_registry_name
  resource_group_name   = var.resource_group_name
  location              = var.location
  sku                   = var.container_registry_sku
  admin_enabled         = var.container_registry_admin_enabled
  tags = {
    Environment = var.environment
  }
}

module "container_registry_scope_map_admin" {
  source                  = "../modules/container_registry_scope_map"
  actions                 = var.container_registry_scope_map_admin_actions
  container_registry_name = module.container_registry.name
  description             = var.container_registry_scope_map_admin_description
  name                    = var.container_registry_scope_map_admin_name
  resource_group_name     = var.resource_group_name
}

# ... Add additional module blocks for each resource as needed, wiring outputs to inputs where dependencies exist ...

module "nat_gateway" {
  source                = "../modules/nat_gateway"
  name                  = var.nat_gateway_name
  location              = var.location
  resource_group_name   = var.resource_group_name
  sku_name              = var.nat_gateway_sku_name
  idle_timeout_in_minutes = var.nat_gateway_idle_timeout_in_minutes
  tags = {
    Environment = var.environment
  }
  zones = var.nat_gateway_zones
}

module "network_security_group_analytics" {
  source                = "../modules/network_security_group"
  name                  = var.nsg_analytics_name
  location              = var.location
  resource_group_name   = var.resource_group_name
  tags = {
    Environment = var.environment
  }
  security_rule = var.nsg_analytics_security_rule
}

module "network_security_group_automation" {
  source                = "../modules/network_security_group"
  name                  = var.nsg_automation_name
  location              = var.location
  resource_group_name   = var.resource_group_name
  tags = {
    Environment = var.environment
  }
  security_rule = var.nsg_automation_security_rule
}

module "network_security_group_privateendpoints" {
  source                = "../modules/network_security_group"
  name                  = var.nsg_privateendpoints_name
  location              = var.location
  resource_group_name   = var.resource_group_name
  tags = {
    Environment = var.environment
  }
  security_rule = var.nsg_privateendpoints_security_rule
}

module "private_dns_zone_databricks" {
  source                = "../modules/private_dns_zone"
  name                  = var.private_dns_zone_databricks_name
  resource_group_name   = var.resource_group_name
  tags                  = {}
  soa_record            = var.private_dns_zone_databricks_soa_record
}

module "private_dns_zone_blob" {
  source                = "../modules/private_dns_zone"
  name                  = var.private_dns_zone_blob_name
  resource_group_name   = var.resource_group_name
  tags                  = {}
  soa_record            = var.private_dns_zone_blob_soa_record
}

module "private_dns_zone_dfs" {
  source                = "../modules/private_dns_zone"
  name                  = var.private_dns_zone_dfs_name
  resource_group_name   = var.resource_group_name
  tags                  = {}
  soa_record            = var.private_dns_zone_dfs_soa_record
}

module "private_dns_zone_servicebus" {
  source                = "../modules/private_dns_zone"
  name                  = var.private_dns_zone_servicebus_name
  resource_group_name   = var.resource_group_name
  tags                  = {}
  soa_record            = var.private_dns_zone_servicebus_soa_record
}

module "private_dns_zone_vaultcore" {
  source                = "../modules/private_dns_zone"
  name                  = var.private_dns_zone_vaultcore_name
  resource_group_name   = var.resource_group_name
  tags                  = {}
  soa_record            = var.private_dns_zone_vaultcore_soa_record
}

module "virtual_network" {
  source                = "../modules/virtual_network"
  name                  = var.virtual_network_name
  location              = var.location
  resource_group_name   = var.resource_group_name
  address_space         = var.virtual_network_address_space
  tags = {
    Environment = var.environment
  }
}

# Add modules for subnets, associations, service bus, and others as needed, wiring dependencies using module outputs

# Private DNS Zone Virtual Network Links
module "private_dns_zone_vnet_link_databricks" {
  source                = "../modules/private_dns_zone_virtual_network_link"
  name                  = var.private_dns_zone_vnet_link_databricks_name
  private_dns_zone_name = module.private_dns_zone_databricks.name
  resource_group_name   = var.resource_group_name
  virtual_network_id    = module.virtual_network.id
  registration_enabled  = var.private_dns_zone_vnet_link_databricks_registration_enabled
  resolution_policy     = var.private_dns_zone_vnet_link_databricks_resolution_policy
  tags                  = {}
}

module "private_dns_zone_vnet_link_blob" {
  source                = "../modules/private_dns_zone_virtual_network_link"
  name                  = var.private_dns_zone_vnet_link_blob_name
  private_dns_zone_name = module.private_dns_zone_blob.name
  resource_group_name   = var.resource_group_name
  virtual_network_id    = module.virtual_network.id
  registration_enabled  = var.private_dns_zone_vnet_link_blob_registration_enabled
  resolution_policy     = var.private_dns_zone_vnet_link_blob_resolution_policy
  tags                  = {}
}

module "private_dns_zone_vnet_link_dfs" {
  source                = "../modules/private_dns_zone_virtual_network_link"
  name                  = var.private_dns_zone_vnet_link_dfs_name
  private_dns_zone_name = module.private_dns_zone_dfs.name
  resource_group_name   = var.resource_group_name
  virtual_network_id    = module.virtual_network.id
  registration_enabled  = var.private_dns_zone_vnet_link_dfs_registration_enabled
  resolution_policy     = var.private_dns_zone_vnet_link_dfs_resolution_policy
  tags                  = {}
}

module "private_dns_zone_vnet_link_servicebus" {
  source                = "../modules/private_dns_zone_virtual_network_link"
  name                  = var.private_dns_zone_vnet_link_servicebus_name
  private_dns_zone_name = module.private_dns_zone_servicebus.name
  resource_group_name   = var.resource_group_name
  virtual_network_id    = module.virtual_network.id
  registration_enabled  = var.private_dns_zone_vnet_link_servicebus_registration_enabled
  resolution_policy     = var.private_dns_zone_vnet_link_servicebus_resolution_policy
  tags                  = {}
}

module "private_dns_zone_vnet_link_vaultcore" {
  source                = "../modules/private_dns_zone_virtual_network_link"
  name                  = var.private_dns_zone_vnet_link_vaultcore_name
  private_dns_zone_name = module.private_dns_zone_vaultcore.name
  resource_group_name   = var.resource_group_name
  virtual_network_id    = module.virtual_network.id
  registration_enabled  = var.private_dns_zone_vnet_link_vaultcore_registration_enabled
  resolution_policy     = var.private_dns_zone_vnet_link_vaultcore_resolution_policy
  tags                  = {}
}
