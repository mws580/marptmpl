output "virtual_network_name" {
	description = "The name of the virtual network."
	value       = module.virtual_network.name
}

output "virtual_network_id" {
	description = "The id of the virtual network."
	value       = module.virtual_network.id
}

output "private_dns_zone_databricks_name" {
	description = "The name of the databricks private DNS zone."
	value       = module.private_dns_zone_databricks.name
}
output "private_dns_zone_databricks_id" {
	description = "The id of the databricks private DNS zone."
	value       = module.private_dns_zone_databricks.id
}
output "private_dns_zone_blob_name" {
	description = "The name of the blob private DNS zone."
	value       = module.private_dns_zone_blob.name
}
output "private_dns_zone_blob_id" {
	description = "The id of the blob private DNS zone."
	value       = module.private_dns_zone_blob.id
}
output "private_dns_zone_dfs_name" {
	description = "The name of the dfs private DNS zone."
	value       = module.private_dns_zone_dfs.name
}
output "private_dns_zone_dfs_id" {
	description = "The id of the dfs private DNS zone."
	value       = module.private_dns_zone_dfs.id
}
output "private_dns_zone_servicebus_name" {
	description = "The name of the servicebus private DNS zone."
	value       = module.private_dns_zone_servicebus.name
}
output "private_dns_zone_servicebus_id" {
	description = "The id of the servicebus private DNS zone."
	value       = module.private_dns_zone_servicebus.id
}
output "private_dns_zone_vaultcore_name" {
	description = "The name of the vaultcore private DNS zone."
	value       = module.private_dns_zone_vaultcore.name
}
output "private_dns_zone_vaultcore_id" {
	description = "The id of the vaultcore private DNS zone."
	value       = module.private_dns_zone_vaultcore.id
}

