# Key Vault module variables
variable "key_vault_name" {
  description = "Name of the Key Vault."
  type        = string
  default     = "kv-m365-dev-002"
}

variable "key_vault_sku_name" {
  description = "SKU name for the Key Vault."
  type        = string
  default     = "standard"
}

variable "key_vault_tenant_id" {
  description = "Tenant ID for the Key Vault."
  type        = string
  default     = "beef7353-da47-4c47-b28a-e4d289a51a27"
}

variable "key_vault_access_policy" {
  description = "List of access policies for the Key Vault."
  type        = list(any)
  default     = []
}

variable "key_vault_enable_rbac_authorization" {
  description = "Enable RBAC authorization for the Key Vault."
  type        = bool
  default     = true
}

variable "key_vault_enabled_for_deployment" {
  description = "Whether Key Vault is enabled for deployment."
  type        = bool
  default     = false
}

variable "key_vault_enabled_for_disk_encryption" {
  description = "Whether Key Vault is enabled for disk encryption."
  type        = bool
  default     = false
}

variable "key_vault_enabled_for_template_deployment" {
  description = "Whether Key Vault is enabled for template deployment."
  type        = bool
  default     = false
}

variable "key_vault_public_network_access_enabled" {
  description = "Whether public network access is enabled."
  type        = bool
  default     = false
}

variable "key_vault_purge_protection_enabled" {
  description = "Whether purge protection is enabled."
  type        = bool
  default     = false
}

variable "key_vault_rbac_authorization_enabled" {
  description = "Whether RBAC authorization is enabled."
  type        = bool
  default     = true
}

variable "key_vault_soft_delete_retention_days" {
  description = "Soft delete retention days."
  type        = number
  default     = 90
}

variable "key_vault_tags" {
  description = "Tags for the Key Vault."
  type        = map(string)
  default     = {
    Environment = "dev"
  }
}

variable "key_vault_network_acls" {
  description = "Network ACLs for the Key Vault."
  type = object({
    bypass                     = string
    default_action             = string
    ip_rules                   = list(string)
    virtual_network_subnet_ids = list(string)
  })
  default = {
    bypass                     = "AzureServices"
    default_action             = "Deny"
    ip_rules                   = ["167.220.149.88/32", "63.198.1.209/32"]
    virtual_network_subnet_ids = []
  }
}
# Shared variables for main.tf

variable "subscription_id" {
  description = "Azure Subscription ID"
  type        = string
  default     = "0d8eaac2-1d58-4722-879f-9c402d1a31df"
}

variable "location" {
  description = "Azure region for resources"
  type        = string
  default     = "eastus2"
}

variable "environment" {
  description = "Deployment environment (e.g., dev, prod)"
  type        = string
  default     = "dev"
}

variable "resource_group_name" {
  description = "Name of the resource group"
  type        = string
  default     = "rg-m365-shared-dev-eastus2-001"
}

variable "subnet_private_endpoints_name" {
  description = "Subnet name for private endpoints"
  type        = string
  default     = "snet-private-endpoints"
}

variable "subnet_private_endpoints_address_prefixes" {
  description = "Address prefixes for the private endpoints subnet"
  type        = list(string)
  default     = ["10.200.1.0/24"]
}

variable "subnet_private_endpoints_network_policies" {
  description = "Network policies for private endpoint subnet"
  type        = string
  default     = "Disabled"
}

variable "subnet_private_endpoints_link_service_policies_enabled" {
  description = "Enable private link service network policies"
  type        = bool
  default     = true
}

variable "public_ip_nat_name" {
  description = "Name of the NAT public IP"
  type        = string
  default     = "pip-nat-m365-dev-eastus2"
}

variable "public_ip_nat_allocation_method" {
  description = "Allocation method for public IP"
  type        = string
  default     = "Static"
}

variable "public_ip_nat_sku" {
  description = "SKU for public IP"
  type        = string
  default     = "Standard"
}

variable "public_ip_nat_sku_tier" {
  description = "SKU tier for public IP"
  type        = string
  default     = "Regional"
}

variable "public_ip_nat_ip_version" {
  description = "IP version for public IP"
  type        = string
  default     = "IPv4"
}

variable "public_ip_nat_idle_timeout_in_minutes" {
  description = "Idle timeout for public IP"
  type        = number
  default     = 4
}

variable "public_ip_nat_zones" {
  description = "Zones for public IP"
  type        = list(string)
  default     = []
}

variable "private_endpoint_kv_name" {
  description = "Name of the Key Vault private endpoint"
  type        = string
  default     = "pe-kv-m365-dev-001"
}

variable "private_endpoint_kv_is_manual_connection" {
  description = "Is manual connection for private endpoint"
  type        = bool
  default     = false
}

variable "private_endpoint_kv_service_connection_name" {
  description = "Service connection name for private endpoint"
  type        = string
  default     = "pe-kv-m365-dev-001_870ec253-fc36-4fe0-832b-1c9f1616512c"
}

variable "private_endpoint_kv_resource_alias" {
  description = "Resource alias for private endpoint"
  type        = string
  default     = null
}

variable "private_endpoint_kv_resource_id" {
  description = "Resource ID for private endpoint"
  type        = string
  default     = "/subscriptions/4293db49-78c9-4e47-bcd0-b44b4f7610a4/resourceGroups/rg-m365-shared-dev-eastus2-001/providers/Microsoft.KeyVault/vaults/kv-m365-dev-001"
}

variable "private_endpoint_kv_request_message" {
  description = "Request message for private endpoint"
  type        = string
  default     = null
}

variable "private_endpoint_kv_subresource_names" {
  description = "Subresource names for private endpoint"
  type        = list(string)
  default     = ["vault"]
}

variable "container_registry_name" {
  description = "Name of the container registry"
  type        = string
  default     = "acrm365deveastus2"
}

variable "container_registry_sku" {
  description = "SKU for container registry"
  type        = string
  default     = "Basic"
}

variable "container_registry_admin_enabled" {
  description = "Enable admin for container registry"
  type        = bool
  default     = true
}

variable "container_registry_scope_map_admin_actions" {
  description = "Actions for container registry scope map admin"
  type        = list(string)
  default     = ["repositories/*/metadata/read", "repositories/*/metadata/write", "repositories/*/content/read", "repositories/*/content/write", "repositories/*/content/delete"]
}

variable "container_registry_scope_map_admin_description" {
  description = "Description for container registry scope map admin"
  type        = string
  default     = "Can perform all read, write and delete operations on the registry"
}

variable "container_registry_scope_map_admin_name" {
  description = "Name for container registry scope map admin"
  type        = string
  default     = "repositoriesadmin"
}

variable "nat_gateway_name" {
  description = "Name of the NAT gateway"
  type        = string
  default     = "nat-m365-dev-eastus2"
}

variable "nat_gateway_sku_name" {
  description = "SKU name for NAT gateway"
  type        = string
  default     = "Standard"
}

variable "nat_gateway_idle_timeout_in_minutes" {
  description = "Idle timeout for NAT gateway"
  type        = number
  default     = 4
}

variable "nat_gateway_zones" {
  description = "Zones for NAT gateway"
  type        = list(string)
  default     = []
}

variable "nsg_analytics_name" {
  description = "Name for analytics NSG"
  type        = string
  default     = "vnet-m365-dev-eastus2-snet-m365-analytics-aca-nsg-eastus2"
}

variable "nsg_analytics_security_rule" {
  description = "Security rules for analytics NSG"
  type        = list(any)
  default     = []
}

variable "nsg_automation_name" {
  description = "Name for automation NSG"
  type        = string
  default     = "vnet-m365-dev-eastus2-snet-m365-automation-aca-nsg-eastus2"
}

variable "nsg_automation_security_rule" {
  description = "Security rules for automation NSG"
  type        = list(any)
  default     = []
}

variable "nsg_privateendpoints_name" {
  description = "Name for private endpoints NSG"
  type        = string
  default     = "vnet-m365-dev-eastus2-snet-privateendpoints-nsg-eastus2"
}

variable "nsg_privateendpoints_security_rule" {
  description = "Security rules for private endpoints NSG"
  type        = list(any)
  default     = []
}

variable "private_dns_zone_databricks_name" {
  description = "Name for Databricks private DNS zone"
  type        = string
  default     = "privatelink.azuredatabricks.net"
}

variable "private_dns_zone_databricks_soa_record" {
  description = "SOA record for Databricks private DNS zone"
  type        = string
  default     = null
}

variable "private_dns_zone_blob_name" {
  description = "Name for Blob private DNS zone"
  type        = string
  default     = "privatelink.blob.core.windows.net"
}

variable "private_dns_zone_blob_soa_record" {
  description = "SOA record for Blob private DNS zone"
  type        = string
  default     = null
}

variable "private_dns_zone_dfs_name" {
  description = "Name for DFS private DNS zone"
  type        = string
  default     = "privatelink.dfs.core.windows.net"
}

variable "private_dns_zone_dfs_soa_record" {
  description = "SOA record for DFS private DNS zone"
  type        = string
  default     = null
}

variable "private_dns_zone_servicebus_name" {
  description = "Name for Service Bus private DNS zone"
  type        = string
  default     = "privatelink.servicebus.windows.net"
}

variable "private_dns_zone_servicebus_soa_record" {
  description = "SOA record for Service Bus private DNS zone"
  type        = string
  default     = null
}

variable "private_dns_zone_vaultcore_name" {
  description = "Name for Vault Core private DNS zone"
  type        = string
  default     = "privatelink.vaultcore.azure.net"
}

variable "private_dns_zone_vaultcore_soa_record" {
  description = "SOA record for Vault Core private DNS zone"
  type        = string
  default     = null
}

variable "virtual_network_name" {
  description = "Name for the virtual network"
  type        = string
  default     = "vnet-m365-dev-eastus2"
}

variable "virtual_network_address_space" {
  description = "Address space for the virtual network"
  type        = list(string)
  default     = ["10.200.0.0/16"]
}

variable "private_dns_zone_vnet_link_databricks_name" {
  description = "Name for Databricks DNS zone VNet link"
  type        = string
  default     = "link-vnet-m365-dev"
}

variable "private_dns_zone_vnet_link_databricks_registration_enabled" {
  description = "Registration enabled for Databricks DNS zone VNet link"
  type        = bool
  default     = false
}

variable "private_dns_zone_vnet_link_databricks_resolution_policy" {
  description = "Resolution policy for Databricks DNS zone VNet link"
  type        = string
  default     = "Default"
}

variable "private_dns_zone_vnet_link_blob_name" {
  description = "Name for Blob DNS zone VNet link"
  type        = string
  default     = "link-vnet-m365-dev"
}

variable "private_dns_zone_vnet_link_blob_registration_enabled" {
  description = "Registration enabled for Blob DNS zone VNet link"
  type        = bool
  default     = false
}

variable "private_dns_zone_vnet_link_blob_resolution_policy" {
  description = "Resolution policy for Blob DNS zone VNet link"
  type        = string
  default     = "Default"
}

variable "private_dns_zone_vnet_link_dfs_name" {
  description = "Name for DFS DNS zone VNet link"
  type        = string
  default     = "link-vnet-m365-dev"
}

variable "private_dns_zone_vnet_link_dfs_registration_enabled" {
  description = "Registration enabled for DFS DNS zone VNet link"
  type        = bool
  default     = false
}

variable "private_dns_zone_vnet_link_dfs_resolution_policy" {
  description = "Resolution policy for DFS DNS zone VNet link"
  type        = string
  default     = "Default"
}

variable "private_dns_zone_vnet_link_servicebus_name" {
  description = "Name for Service Bus DNS zone VNet link"
  type        = string
  default     = "link-vnet-m365-dev"
}

variable "private_dns_zone_vnet_link_servicebus_registration_enabled" {
  description = "Registration enabled for Service Bus DNS zone VNet link"
  type        = bool
  default     = false
}

variable "private_dns_zone_vnet_link_servicebus_resolution_policy" {
  description = "Resolution policy for Service Bus DNS zone VNet link"
  type        = string
  default     = "Default"
}

variable "private_dns_zone_vnet_link_vaultcore_name" {
  description = "Name for Vault Core DNS zone VNet link"
  type        = string
  default     = "link-vnet-m365-dev"
}

variable "private_dns_zone_vnet_link_vaultcore_registration_enabled" {
  description = "Registration enabled for Vault Core DNS zone VNet link"
  type        = bool
  default     = false
}

variable "private_dns_zone_vnet_link_vaultcore_resolution_policy" {
  description = "Resolution policy for Vault Core DNS zone VNet link"
  type        = string
  default     = "Default"
}
