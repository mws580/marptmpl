// Main Terraform configuration for Analytics
// Module calls generated from mo-rg-m365-analytics.txt



provider "azurerm" {
  subscription_id = var.subscription_id
  features {}
}

  module "container_app_environment" {
    source              = "../modules/container_app_environment"
    name                = var.container_app_environment_name
    location            = var.location
    resource_group_name = var.resource_group_name
  }

  module "data_factory" {
    source              = "../modules/data_factory"
    name                = var.data_factory_name
    location            = var.location
    resource_group_name = var.resource_group_name
  }

  module "data_factory_linked_custom_service" {
    source            = "../modules/data_factory_linked_custom_service"
    name              = var.df_linked_custom_service_name
    data_factory_id   = module.data_factory.id
    type              = var.df_linked_custom_service_type
    type_properties_json = var.df_linked_custom_service_type_properties_json
  }

  module "data_factory_pipeline_1" {
    source            = "../modules/data_factory_pipeline"
    name              = var.data_factory_pipeline_1_name
    data_factory_id   = module.data_factory.id
  }

  module "data_factory_pipeline_2" {
    source            = "../modules/data_factory_pipeline"
    name              = var.data_factory_pipeline_2_name
    data_factory_id   = module.data_factory.id
  }

module "container_app_job_1" {
  source                        = "../modules/container_app_job"
  name                          = var.container_app_job_1_name
  container_app_environment_id   = module.container_app_environment.id
  resource_group_name           = var.resource_group_name
  location                      = var.location
  replica_timeout_in_seconds    = var.container_app_job_1_replica_timeout_in_seconds
  template                     = var.container_app_job_1_template
  manual_trigger_config        = var.container_app_job_1_template.manual_trigger_config
}

module "container_app_job_2" {
  source                        = "../modules/container_app_job"
  name                          = var.container_app_job_2_name
  container_app_environment_id   = module.container_app_environment.id
  resource_group_name           = var.resource_group_name
  location                      = var.location
  replica_timeout_in_seconds    = var.container_app_job_2_replica_timeout_in_seconds
  template                     = var.container_app_job_2_template
  manual_trigger_config        = var.container_app_job_2_template.manual_trigger_config
}



// ...existing code...

module "databricks_access_connector" {
  source              = "../modules/databricks_access_connector"
  name                = var.db_access_connector_name
  resource_group_name = var.resource_group_name
  location            = var.location
}

module "databricks_workspace" {
  source              = "../modules/databricks_workspace"
  name                = var.db_workspace_name
  resource_group_name = var.resource_group_name
  location            = var.location
  sku                 = var.db_workspace_sku
}

module "eventgrid_system_topic" {
  source              = "../modules/eventgrid_system_topic"
  name                = var.eg_system_topic_name
  resource_group_name = var.resource_group_name
  location            = var.location
  topic_type          = var.eg_system_topic_type
}

module "eventgrid_system_topic_event_subscription" {
  source              = "../modules/eventgrid_system_topic_event_subscription"
  name                = var.eg_event_subscription_name
  system_topic        = module.eventgrid_system_topic.id
  resource_group_name = var.resource_group_name
}

module "network_security_group" {
  source              = "../modules/network_security_group"
  name                = var.nsg_name
  location            = var.location
  resource_group_name = var.resource_group_name
}

module "network_security_rule_1" {
  source                        = "../modules/network_security_rule"
  name                          = var.nsg_rule1_name
  network_security_group_name    = module.network_security_group.name
  resource_group_name            = var.resource_group_name
  priority                       = var.nsg_rule1_priority
  direction                      = var.nsg_rule1_direction
  access                         = var.nsg_rule1_access
  protocol                       = var.nsg_rule1_protocol
  source_port_range              = var.nsg_rule1_source_port_range
  destination_port_range         = var.nsg_rule1_destination_port_range
  source_address_prefix          = var.nsg_rule1_source_address_prefix
  destination_address_prefix     = var.nsg_rule1_destination_address_prefix
}

module "network_security_rule_2" {
  source                        = "../modules/network_security_rule"
  name                          = var.nsg_rule2_name
  network_security_group_name    = module.network_security_group.name
  resource_group_name            = var.resource_group_name
  priority                       = var.nsg_rule2_priority
  direction                      = var.nsg_rule2_direction
  access                         = var.nsg_rule2_access
  protocol                       = var.nsg_rule2_protocol
  source_port_range              = var.nsg_rule2_source_port_range
  destination_port_range         = var.nsg_rule2_destination_port_range
  source_address_prefix          = var.nsg_rule2_source_address_prefix
  destination_address_prefix     = var.nsg_rule2_destination_address_prefix
}

module "private_endpoint_1" {
  source              = "../modules/private_endpoint"
  name                = var.private_endpoint_1_name
  location            = var.location
  resource_group_name = var.resource_group_name
  subnet_id           = var.pe1_subnet_id
  private_service_connection_name = var.private_endpoint_1_private_service_connection_name
  private_connection_resource_id = var.private_endpoint_1_private_connection_resource_id
  is_manual_connection = var.private_endpoint_1_is_manual_connection
  subresource_names = var.private_endpoint_1_subresource_names
}

module "private_endpoint_2" {
  source              = "../modules/private_endpoint"
  name                = var.private_endpoint_2_name
  location            = var.location
  resource_group_name = var.resource_group_name
  subnet_id           = var.pe2_subnet_id
  private_service_connection_name = var.private_endpoint_2_private_service_connection_name
  private_connection_resource_id = var.private_endpoint_2_private_connection_resource_id
  is_manual_connection = var.private_endpoint_2_is_manual_connection
  subresource_names = var.private_endpoint_2_subresource_names
}

module "log_analytics_workspace" {
  source              = "../modules/log_analytics_workspace"
  name                = var.law_name
  location            = var.location
  resource_group_name = var.resource_group_name
  sku                 = var.law_sku
  retention_in_days   = var.law_retention_in_days
}

module "log_analytics_saved_search_1" {
  source                      = "../modules/log_analytics_saved_search"
  name                        = var.law_saved_search1_name
  log_analytics_workspace_id   = module.log_analytics_workspace.id
  display_name                 = var.law_saved_search1_display_name
  category                     = var.law_saved_search1_category
  query                        = var.law_saved_search1_query
}

module "log_analytics_saved_search_2" {
  source                      = "../modules/log_analytics_saved_search"
  name                        = var.law_saved_search2_name
  log_analytics_workspace_id   = module.log_analytics_workspace.id
  display_name                 = var.law_saved_search2_display_name
  category                     = var.law_saved_search2_category
  query                        = var.law_saved_search2_query
}


// ...existing code...
