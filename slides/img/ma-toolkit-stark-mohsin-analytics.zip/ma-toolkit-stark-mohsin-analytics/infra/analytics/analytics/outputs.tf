
output "container_app_job_1_id" {
  value = module.container_app_job_1.id
}

output "container_app_job_2_id" {
  value = module.container_app_job_2.id
}

output "container_app_environment_id" {
  value = module.container_app_environment.id
}

output "data_factory_id" {
  value = module.data_factory.id
}

output "data_factory_linked_custom_service_id" {
  value = module.data_factory_linked_custom_service.id
}

output "data_factory_pipeline_1_id" {
  value = module.data_factory_pipeline_1.id
}

output "data_factory_pipeline_2_id" {
  value = module.data_factory_pipeline_2.id
}

output "databricks_access_connector_id" {
  value = module.databricks_access_connector.id
}

output "databricks_workspace_id" {
  value = module.databricks_workspace.id
}

output "eventgrid_system_topic_id" {
  value = module.eventgrid_system_topic.id
}

output "eventgrid_system_topic_event_subscription_id" {
  value = module.eventgrid_system_topic_event_subscription.id
}

output "network_security_group_id" {
  value = module.network_security_group.id
}

output "network_security_rule_1_id" {
  value = module.network_security_rule_1.id
}

output "network_security_rule_2_id" {
  value = module.network_security_rule_2.id
}

output "private_endpoint_1_id" {
  value = module.private_endpoint_1.id
}

output "private_endpoint_2_id" {
  value = module.private_endpoint_2.id
}

output "log_analytics_workspace_id" {
  value = module.log_analytics_workspace.id
}

output "log_analytics_saved_search_1_id" {
  value = module.log_analytics_saved_search_1.id
}

output "log_analytics_saved_search_2_id" {
  value = module.log_analytics_saved_search_2.id
}
