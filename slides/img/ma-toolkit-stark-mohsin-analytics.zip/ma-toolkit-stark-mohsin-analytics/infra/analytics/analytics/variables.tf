variable "container_app_job_1_replica_timeout_in_seconds" {
	description = "Replica timeout in seconds for container_app_job_1"
	type        = number
}

variable "container_app_job_1_template" {
	description = "Template for container_app_job_1"
	type        = any
	default = {
		container = [{
			name  = "job1-container"
			image = "mcr.microsoft.com/azure-cli"
			cpu   = 0.5
			memory = 1.0
			env = []
		}]
		manual_trigger_config = {}
	}
}

variable "container_app_job_2_replica_timeout_in_seconds" {
	description = "Replica timeout in seconds for container_app_job_2"
	type        = number
}

variable "container_app_job_2_template" {
	description = "Template for container_app_job_2"
	type        = any
	default = {
		container = [{
			name  = "job2-container"
			image = "mcr.microsoft.com/azure-cli"
			cpu   = 0.5
			memory = 1.0
			env = []
		}]
		manual_trigger_config = {}
	}
}

variable "df_linked_custom_service_type_properties_json" {
	description = "Type properties JSON for data_factory_linked_custom_service"
	type        = string
}
variable "private_endpoint_1_private_service_connection_name" { type = string }
variable "private_endpoint_1_private_connection_resource_id" { type = string }
variable "private_endpoint_1_is_manual_connection" { type = bool }
variable "private_endpoint_1_subresource_names" { type = list(string) }

variable "private_endpoint_2_private_service_connection_name" { type = string }
variable "private_endpoint_2_private_connection_resource_id" { type = string }
variable "private_endpoint_2_is_manual_connection" { type = bool }
variable "private_endpoint_2_subresource_names" { type = list(string) }
variable "nsg_rule1_name" { type = string }
variable "nsg_rule2_name" { type = string }
variable "law_saved_search1_name" { type = string }
variable "law_saved_search2_name" { type = string }
variable "container_app_job_1_name" { type = string }
variable "container_app_job_2_name" { type = string }
variable "data_factory_pipeline_1_name" { type = string }
variable "data_factory_pipeline_2_name" { type = string }
variable "private_endpoint_1_name" { type = string }
variable "private_endpoint_2_name" { type = string }

variable "resource_group_name" {
	description = "Name of the resource group"
	type        = string
}

variable "location" {
	description = "Azure region for resources"
	type        = string
}

variable "tags" {
	description = "Tags for the resource group"
	type        = map(string)
	default     = {}
}

variable "container_app_environment_name" {
	description = "Name of the container app environment"
	type        = string
}

variable "data_factory_name" {
	description = "Name of the data factory"
	type        = string
}

variable "df_linked_custom_service_name" {
	description = "Name of the Data Factory linked custom service"
	type        = string
}

variable "df_linked_custom_service_type" {
	description = "Type of the Data Factory linked custom service"
	type        = string
}

variable "db_access_connector_name" {
	description = "Name of the Databricks access connector"
	type        = string
}

variable "db_workspace_name" {
	description = "Name of the Databricks workspace"
	type        = string
}

variable "db_workspace_sku" {
	description = "SKU for the Databricks workspace"
	type        = string
}

variable "eg_system_topic_name" {
	description = "Name of the EventGrid system topic"
	type        = string
}

variable "eg_system_topic_type" {
	description = "Type of the EventGrid system topic"
	type        = string
}
variable "subscription_id" {
  description = "Azure Subscription ID"
  type        = string
  default     = "4293db49-78c9-4e47-bcd0-b44b4f7610a4"
}

variable "eg_event_subscription_name" {
	description = "Name of the EventGrid event subscription"
	type        = string
}

variable "nsg_name" {
	description = "Name of the network security group"
	type        = string
}

variable "nsg_rule1_priority" {
	description = "Priority for NSG rule 1"
	type        = number
}

variable "nsg_rule1_direction" {
	description = "Direction for NSG rule 1"
	type        = string
}

variable "nsg_rule1_access" {
	description = "Access for NSG rule 1"
	type        = string
}

variable "nsg_rule1_protocol" {
	description = "Protocol for NSG rule 1"
	type        = string
}

variable "nsg_rule1_source_port_range" {
	description = "Source port range for NSG rule 1"
	type        = string
}

variable "nsg_rule1_destination_port_range" {
	description = "Destination port range for NSG rule 1"
	type        = string
}

variable "nsg_rule1_source_address_prefix" {
	description = "Source address prefix for NSG rule 1"
	type        = string
}

variable "nsg_rule1_destination_address_prefix" {
	description = "Destination address prefix for NSG rule 1"
	type        = string
}

variable "nsg_rule2_priority" {
	description = "Priority for NSG rule 2"
	type        = number
}

variable "nsg_rule2_direction" {
	description = "Direction for NSG rule 2"
	type        = string
}

variable "nsg_rule2_access" {
	description = "Access for NSG rule 2"
	type        = string
}

variable "nsg_rule2_protocol" {
	description = "Protocol for NSG rule 2"
	type        = string
}

variable "nsg_rule2_source_port_range" {
	description = "Source port range for NSG rule 2"
	type        = string
}

variable "nsg_rule2_destination_port_range" {
	description = "Destination port range for NSG rule 2"
	type        = string
}

variable "nsg_rule2_source_address_prefix" {
	description = "Source address prefix for NSG rule 2"
	type        = string
}

variable "nsg_rule2_destination_address_prefix" {
	description = "Destination address prefix for NSG rule 2"
	type        = string
}

variable "pe1_subnet_id" {
	description = "Subnet ID for private endpoint 1"
	type        = string
}

variable "pe2_subnet_id" {
	description = "Subnet ID for private endpoint 2"
	type        = string
}

variable "law_name" {
	description = "Name of the Log Analytics Workspace"
	type        = string
}

variable "law_sku" {
	description = "SKU for the Log Analytics Workspace"
	type        = string
}

variable "law_retention_in_days" {
	description = "Retention in days for Log Analytics Workspace"
	type        = number
}

variable "law_saved_search1_display_name" {
	description = "Display name for Log Analytics Saved Search 1"
	type        = string
}

variable "law_saved_search1_category" {
	description = "Category for Log Analytics Saved Search 1"
	type        = string
}

variable "law_saved_search1_query" {
	description = "Query for Log Analytics Saved Search 1"
	type        = string
}

variable "law_saved_search2_display_name" {
	description = "Display name for Log Analytics Saved Search 2"
	type        = string
}

variable "law_saved_search2_category" {
	description = "Category for Log Analytics Saved Search 2"
	type        = string
}

variable "law_saved_search2_query" {
	description = "Query for Log Analytics Saved Search 2"
	type        = string
}
