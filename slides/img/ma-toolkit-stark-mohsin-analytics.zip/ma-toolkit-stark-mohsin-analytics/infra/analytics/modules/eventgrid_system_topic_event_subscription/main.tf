// EventGrid System Topic Event Subscription module main.tf
resource "azurerm_eventgrid_system_topic_event_subscription" "this" {
  name                = var.name
  system_topic        = var.system_topic
  resource_group_name = var.resource_group_name
  // ...add other required properties and variables as needed
}
