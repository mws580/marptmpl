variable "name" { type = string }
variable "system_topic" { type = string }
variable "resource_group_name" { type = string }
