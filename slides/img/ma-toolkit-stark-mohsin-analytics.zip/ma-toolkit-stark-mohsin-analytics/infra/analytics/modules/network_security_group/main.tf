// Network Security Group module main.tf
resource "azurerm_network_security_group" "this" {
  name                = var.name
  location            = var.location
  resource_group_name = var.resource_group_name
  // ...add other required properties and variables as needed
}
