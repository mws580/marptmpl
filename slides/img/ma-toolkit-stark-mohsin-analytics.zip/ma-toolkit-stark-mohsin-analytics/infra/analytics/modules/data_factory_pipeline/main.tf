// Data Factory Pipeline module main.tf
resource "azurerm_data_factory_pipeline" "this" {
  name                = var.name
  data_factory_id     = var.data_factory_id
  // ...add other required properties and variables as needed
}
