output "id" {
  value = azurerm_data_factory_pipeline.this.id
}
