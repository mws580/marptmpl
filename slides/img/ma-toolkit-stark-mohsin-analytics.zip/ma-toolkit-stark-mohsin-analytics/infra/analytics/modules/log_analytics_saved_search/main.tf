// Log Analytics Saved Search module main.tf
resource "azurerm_log_analytics_saved_search" "this" {
  name                = var.name
  log_analytics_workspace_id = var.log_analytics_workspace_id
  display_name        = var.display_name
  category            = var.category
  query               = var.query
  // ...add other required properties and variables as needed
}
