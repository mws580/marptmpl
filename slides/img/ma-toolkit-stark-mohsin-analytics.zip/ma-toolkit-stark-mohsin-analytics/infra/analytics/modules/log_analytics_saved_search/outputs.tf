output "id" {
  value = azurerm_log_analytics_saved_search.this.id
}
