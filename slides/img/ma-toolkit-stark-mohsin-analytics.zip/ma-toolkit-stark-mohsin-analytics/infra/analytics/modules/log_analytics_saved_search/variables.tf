variable "name" { type = string }
variable "log_analytics_workspace_id" { type = string }
variable "display_name" { type = string }
variable "category" { type = string }
variable "query" { type = string }
