variable "replica_timeout_in_seconds" { type = number }
variable "template" { type = any }
variable "manual_trigger_config" {
	type = object({
		parallelism              = number
		replica_completion_count = number
	})
	default = null
}
variable "name" { type = string }
variable "container_app_environment_id" { type = string }
variable "resource_group_name" { type = string }
variable "location" { type = string }
