// Container App Job module main.tf
resource "azurerm_container_app_job" "this" {
  name                = var.name
  container_app_environment_id = var.container_app_environment_id
  resource_group_name = var.resource_group_name
  location            = var.location
  replica_timeout_in_seconds   = var.replica_timeout_in_seconds

  template {
    dynamic "container" {
      for_each = try(var.template.container, [])
      content {
        name   = container.value.name
        image  = container.value.image
        cpu    = container.value.cpu
        memory = container.value.memory
        # Add more container fields as needed
      }
    }
    # Add other blocks (init_container, etc.) as needed using similar dynamic blocks
  }

  dynamic "manual_trigger_config" {
    for_each = var.manual_trigger_config == null ? [] : [var.manual_trigger_config]
    content {
      parallelism              = manual_trigger_config.value.parallelism
      replica_completion_count = manual_trigger_config.value.replica_completion_count
    }
  }
  # ...existing code...
}
