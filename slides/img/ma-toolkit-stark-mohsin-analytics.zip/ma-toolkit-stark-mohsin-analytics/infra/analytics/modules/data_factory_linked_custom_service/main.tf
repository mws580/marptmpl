// Data Factory Linked Custom Service module main.tf
resource "azurerm_data_factory_linked_custom_service" "this" {
  name                = var.name
  data_factory_id     = var.data_factory_id
  type                = var.type
  type_properties_json = var.type_properties_json
  // ...existing code...
}
