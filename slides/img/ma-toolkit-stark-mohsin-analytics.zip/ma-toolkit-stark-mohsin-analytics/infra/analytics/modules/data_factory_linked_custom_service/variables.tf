variable "type_properties_json" { type = string }
variable "name" { type = string }
variable "data_factory_id" { type = string }
variable "type" { type = string }
