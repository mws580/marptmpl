// EventGrid System Topic module main.tf
resource "azurerm_eventgrid_system_topic" "this" {
  name                = var.name
  resource_group_name = var.resource_group_name
  location            = var.location
  topic_type          = var.topic_type
  // ...add other required properties and variables as needed
}
