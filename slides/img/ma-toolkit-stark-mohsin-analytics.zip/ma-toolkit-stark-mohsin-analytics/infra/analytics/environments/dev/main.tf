terraform {
  required_version = ">= 1.0.0"
}

provider "azurerm" {
  features {}
}

module "analytics" {
  source = "../../analytics"
  resource_group_name = var.resource_group_name
  location = var.location
  tags = var.tags
  container_app_environment_name = var.container_app_environment_name
  data_factory_name = var.data_factory_name
  df_linked_custom_service_name = var.df_linked_custom_service_name
  df_linked_custom_service_type = var.df_linked_custom_service_type
  db_access_connector_name = var.db_access_connector_name
  db_workspace_name = var.db_workspace_name
  db_workspace_sku = var.db_workspace_sku
  eg_system_topic_name = var.eg_system_topic_name
  eg_system_topic_type = var.eg_system_topic_type
  eg_event_subscription_name = var.eg_event_subscription_name
  nsg_name = var.nsg_name
  nsg_rule1_name = var.nsg_rule1_name
  nsg_rule1_priority = var.nsg_rule1_priority
  nsg_rule1_direction = var.nsg_rule1_direction
  nsg_rule1_access = var.nsg_rule1_access
  nsg_rule1_protocol = var.nsg_rule1_protocol
  nsg_rule1_source_port_range = var.nsg_rule1_source_port_range
  nsg_rule1_destination_port_range = var.nsg_rule1_destination_port_range
  nsg_rule1_source_address_prefix = var.nsg_rule1_source_address_prefix
  nsg_rule1_destination_address_prefix = var.nsg_rule1_destination_address_prefix
  nsg_rule2_name = var.nsg_rule2_name
  nsg_rule2_priority = var.nsg_rule2_priority
  nsg_rule2_direction = var.nsg_rule2_direction
  nsg_rule2_access = var.nsg_rule2_access
  nsg_rule2_protocol = var.nsg_rule2_protocol
  nsg_rule2_source_port_range = var.nsg_rule2_source_port_range
  nsg_rule2_destination_port_range = var.nsg_rule2_destination_port_range
  nsg_rule2_source_address_prefix = var.nsg_rule2_source_address_prefix
  nsg_rule2_destination_address_prefix = var.nsg_rule2_destination_address_prefix
  pe1_subnet_id = var.pe1_subnet_id
  pe2_subnet_id = var.pe2_subnet_id
  law_name = var.law_name
  law_sku = var.law_sku
  law_retention_in_days = var.law_retention_in_days
  law_saved_search1_name = var.law_saved_search1_name
  law_saved_search1_display_name = var.law_saved_search1_display_name
  law_saved_search1_category = var.law_saved_search1_category
  law_saved_search1_query = var.law_saved_search1_query
  law_saved_search2_name = var.law_saved_search2_name
  law_saved_search2_display_name = var.law_saved_search2_display_name
  law_saved_search2_category = var.law_saved_search2_category
  law_saved_search2_query = var.law_saved_search2_query
  container_app_job_1_name = var.container_app_job_1_name
  container_app_job_2_name = var.container_app_job_2_name
  data_factory_pipeline_1_name = var.data_factory_pipeline_1_name
  data_factory_pipeline_2_name = var.data_factory_pipeline_2_name
  private_endpoint_1_name = var.private_endpoint_1_name
  private_endpoint_2_name = var.private_endpoint_2_name
  private_endpoint_1_private_service_connection_name = var.private_endpoint_1_private_service_connection_name
  private_endpoint_1_private_connection_resource_id = var.private_endpoint_1_private_connection_resource_id
  private_endpoint_1_is_manual_connection = var.private_endpoint_1_is_manual_connection
  private_endpoint_1_subresource_names = var.private_endpoint_1_subresource_names
  private_endpoint_2_private_service_connection_name = var.private_endpoint_2_private_service_connection_name
  private_endpoint_2_private_connection_resource_id = var.private_endpoint_2_private_connection_resource_id
  private_endpoint_2_is_manual_connection = var.private_endpoint_2_is_manual_connection
  private_endpoint_2_subresource_names = var.private_endpoint_2_subresource_names
  container_app_job_1_replica_timeout_in_seconds = var.container_app_job_1_replica_timeout_in_seconds
  container_app_job_1_template = var.container_app_job_1_template
  container_app_job_2_replica_timeout_in_seconds = var.container_app_job_2_replica_timeout_in_seconds
  container_app_job_2_template = var.container_app_job_2_template
  df_linked_custom_service_type_properties_json = var.df_linked_custom_service_type_properties_json
}
