output "container_app_job_1_id" {
  value = module.analytics.container_app_job_1_id
}

output "container_app_job_2_id" {
  value = module.analytics.container_app_job_2_id
}

output "container_app_environment_id" {
  value = module.analytics.container_app_environment_id
}

output "data_factory_id" {
  value = module.analytics.data_factory_id
}

output "data_factory_linked_custom_service_id" {
  value = module.analytics.data_factory_linked_custom_service_id
}

output "data_factory_pipeline_1_id" {
  value = module.analytics.data_factory_pipeline_1_id
}

output "data_factory_pipeline_2_id" {
  value = module.analytics.data_factory_pipeline_2_id
}

output "databricks_access_connector_id" {
  value = module.analytics.databricks_access_connector_id
}

output "databricks_workspace_id" {
  value = module.analytics.databricks_workspace_id
}

output "eventgrid_system_topic_id" {
  value = module.analytics.eventgrid_system_topic_id
}

output "eventgrid_system_topic_event_subscription_id" {
  value = module.analytics.eventgrid_system_topic_event_subscription_id
}

output "network_security_group_id" {
  value = module.analytics.network_security_group_id
}

output "network_security_rule_1_id" {
  value = module.analytics.network_security_rule_1_id
}

output "network_security_rule_2_id" {
  value = module.analytics.network_security_rule_2_id
}

output "private_endpoint_1_id" {
  value = module.analytics.private_endpoint_1_id
}

output "private_endpoint_2_id" {
  value = module.analytics.private_endpoint_2_id
}

output "log_analytics_workspace_id" {
  value = module.analytics.log_analytics_workspace_id
}

output "log_analytics_saved_search_1_id" {
  value = module.analytics.log_analytics_saved_search_1_id
}

output "log_analytics_saved_search_2_id" {
  value = module.analytics.log_analytics_saved_search_2_id
}
