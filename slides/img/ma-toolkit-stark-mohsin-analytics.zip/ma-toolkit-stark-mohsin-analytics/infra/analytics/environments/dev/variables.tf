variable "container_app_job_1_replica_timeout_in_seconds" {
	type    = number
	default = 60
}
variable "container_app_job_1_template" {
	type    = any
	default = {
		container = [
			{
				name   = "aca-job-ingest-source"
				image  = "acrm365deveastus2.azurecr.io/analytics/graph-ingest:v14"
				cpu    = 1
				memory = "2Gi"
				args    = []
				command = []
				env = [
					{
						name        = "ENVIRONMENT"
						value       = "source"
						secret_name = ""
					},
					{
						name        = "KEYVAULT_NAME"
						value       = "kv-m365-dev-001"
						secret_name = ""
					},
					{
						name        = "ENTITY_TYPE"
						value       = "users"
						secret_name = ""
					}
				]
			}
		]
		 manual_trigger_config = {
			 parallelism              = 1
			 replica_completion_count = 1
		 }
	   }
	}
variable "container_app_job_2_replica_timeout_in_seconds" {
	type    = number
	default = 60
}
variable "container_app_job_2_template" {
	type    = any
	default = {
		container = [
			{
				name   = "aca-job-ingest-target"
				image  = "acrm365deveastus2.azurecr.io/analytics/graph-ingest:v14"
				cpu    = 1
				memory = "2Gi"
				args    = []
				command = []
				env = [
					{
						name        = "ENVIRONMENT"
						value       = "target"
						secret_name = ""
					},
					{
						name        = "KEYVAULT_NAME"
						value       = "kv-m365-dev-001"
						secret_name = ""
					},
					{
						name        = "ENTITY_TYPE"
						value       = "users"
						secret_name = ""
					}
				]
			}
		]
		 manual_trigger_config = {
			 parallelism              = 1
			 replica_completion_count = 1
		 }
	   }
	}
variable "df_linked_custom_service_type_properties_json" {
	type    = string
	default = "{}"
}
variable "private_endpoint_1_private_service_connection_name" {
	type    = string
	default = "pep-m365-dev-analytics1-psc"
}
variable "private_endpoint_1_private_connection_resource_id" {
	type    = string
	default = "/subscriptions/00000000-0000-0000-0000-000000000000/resourceGroups/example-rg/providers/Microsoft.Storage/storageAccounts/example-storage"
}
variable "private_endpoint_1_is_manual_connection" {
	type    = bool
	default = false
}
variable "private_endpoint_1_subresource_names" {
	type    = list(string)
	default = ["blob"]
}

variable "private_endpoint_2_private_service_connection_name" {
	type    = string
	default = "pep-m365-dev-analytics2-psc"
}
variable "private_endpoint_2_private_connection_resource_id" {
	type    = string
	default = "/subscriptions/00000000-0000-0000-0000-000000000000/resourceGroups/example-rg/providers/Microsoft.Sql/servers/example-sql"
}
variable "private_endpoint_2_is_manual_connection" {
	type    = bool
	default = false
}
variable "private_endpoint_2_subresource_names" {
	type    = list(string)
	default = ["sqlServer"]
}
variable "resource_group_name" {
	type    = string
	default = "rg-m365-dev-analytics-eastus2-001"
}
variable "location" {
	type    = string
	default = "eastus"
}
variable "tags" {
	type    = map(string)
	default = { environment = "dev" }
}
variable "container_app_environment_name" {
	type    = string
	default = "cae-m365-dev-analytics"
}
variable "data_factory_name" {
	type    = string
	default = "adf-m365-dev-analytics"
}
variable "df_linked_custom_service_name" {
	type    = string
	default = "adf-m365-dev-analytics-lcs"
}
variable "df_linked_custom_service_type" {
	type    = string
	default = "CustomType"
}
variable "db_access_connector_name" {
	type    = string
	default = "dbac-m365-dev-analytics"
}
variable "db_workspace_name" {
	type    = string
	default = "dbws-m365-dev-analytics"
}
variable "db_workspace_sku" {
	type    = string
	default = "standard"
}
variable "eg_system_topic_name" {
	type    = string
	default = "evgt-m365-dev-analytics"
}
variable "eg_system_topic_type" {
	type    = string
	default = "Microsoft.Storage.StorageAccounts"
}
variable "eg_event_subscription_name" {
	type    = string
	default = "evgs-m365-dev-analytics"
}
variable "nsg_name" {
	type    = string
	default = "nsg-m365-dev-analytics"
}
variable "nsg_rule1_name" {
	type    = string
	default = "nsg-m365-dev-analytics-rule-1"
}
variable "nsg_rule1_priority" {
	type    = number
	default = 100
}
variable "nsg_rule1_direction" {
	type    = string
	default = "Inbound"
}
variable "nsg_rule1_access" {
	type    = string
	default = "Allow"
}
variable "nsg_rule1_protocol" {
	type    = string
	default = "Tcp"
}
variable "nsg_rule1_source_port_range" {
	type    = string
	default = "*"
}
variable "nsg_rule1_destination_port_range" {
	type    = string
	default = "80"
}
variable "nsg_rule1_source_address_prefix" {
	type    = string
	default = "*"
}
variable "nsg_rule1_destination_address_prefix" {
	type    = string
	default = "*"
}
variable "nsg_rule2_name" {
	type    = string
	default = "nsg-m365-dev-analytics-rule-2"
}
variable "nsg_rule2_priority" {
	type    = number
	default = 200
}
variable "nsg_rule2_direction" {
	type    = string
	default = "Outbound"
}
variable "nsg_rule2_access" {
	type    = string
	default = "Deny"
}
variable "nsg_rule2_protocol" {
	type    = string
	default = "Tcp"
}
variable "nsg_rule2_source_port_range" {
	type    = string
	default = "*"
}
variable "nsg_rule2_destination_port_range" {
	type    = string
	default = "443"
}
variable "nsg_rule2_source_address_prefix" {
	type    = string
	default = "*"
}
variable "nsg_rule2_destination_address_prefix" {
	type    = string
	default = "*"
}
variable "pe1_subnet_id" {
	type    = string
	default = "/subscriptions/00000000-0000-0000-0000-000000000000/resourceGroups/example-rg/providers/Microsoft.Network/virtualNetworks/example-vnet/subnets/subnet1"
}
variable "pe2_subnet_id" {
	type    = string
	default = "/subscriptions/00000000-0000-0000-0000-000000000000/resourceGroups/example-rg/providers/Microsoft.Network/virtualNetworks/example-vnet/subnets/subnet2"
}
variable "law_name" {
	type    = string
	default = "log-m365-dev-analytics"
}
variable "law_sku" {
	type    = string
	default = "PerGB2018"
}
variable "law_retention_in_days" {
	type    = number
	default = 30
}
variable "law_saved_search1_name" {
	type    = string
	default = "log-m365-dev-analytics-ss-1"
}
variable "law_saved_search1_display_name" {
	type    = string
	default = "Saved m365-dev-analytics Search 1"
}
variable "law_saved_search1_category" {
	type    = string
	default = "Analytics"
}
variable "law_saved_search1_query" {
	type    = string
	default = "Heartbeat | take 10"
}
variable "law_saved_search2_name" {
	type    = string
	default = "log-ss-2"
}
variable "law_saved_search2_display_name" {
	type    = string
	default = "Saved m365-dev-analytics Search 2"
}
variable "law_saved_search2_category" {
	type    = string
	default = "Security"
}
variable "law_saved_search2_query" {
	type    = string
	default = "SecurityEvent | take 10"
}
variable "container_app_job_1_name" {
	type    = string
	default = "caj-m365-dev-analytics-1"
}
variable "container_app_job_2_name" {
	type    = string
	default = "caj-m365-dev-analytics-2"
}
variable "data_factory_pipeline_1_name" {
	type    = string
	default = "adf-pipeline-m365-dev-analytics-1"
}
variable "data_factory_pipeline_2_name" {
	type    = string
	default = "adf-pipeline-m365-dev-analytics-2"
}
variable "private_endpoint_1_name" {
	type    = string
	default = "pep-m365-dev-analytics-1"
}
variable "private_endpoint_2_name" {
	type    = string
	default = "pep-m365-dev-analytics-2"
}
